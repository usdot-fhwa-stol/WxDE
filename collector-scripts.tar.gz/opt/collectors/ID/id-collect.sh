wget -O /opt/collectors/ID/data/id.xml --user=idt --password=Data4Idaho http://exportdb.bouds.vaisala.com/export?region=299
java -cp /opt/collectors/ID vaisalaxml.VaisalaXML /opt/collectors/ID/data/id.xml /opt/collectors/ID/data/id.csv
