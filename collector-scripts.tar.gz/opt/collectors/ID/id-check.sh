#!/bin/sh
isRunning=`ps -e | grep id-collect.sh`
if test ${#isRunning} -eq 0
then
  /opt/collectors/ID/id-collect.sh
fi
