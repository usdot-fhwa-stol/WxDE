wget -r -l1 --no-parent -nd -N -P /opt/collectors/MN/data/RWISexport --user=clarus --password=MNcdk755 -A ssi.atmos.*,ssi.Sub.*,ssi.surface.* ftp://rwis.dot.state.mn.us/external_images/
