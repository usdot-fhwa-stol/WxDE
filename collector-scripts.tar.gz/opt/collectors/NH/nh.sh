wget --no-parent -nd -N -P /opt/collectors/NH/data http://199.192.6.37/NH_ExpAtmosDataRaw.txt
wget --no-parent -nd -N -P /opt/collectors/NH/data http://199.192.6.37/NH_ExpSurfaceDataRaw.txt
wget --user=bKrueger --password=hSj3A2 --no-parent -nd -N -P /opt/collectors/NH/data http://50.17.222.248/NHDOT/export/NTCIP_Bow.csv
wget --user=bKrueger --password=hSj3A2 --no-parent -nd -N -P /opt/collectors/NH/data http://50.17.222.248/NHDOT/export/NTCIP_Hooksett.csv
wget --user=bKrueger --password=hSj3A2 --no-parent -nd -N -P /opt/collectors/NH/data http://50.17.222.248/NHDOT/export/NTCIP_Nashua.csv
