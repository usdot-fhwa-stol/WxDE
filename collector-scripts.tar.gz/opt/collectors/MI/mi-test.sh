#!/bin/sh
isRunning=`ps -e | grep -c mi-test`
if test ${#isRunning} -eq 1
then
  echo true
else
  echo false
fi
