#!/bin/sh
isRunning=`ps -e | grep mi-collect`
if test ${#isRunning} -eq 0
then
  /opt/collectors/MI/mi-collect.sh &
fi
