sudo tar zcvf $1.tgz $1
sudo rm -r $1
