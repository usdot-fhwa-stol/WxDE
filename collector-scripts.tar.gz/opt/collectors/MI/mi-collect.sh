java -cp /opt/collectors/MI wde.cs.imo.MiDot http://imo.umtri.umich.edu/synesis/ /opt/collectors/MI/data/IMO/
