#!/bin/bash

radar_root=/opt/collectors/radar
old_folder="$(date --date="2 days ago" +'%Y%m%d')"
if [ -d "$radar_root/data/$old_folder" ]; then
	printf "removing $radar_root/data/$old_folder"
	rm -r "$radar_root/data/$old_folder"
fi
