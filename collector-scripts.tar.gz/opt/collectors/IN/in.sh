psftp -b /opt/collectors/IN/in.scr -batch -pw WxDE2015-1 brboyce@shared.state.in.us@sftp.in.gov
