#!/bin/bash

interval=60
now="$(date +'%s')"
let remainder=($interval - $now % $interval)
sleep $remainder

while :
do
	end="$(date +'%Y-%m-%dT%H:%M:%SZ')"
	start="$(date --date="5 seconds ago" +'%Y-%m-%dT%H:%M:%SZ')"

	curl "http://api.weathertelematics.com/filtered/KizuocpR5HyGScbg6b3U.xml?start_date=$start&end_date=$end" |gzip -d > data/obsData_$end.xml

	now="$(date +'%s')"
	let remainder=($interval - $now % $interval)
	sleep $remainder
done
