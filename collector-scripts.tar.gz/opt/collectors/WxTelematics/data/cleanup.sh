#!/bin/sh

# cleans up old files in this directory.
# Assumes the year is 2014!


