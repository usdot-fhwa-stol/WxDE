wget -O /opt/collectors/WxTelematics/data/MOPED.dat https://madis-data.noaa.gov/madisDOT/data/MOPED.dat
