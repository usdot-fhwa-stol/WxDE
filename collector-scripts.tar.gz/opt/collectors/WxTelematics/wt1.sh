#!/bin/bash

end="$(date +'%Y-%m-%dT%H:%M:%SZ')"
start="$(date --date="5 seconds ago" +'%Y-%m-%dT%H:%M:%SZ')"
datafolder=/opt/collectors/WxTelematics/data

curl "http://api.weathertelematics.com/filtered/KizuocpR5HyGScbg6b3U.xml?start_date=$start&end_date=$end" |gzip -d > $datafolder/obsData_$end.xml
