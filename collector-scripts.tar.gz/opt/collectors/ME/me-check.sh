#!/bin/sh
isRunning=`ps -e | grep me-collect.sh`
if test ${#isRunning} -eq 0
then
  /opt/collectors/ME/me-collect.sh
fi
