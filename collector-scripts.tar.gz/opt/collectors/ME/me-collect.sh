wget -O /opt/collectors/ME/data/me.xml --user=maine --password=Data4Maine21 http://exportdb.bouds.vaisala.com/export?region=315
java -cp /opt/collectors/ME vaisalaxml.VaisalaXML /opt/collectors/ME/data/me.xml /opt/collectors/ME/data/me.csv
