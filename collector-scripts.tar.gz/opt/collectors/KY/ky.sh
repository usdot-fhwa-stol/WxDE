#!/bin/sh
wget -N -T 20 -r -l1 -np -nd -P /opt/collectors/KY/data --user=Clarus --password="dv<3,3<Sd0iT" -A *.dat -R test* ftp://159.19.10.68/RWIS/weatherdata/
java -cp /opt/collectors/KY wde.cs.MergeKY /opt/collectors/KY/data/ /opt/collectors/KY/data/ky.csv
