curl ftp://tgftp.nws.noaa.gov/data/observations/metar/cycles/$(date +"%H")Z.TXT -o /opt/collectors/NWS/data/nws.txt
java -cp /opt/collectors/NWS metar.Main /opt/collectors/NWS/data/nws.txt /opt/collectors/NWS/data/nws2.csv
rm /opt/collectors/NWS/data/nws.txt
