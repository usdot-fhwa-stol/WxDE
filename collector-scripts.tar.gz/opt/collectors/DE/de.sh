wget -N -P /opt/collectors/DE/data https://tmc.deldot.gov/json/weatherstation.json
java -cp /opt/collectors/DE DEjson /opt/collectors/DE/data/weatherstation.json
