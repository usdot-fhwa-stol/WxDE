wget --user=synpat --password=nuC53Ken --no-parent -nd -N -P /opt/collectors/CO/data http://data.cotrip.org/xml/weatherstation.xml
# mkdir /opt/apache-tomcat-7.0.41/webapps/ROOT/CO
# cp /opt/collectors/CO/* /opt/apache-tomcat-7.0.41/webapps/ROOT/CO
