#!/bin/sh
wget -N -T 20 -r -l1 -np -nd -P /opt/collectors/UT/data --user=anonymous --password=clarus@mixonhill.com -A *MesoAtmo.dat,*MesoRoad.dat -R Farmington* ftp://ftp.commuterlink.utah.gov/RWIS/
java -cp /opt/collectors/UT MergeUT /opt/collectors/UT/data _MesoAtmo.dat /opt/collectors/UT/data/ut-atmo.csv 7 -21600000
java -cp /opt/collectors/UT MergeUT /opt/collectors/UT/data _MesoRoad.dat /opt/collectors/UT/data/ut-road.csv 0 -21600000
