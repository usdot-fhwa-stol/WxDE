#!/bin/sh
isRunning=`ps -e | grep ut-collect.sh`
if test ${#isRunning} -eq 0
then
  /opt/collectors/UT/ut-collect.sh
fi
