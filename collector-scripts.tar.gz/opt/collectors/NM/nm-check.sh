#!/bin/sh
isRunning=`ps -e | grep nm-collect.sh`
if test ${#isRunning} -eq 0
then
  /opt/collectors/NM/nm-collect.sh
fi
