wget -O /opt/collectors/NM/data/nm.xml --user=nmadmin --password=nmgetsomeDATA! http://exportdb.bouds.vaisala.com/export?region=979
java -cp /opt/collectors/NM vaisalaxml.VaisalaXML /opt/collectors/NM/data/nm.xml /opt/collectors/NM/data/nm.csv
