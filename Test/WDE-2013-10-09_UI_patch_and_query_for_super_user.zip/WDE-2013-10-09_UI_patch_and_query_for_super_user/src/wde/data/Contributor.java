package wde.data;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Contributor {
	
	private Integer contributorId;
	private String name;
	private String agency;
	private String disclaimer;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public Integer getContributorId() {
		return contributorId;
	}
	public void setContributorId(Integer contributorId) {
		this.contributorId = contributorId;
	}
	public String getDisclaimer() {
		return disclaimer;
	}
	public void setDisclaimer(String disclaimer) {
		this.disclaimer = disclaimer;
	}
}
