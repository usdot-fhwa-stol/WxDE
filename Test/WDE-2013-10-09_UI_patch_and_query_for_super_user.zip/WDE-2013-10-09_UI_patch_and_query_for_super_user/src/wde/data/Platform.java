package wde.data;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Platform {
	
	private Integer id;
	private String platformCode;
	private Character category;
	private String description;
	private Integer contributorId;
	private Double locBaseLat;
	private Double locBaseLong;
	private Double locBaseElev;
	private String updateTime;
	private String toTime;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getContributorId() {
		return contributorId;
	}
	public void setContributorId(Integer contributorId) {
		this.contributorId = contributorId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPlatformCode() {
		return platformCode;
	}
	public void setPlatformCode(String platformCode) {
		this.platformCode = platformCode;
	}
	public Character getCategory() {
		return category;
	}
	public void setCategory(Character category) {
		this.category = category;
	}
	public Double getLocBaseLat() {
		return locBaseLat;
	}
	public void setLocBaseLat(Double locBaseLat) {
		this.locBaseLat = locBaseLat;
	}
	public Double getLocBaseLong() {
		return locBaseLong;
	}
	public void setLocBaseLong(Double locBaseLong) {
		this.locBaseLong = locBaseLong;
	}
	public Double getLocBaseElev() {
		return locBaseElev;
	}
	public void setLocBaseElev(Double locBaseElev) {
		this.locBaseElev = locBaseElev;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getToTime() {
		return toTime;
	}
	public void setToTime(String toTime) {
		this.toTime = toTime;
	}
	
}
