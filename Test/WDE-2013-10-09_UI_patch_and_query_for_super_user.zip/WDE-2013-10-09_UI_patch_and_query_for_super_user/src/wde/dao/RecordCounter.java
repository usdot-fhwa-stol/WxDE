/************************************************************************
 * Source filename: RecordCounter.java
 * 
 * Creation date: Mar 2, 2013
 * 
 * Author: zhengg
 * 
 * Project: WxDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.dao;

public class RecordCounter {

    private int insertCounter;
    
    private int updateCounter;

    /**
     * @return the insertCounter
     */
    public int getInsertCounter() {
        return insertCounter;
    }

    /**
     * @param insertCounter the insertCounter to set
     */
    public void setInsertCounter(int insertCounter) {
        this.insertCounter = insertCounter;
    }

    /**
     * @return the updateCounter
     */
    public int getUpdateCounter() {
        return updateCounter;
    }

    /**
     * @param updateCounter the updateCounter to set
     */
    public void setUpdateCounter(int updateCounter) {
        this.updateCounter = updateCounter;
    }
    
}
