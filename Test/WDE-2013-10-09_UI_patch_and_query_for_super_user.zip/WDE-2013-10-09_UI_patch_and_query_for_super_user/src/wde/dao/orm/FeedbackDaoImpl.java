package wde.dao.orm;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import wde.dao.WdeDbSessionManager;
import wde.data.Contributor;
import wde.data.Feedback;


public class FeedbackDaoImpl implements FeedbackDao {
	
	@Override
	public void insertNewFeedback(Feedback feedback) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);

		try {
			session.insert("wde.FeedbackMapper.insertNewFeedback", feedback);
		} finally {
			session.close();
		}			
	}

	@Override
	public List<Feedback> getFeedbacks() {
		SqlSessionFactory sqlMapper = WdeDbSessionManager
				.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);
		List<Feedback> retList = null;
		try {
			retList = session
					.selectList("wde.FeedbackMapper.selectFeedbacks");
		} finally {
			session.close();
		}
		return retList;
	}
}
