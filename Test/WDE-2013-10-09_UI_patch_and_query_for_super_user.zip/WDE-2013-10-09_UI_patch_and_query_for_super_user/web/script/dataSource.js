$(function() {
	var strURL = ''
	$('#loading').fadeIn('slow')
	var strDisclaimer
	setTimeout(
			function() {
				$
						.getJSON(
								'/resources/contributors',
								function(data) {
									$
											.each(
													data.contributor,
													function(key, value) {

														strDisclaimer = value.disclaimer
														if (strDisclaimer == undefined)
															strDisclaimer = "<td class=\"align-center\"><span style=\"color: #999\">none</span></td>"
														else
															strDisclaimer = '<td class=\"align-center\"><a href="'
																	+ strDisclaimer
																	+ '" class="btn-dark align-center exit-link"><i class="icon-file-text-alt"></i> View</a>'
														$('.reports-table')
																.append(
																		'<tr>'
																				+ '<td id="sourceName" data-type="'
																				+ value.name
																				+ '">'
																				+ value.name
																				+ '</td>'
																				+ '<td>'
																				+ value.agency
																				+ '</td>'
																				+ strDisclaimer
																				+ '<td><a href="/auth/platforms.jsp#'
																				+ value.contributorId
																				+ '" class="btn-dark align-center"><i class="icon-file-text-alt"></i> View</a>'
																				+ '</tr>')

													})
									$(".exit-link").click(
											function(e) {
												e.preventDefault()
												strURL = $(this).attr("href")
												$("#link").html(
														'<em style="text-decoration: underline;">'
																+ strURL
																+ "</em>")
												$("#dialog").dialog("open")
											})
								})

				$('#loading').fadeOut()

			}, 1000)

	$("#dialog").dialog({
		autoOpen : false,
		resizable : false,
		height : "auto",
		modal : true,
		show : {
			effect : "fade",
			duration : 1E3
		},
		hide : {
			effect : "fade",
			duration : 1E3
		},
		buttons : {
			"Continue" : function() {
				$(this).dialog("close")
				window.open(strURL)
			},
			Cancel : function() {
				$(this).dialog("close")
			}
		}
	});
});

var table = $('#sortable-table');

$('#sort-name, #sort-agency').css("cursor", "pointer").wrapInner(
		'<span class="explode" title="Click to sort this column"/>').each(
		function() {

			var th = $(this), thIndex = th.index(), inverse = false, caret
			th.bind("click", function() {

				table.find('td').filter(function() {

					return $(this).index() === thIndex

				}).sortElements(
						function(a, b) {

							return $.text([ a ]) > $.text([ b ]) ? inverse ? -1
									: 1 : inverse ? 1 : -1

						}, function() {

							// parentNode is the element we want to move
							return this.parentNode;

						});

				if (inverse == true)
					caret = "icon-sort-up"
				else
					caret = "icon-sort-down"

				$(this).find(".icon-stack").html(
						'<i class="icon-sort" style="color: #AAA;"></i>'
								+ '<i class="' + caret + '"></i>');

				inverse = !inverse

			});

		});
