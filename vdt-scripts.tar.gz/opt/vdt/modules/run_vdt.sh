export VII_DATA=/opt/vdt/data

./run_probe_message_dataset_manager.py
