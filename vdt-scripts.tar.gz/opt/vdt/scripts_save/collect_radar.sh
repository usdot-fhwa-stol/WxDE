#!/bin/bash

vdt_root=/opt/vdt
radar_input=$vdt_root/data/raw/radar/binary/mosaic2d
radar_output=$vdt_root/data/raw/radar/netcdf/mosaic2d
radar2nc_script=$vdt_root/ingest/radar
interval=120

updateTime() {
        current_date="$(date +'%Y%m%d')"
        current_time="$(date +'%H%M%S')"
        printf "Current time: $current_date $current_time, "
        now="$(date +'%s')"
        let remainder=($interval - $now % $interval)
        printf "wait for $remainder seconds\n"
        sleep $remainder
        current_date="$(date --date="4 minutes ago" +'%Y%m%d')"
        current_minute="$(date --date="4 minutes ago" +'%H%M')"
	old_folder="$(date --date="4 days ago" +'%Y%m%d')"
	if [ -d "$radar_input/$old_folder" ]; then
		printf "removing $radar_input/$old_folder"
		rm -r "$radar_input/$old_folder"
	fi
	if [ -d "$radar_output/$old_folder" ]; then
		printf "removing $radar_output/$old_folder"
		rm -r "$radar_output/$old_folder"
	fi
}

printf "Begin radar data collector - " 
updateTime

while :
do
	ifile1="$radar_input/$current_date/CREF.2d.tile1.$current_date.$current_minute.gz"
	ifile2="$radar_input/$current_date/CREF.2d.tile2.$current_date.$current_minute.gz"
	ifile3="$radar_input/$current_date/CREF.2d.tile3.$current_date.$current_minute.gz"
	ifile4="$radar_input/$current_date/CREF.2d.tile4.$current_date.$current_minute.gz"

	printf "converting $ifile1, $ifile2, $ifile3, $ifile4 to NetCDF\n"
	cd $radar2nc_script 
	./nssl_binary_to_netcdf4.py $ifile1 
	./nssl_binary_to_netcdf4.py $ifile2 
	./nssl_binary_to_netcdf4.py $ifile3 
	./nssl_binary_to_netcdf4.py $ifile4 
	cd $vdt_root

	updateTime
done
