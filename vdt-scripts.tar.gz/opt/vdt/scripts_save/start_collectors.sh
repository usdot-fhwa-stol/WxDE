#!/bin/bash
sudo nohup ./collect_mn_imo.sh > collectors.out 2>collectors.err &
printf "Starting IMO Collector\n"

sudo nohup ./collect_metar.sh > collectors.out 2>collectors.err &
printf "Starting METAR Collector\n"

sudo nohup ./collect_radar.sh > collectors.out 2>collectors.err &
printf "Starting RADAR Collector\n"

sudo nohup ./collect_rtma.sh > collectors.out 2>collectors.err &
printf "Starting RTMA Collector\n"
