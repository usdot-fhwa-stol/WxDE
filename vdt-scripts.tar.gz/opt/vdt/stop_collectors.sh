#!/bin/bash

sudo kill -9 `ps -aef|grep imo|grep -v grep|awk '{print $2}'`
printf "Stopped IMO Collector\n"

sudo kill -9 `ps -aef|grep metar|grep -v grep|awk '{print $2}'`
printf "Stopped METAR Collector\n"

sudo kill -9 `ps -aef|grep radar|grep -v grep|awk '{print $2}'`
printf "Stopped RADAR Collector\n"

sudo kill -9 `ps -aef|grep rtma|grep -v grep|awk '{print $2}'`
printf "Stopped RTMA Collector\n"

