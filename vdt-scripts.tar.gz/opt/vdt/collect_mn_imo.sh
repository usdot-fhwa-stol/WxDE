rm /opt/vdt/data/raw/IMO/MN/heartbeat.bin
rm /opt/vdt/data/raw/IMO/MN/error.log
java -cp /opt/vdt/wde.jar:/opt/vdt/lib/log4j-1.2.13.jar:/opt/vdt/lib/netcdfAll-4.0.jar wde.cs.imo.MnDot 207.67.22.117 4501 5 /opt/vdt/data/raw/IMO/MN/ ameritrak
