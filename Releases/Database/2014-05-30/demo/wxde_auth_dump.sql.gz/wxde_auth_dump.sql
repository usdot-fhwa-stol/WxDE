--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: wxde
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO wxde;

SET search_path = auth, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: country; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE country (
    country_code character(2) NOT NULL,
    country_name character varying(50) NOT NULL
);


ALTER TABLE auth.country OWNER TO wxde;

--
-- Name: feedback; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE feedback (
    id integer NOT NULL,
    name character varying(100),
    email character varying(100) NOT NULL,
    section character varying(100) NOT NULL,
    description character varying(500) NOT NULL,
    feedback_type_id integer NOT NULL,
    user_name character varying(15),
    date_created date,
    timestamp_created timestamp without time zone
);


ALTER TABLE auth.feedback OWNER TO wxde;

--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: auth; Owner: wxde
--

CREATE SEQUENCE feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.feedback_id_seq OWNER TO wxde;

--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: wxde
--

ALTER SEQUENCE feedback_id_seq OWNED BY feedback.id;


--
-- Name: feedback_type; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE feedback_type (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE auth.feedback_type OWNER TO wxde;

--
-- Name: feedback_type_id_seq; Type: SEQUENCE; Schema: auth; Owner: wxde
--

CREATE SEQUENCE feedback_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.feedback_type_id_seq OWNER TO wxde;

--
-- Name: feedback_type_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: wxde
--

ALTER SEQUENCE feedback_type_id_seq OWNED BY feedback_type.id;


--
-- Name: organization_type; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE organization_type (
    organization_type character varying(32) NOT NULL,
    organization_type_name character varying(32) NOT NULL
);


ALTER TABLE auth.organization_type OWNER TO wxde;

--
-- Name: user_role; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE user_role (
    user_name character varying(15) NOT NULL,
    user_role character varying(15) NOT NULL
);


ALTER TABLE auth.user_role OWNER TO wxde;

--
-- Name: user_table; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE user_table (
    user_name character varying(15) NOT NULL,
    user_password character varying(100) NOT NULL,
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    organization character varying(32) NOT NULL,
    organization_type character varying(32) NOT NULL,
    country character varying(2) NOT NULL,
    email character varying(50) NOT NULL,
    password_guid character varying(100),
    guid character varying(100),
    verified boolean,
    date_created date,
    date_password_reset date
);


ALTER TABLE auth.user_table OWNER TO wxde;

--
-- Name: id; Type: DEFAULT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback ALTER COLUMN id SET DEFAULT nextval('feedback_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback_type ALTER COLUMN id SET DEFAULT nextval('feedback_type_id_seq'::regclass);


--
-- Data for Name: country; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY country (country_code, country_name) FROM stdin;
US	United States
CA	Canada
AF	Afghanistan
AL	Albania
DZ	Algeria
AS	American Samoa
AD	Andorra
AO	Angola
AI	Anguilla
AQ	Antarctica
AG	Antigua And Barbuda
AR	Argentina
AM	Armenia
AW	Aruba
AU	Australia
AT	Austria
AZ	Azerbaijan
BS	Bahamas
BH	Bahrain
BD	Bangladesh
BB	Barbados
BY	Belarus
BE	Belgium
BZ	Belize
BJ	Benin
BM	Bermuda
BT	Bhutan
BO	Bolivia
BA	Bosnia And Herzegovina
BW	Botswana
BV	Bouvet Island
BR	Brazil
IO	British Indian Ocean Territory
BN	Brunei Darussalam
BG	Bulgaria
BF	Burkina Faso
BI	Burundi
KH	Cambodia
CM	Cameroon
CV	Cape Verde
KY	Cayman Islands
CF	Central African Republic
TD	Chad
CL	Chile
CN	China
CX	Christmas Island
CC	Cocos (keeling) Islands
CO	Colombia
KM	Comoros
CG	Congo
CD	Congo, The Democratic Republic Of The
CK	Cook Islands
CR	Costa Rica
CI	Cote D'ivoire
HR	Croatia
CU	Cuba
CY	Cyprus
CZ	Czech Republic
DK	Denmark
DJ	Djibouti
DM	Dominica
DO	Dominican Republic
TP	East Timor
EC	Ecuador
EG	Egypt
SV	El Salvador
GQ	Equatorial Guinea
ER	Eritrea
EE	Estonia
ET	Ethiopia
FK	Falkland Islands (malvinas)
FO	Faroe Islands
FJ	Fiji
FI	Finland
FR	France
GF	French Guiana
PF	French Polynesia
TF	French Southern Territories
GA	Gabon
GM	Gambia
GE	Georgia
DE	Germany
GH	Ghana
GI	Gibraltar
GR	Greece
GL	Greenland
GD	Grenada
GP	Guadeloupe
GU	Guam
GT	Guatemala
GN	Guinea
GW	Guinea-bissau
GY	Guyana
HT	Haiti
HM	Heard Island And Mcdonald Islands
VA	Holy See (vatican City State)
HN	Honduras
HK	Hong Kong
HU	Hungary
IS	Iceland
IN	India
ID	Indonesia
IQ	Iraq
IE	Ireland
IL	Israel
IT	Italy
JM	Jamaica
JP	Japan
JO	Jordan
KZ	Kazakstan
KE	Kenya
KI	Kiribati
KR	Korea, Republic Of
KV	Kosovo
KW	Kuwait
KG	Kyrgyzstan
LA	Lao People's Democratic Republic
LV	Latvia
LB	Lebanon
LS	Lesotho
LR	Liberia
LY	Libyan Arab Jamahiriya
LI	Liechtenstein
LT	Lithuania
LU	Luxembourg
MO	Macau
MK	Macedonia, The Former Yugoslav Republic Of
MG	Madagascar
MW	Malawi
MY	Malaysia
MV	Maldives
ML	Mali
MT	Malta
MH	Marshall Islands
MQ	Martinique
MR	Mauritania
MU	Mauritius
YT	Mayotte
MX	Mexico
FM	Micronesia, Federated States Of
MD	Moldova, Republic Of
MC	Monaco
MN	Mongolia
ME	Montenegro
MS	Montserrat
MA	Morocco
MZ	Mozambique
MM	Myanmar
NA	Namibia
NR	Nauru
NP	Nepal
NL	Netherlands
AN	Netherlands Antilles
NC	New Caledonia
NZ	New Zealand
NI	Nicaragua
NE	Niger
NG	Nigeria
NU	Niue
NF	Norfolk Island
MP	Northern Mariana Islands
NO	Norway
OM	Oman
PK	Pakistan
PW	Palau
PS	Palestinian Territory, Occupied
PA	Panama
PG	Papua New Guinea
PY	Paraguay
PE	Peru
PH	Philippines
PN	Pitcairn
PL	Poland
PT	Portugal
PR	Puerto Rico
QA	Qatar
RE	Reunion
RO	Romania
RU	Russian Federation
RW	Rwanda
SH	Saint Helena
KN	Saint Kitts And Nevis
LC	Saint Lucia
PM	Saint Pierre And Miquelon
VC	Saint Vincent And The Grenadines
WS	Samoa
SM	San Marino
ST	Sao Tome And Principe
SA	Saudi Arabia
SN	Senegal
SC	Seychelles
RS	Serbia
SL	Sierra Leone
SG	Singapore
SK	Slovakia
SI	Slovenia
SB	Solomon Islands
SO	Somalia
ZA	South Africa
SS	South Sudan
GS	South Georgia And The South Sandwich Islands
ES	Spain
LK	Sri Lanka
SD	Sudan
SR	Suriname
SJ	Svalbard And Jan Mayen
SZ	Swaziland
SE	Sweden
CH	Switzerland
TW	Taiwan, Province Of China
TJ	Tajikistan
TZ	Tanzania, United Republic Of
TH	Thailand
TG	Togo
TK	Tokelau
TO	Tonga
TT	Trinidad And Tobago
TN	Tunisia
TR	Turkey
TM	Turkmenistan
TC	Turks And Caicos Islands
TV	Tuvalu
UG	Uganda
UA	Ukraine
AE	United Arab Emirates
GB	United Kingdom
UM	United States Minor Outlying Islands
UY	Uruguay
UZ	Uzbekistan
VU	Vanuatu
VE	Venezuela
VN	Viet Nam
VG	Virgin Islands, British
VI	Virgin Islands, U.s.
WF	Wallis And Futuna
EH	Western Sahara
YE	Yemen
ZM	Zambia
ZW	Zimbabwe
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY feedback (id, name, email, section, description, feedback_type_id, user_name, date_created, timestamp_created) FROM stdin;
5	\N	boyce_brenda@bah.com	http://74.254.188.196/wdeMap.jsp?lat=46&lon=-92.8&zoom=7	Using IE - Error on page\nRe-center map on . . . not available\nSelect Data to Show - not available 	1	\N	\N	\N
7	Bobby Haas	haasr@saic.com	http://74.254.188.196/auth/reports.jsp	The wdeMap page allows me to view observations from Virginia when I haven’t logged in, even though Virginia is shown as a data restricted state on the data map screen.	3	bobbyhaas	\N	\N
26	Chuckerin Black	chuckerin.black@saic.com	http://74.254.188.196/auth/newMetadata.jsp	test ie8 as of 10/16/2013	1	jedi	\N	\N
27	Gene McHale	gene.mchale@dot.gov	http://74.254.188.196/auth/newWizardTimeRange.jsp	Running a Data Query... After running a data query and using the back button to return to the page to specify the date and time for another query, the "End Time" is reset to "0100".  The "Start Time" seems to keep the value of the most recent query, but the "End Time" is reset.  I think the "End Time" should also retain the value from the most recent query if you use the back button to return to the query page.	1	gmchale	\N	\N
28	Gene McHale	gene.mchale@dot.gov	http://74.254.188.196/auth/newWizardTimeRange.jsp#	Query Defaults... The default "Start Time" and "End Time" are 0000 and 0100.  Should the default "End Time" be 2300 ?	1	gmchale	\N	\N
29	Gene McHale	gene.mchale@dot.gov	http://74.254.188.196/auth/newWizardGeospatial.jsp	Selecting Data -> Coordinates.... results in a pop up window that says "Stack overflow at line 77"	1	gmchale	\N	\N
30	Gene McHale	gene.mchale@dot.gov	http://74.254.188.196/auth/dataSourceMD.jsp	Under "About" -> "Data Sources"....  How is the information in the table sorted for presentation to the user?  It is not currently sorted alphabetically.	1	gmchale	\N	\N
31	Gene McHale	gene.mchale@dot.gov	http://74.254.188.196/auth/newWizardStations.jsp	From the "Data" -> "Observations" -> "Contributor"... After selecting a contributor, a page with "Select Platforms" is shown with a table of platforms.  How are these platforms sorted for presentation to the user?  They are not currently sorted alphabetically.	1	gmchale	\N	\N
32	Gene McHale	gene.mchale@dot.gov	http://74.254.188.196/	WxDE "logo".... We need to discuss as a group the need for a logo.  We had some feedback from the TFHRC webmaster that in general, we're trying to get away from program specific logos.  If we do plan on keeping the logo, the "pentagon" with the small icons is OK, but I'm not sure I understand why we need the row of individual icons below.	1	gmchale	\N	\N
34	Gabe Guevara	gabriel.guevara@dot.gov	http://74.254.188.196/auth/newWizardGeospatial.jsp	I clicked on Coordinates and got\n"Stack Overflow at Line 77"	1	Gabe Guevara	\N	\N
33	Gabe Guevara	gabriel.guevara@dot.gov	http://74.254.188.196/termsOfUse.jsp#	I tried to retrieve my password; the system told me that an e-mail was sent to me- it's been like 15 min and no e-mail yet....	1	Gabe Guevara	\N	\N
35	Chuckerin Black	chuckerin.black@saic.com	http://wxdedemo.leidoshost.com/auth/feedbacks.jsp#	test	1	chuckerin	2013-11-27	2013-11-27 17:31:02.431
\.


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: wxde
--

SELECT pg_catalog.setval('feedback_id_seq', 35, true);


--
-- Data for Name: feedback_type; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY feedback_type (id, name) FROM stdin;
1	Feedback
2	New Feature
4	Data Bug
5	Broken Link Bug
3	UI Bug
\.


--
-- Name: feedback_type_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: wxde
--

SELECT pg_catalog.setval('feedback_type_id_seq', 5, true);


--
-- Data for Name: organization_type; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY organization_type (organization_type, organization_type_name) FROM stdin;
PRIVPROFIT	Private for profit
LOCGOV	Local Government
STATEGOV	State Government
FEDGOV	Federal Government
UNIVERSITY	University
OTHER	Other
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY user_role (user_name, user_role) FROM stdin;
zheng	wde_admin
zheng	wde_user
chuckerin	wde_user
jedi	wde_user
bobbyhaas	wde_user
bobbyhaas	wde_admin
Ianculescu	wde_user
Brenda Boyce	wde_user
Gabe Guevara	wde_user
jedi	wde_admin
gmchale	wde_user
rdouglas	wde_user
chuckerin	wde_admin
jkgarrett	wde_user
jkgarrett	wde_admin
weather2go	wde_user
ppisano	wde_user
gmchale	wde_admin
Daniel Stock	wde_user
Gabe Guevara	wde_admin
ppisano	wde_admin
dsims	wde_user
vader	wde_user
Phillipsthom	wde_user
BobbyHaasTest	wde_user
rothie	wde_user
leighsturges	wde_user
leighsturges	wde_admin
Ralph Patterson	wde_user
Ralph Patterson	wde_admin
RDEGuest	wde_user
Brenda Boyce	wde_admin
\.


--
-- Data for Name: user_table; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY user_table (user_name, user_password, first_name, last_name, organization, organization_type, country, email, password_guid, guid, verified, date_created, date_password_reset) FROM stdin;
jedi	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Luke	Skywalker	Jedi Council	PRIVPROFIT	US	jedi@jedi.com	\N	\N	\N	\N	\N
chuckerin12	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Chuck	Black	SAIC	PRIVPROFIT	CA	chuckerin@gmail.com	\N	\N	\N	\N	\N
Ianculescu	151d3c61de2fb6da3eee5ab1f56b5d419f8488aaf999472cf41b107d468e1f8c	Cristian	Ianculescu	Booz Allen Hamilton	PRIVPROFIT	US	ianculescu_cristian@bah.com	\N	\N	\N	\N	\N
Brenda Boyce	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Brenda	Boyce	Booz Allen	PRIVPROFIT	US	boyce_brenda@bah.com	\N	\N	\N	\N	\N
gmchale	b2fa92507ddb21f84a361790bc7d8ee86f60e1755f1ecd6aaa7680eb073c9528	Gene	McHale	FHWA	FEDGOV	US	gene.mchale@dot.gov	\N	\N	\N	\N	\N
RDEGuest	a7933ba058dd0f081f77f436b41244c2b9f21a70d14b436c56f76490b01650f8	Saman	Moshafi	Indrasoft	PRIVPROFIT	US	saman.moshafi@indrasoft.com	\N	\N	t	\N	\N
rdouglas	fb3fecb912197501f75e9e0a9a110930679c7b6d1499be71cfdee871f8ef95e3	Ray	Douglass	UMD CATT Lab	UNIVERSITY	US	rdouglas@umd.edu	\N	\N	\N	\N	\N
jkgarrett	1e55ce0038b9944cebf55b3341fcb329c013e8acc6af99cc17be0f0797caf8b4	Kyle	Garrett	Synesis Partners LLC	PRIVPROFIT	US	kyle.garrett@synesis-partners.com	\N	\N	\N	\N	\N
weather2go	2fc60fd7cb27fcad18571c6649754560b10787ca4c4ac44f11dd9e9d11f6414f	Bob	Hart	Iteris	PRIVPROFIT	US	rdh@iteris.com	\N	\N	\N	\N	\N
ppisano	76ab10716e9995e8256e5b6e654b27d5822d6f200a34499fce87ec335f130b0c	Paul	Pisano	FHWA	FEDGOV	US	paul.pisano@dot.gov	\N	\N	\N	\N	\N
Daniel Stock	e9ab86a8435195fc1f1205a8836ac5d4aefe783dc7d7f02e5f1542d6aec4fab9	Daniel	Stock	Leidos Corp	PRIVPROFIT	US	stockd@leidos.com	\N	\N	\N	\N	\N
vader	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Anakin	Skywalker	Justice League	PRIVPROFIT	US	chuckerin@gmail.com	\N	631f3db8-db41-4c15-baf3-20c3e93ec7d0	f	\N	\N
bobbyhaas	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Bobby	Haas	Leidos	PRIVPROFIT	US	haasr@leidos.com	16e4e030-9ad3-43ab-b32b-e278914ddf94	\N	\N	\N	2014-01-02
Gabe Guevara	35dbf947490b9c731b0766c786e6bd6f1817a178f17dd8d38cac45bfe9b32ab7	Gabriel	Guevara	FHWA	FEDGOV	US	gabriel.guevara@dot.gov	\N	\N	\N	\N	\N
rothie	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Robert	Roth	Leidos	PRIVPROFIT	US	rothattack@gmail.com	7b81c181-2b59-4bf4-b406-abe3ab69df8e	\N	t	\N	2014-04-03
zheng	da53550b3fd24b14dd4ceb9e53d7381c39dcd3bcd2422a49ed4ba7bdfa084f75	George	Zheng	Leidos	PRIVPROFIT	US	GEORGE.ZHENG@leidos.com	06d0a9d8-d758-45b1-a72e-d204a8aab11f	\N	\N	\N	2014-01-02
chuckerin	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Chuckerin	Black	Leidos	PRIVPROFIT	US	chuckerin.black@leidos.com	a0893b63-bac0-4ca1-8bf3-af4fa93ed5ba	\N	\N	\N	2013-12-11
dsims	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	De'Von	Sims	Leidos	PRIVPROFIT	US	devon.l.sims@leidos.com	\N	\N	t	\N	\N
Phillipsthom	484205eefd5b886e8eb84f6f28d63d3a65a1b5b64840d2e9d08cdf79a45fccb2	Tom	Phillips	Leidos	PRIVPROFIT	US	thomas.h.phillips@leidos.com	\N	\N	t	\N	\N
BobbyHaasTest	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Bobby	Haas	Leidos	PRIVPROFIT	US	haasr@saic.com	\N	\N	t	\N	\N
leighsturges	1418c978580dc7bac8f85212da3c9dfc0950149de173b48cbc1d340d2e479a24	Leigh	Sturges	Narwhal Group	PRIVPROFIT	US	leigh.sturges@narwhalgroup.com	\N	\N	t	\N	\N
Ralph Patterson	9f4af22abc9623b3bee3385c69d3da3ec8828f914d3e90108ab844fdbb53c2a0	Ralph	Patterson	Narwhal Group /FHWA Consultant 	PRIVPROFIT	US	Ralph@narwhalmet.com	\N	\N	t	\N	\N
\.


--
-- Name: PK_USER_ROLE; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT "PK_USER_ROLE" PRIMARY KEY (user_name, user_role);


--
-- Name: pk_country_code; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT pk_country_code PRIMARY KEY (country_code);


--
-- Name: pk_feedback_id; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT pk_feedback_id PRIMARY KEY (id);


--
-- Name: pk_id; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY feedback_type
    ADD CONSTRAINT pk_id PRIMARY KEY (id);


--
-- Name: pk_organization_type; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY organization_type
    ADD CONSTRAINT pk_organization_type PRIMARY KEY (organization_type);


--
-- Name: pk_username; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY user_table
    ADD CONSTRAINT pk_username PRIMARY KEY (user_name);


--
-- Name: fki_country; Type: INDEX; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE INDEX fki_country ON user_table USING btree (country);


--
-- Name: fki_organization_type; Type: INDEX; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE INDEX fki_organization_type ON user_table USING btree (organization_type);


--
-- Name: FK_USER_ROLE; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT "FK_USER_ROLE" FOREIGN KEY (user_name) REFERENCES user_table(user_name);


--
-- Name: fk_country; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY user_table
    ADD CONSTRAINT fk_country FOREIGN KEY (country) REFERENCES country(country_code);


--
-- Name: fk_feedback_type_id; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT fk_feedback_type_id FOREIGN KEY (feedback_type_id) REFERENCES feedback_type(id);


--
-- Name: fk_organization_type; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY user_table
    ADD CONSTRAINT fk_organization_type FOREIGN KEY (organization_type) REFERENCES organization_type(organization_type);


--
-- Name: fk_user_name; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT fk_user_name FOREIGN KEY (user_name) REFERENCES user_table(user_name);


--
-- Name: auth; Type: ACL; Schema: -; Owner: wxde
--

REVOKE ALL ON SCHEMA auth FROM PUBLIC;
REVOKE ALL ON SCHEMA auth FROM wxde;
GRANT ALL ON SCHEMA auth TO wxde;


--
-- PostgreSQL database dump complete
--

