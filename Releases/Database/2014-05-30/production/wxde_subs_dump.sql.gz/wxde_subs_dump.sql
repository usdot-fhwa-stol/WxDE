--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: subs; Type: SCHEMA; Schema: -; Owner: wxde
--

CREATE SCHEMA subs;


ALTER SCHEMA subs OWNER TO wxde;

SET search_path = subs, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: subcontrib; Type: TABLE; Schema: subs; Owner: wxde; Tablespace: 
--

CREATE TABLE subcontrib (
    subid integer DEFAULT 0 NOT NULL,
    contribid integer DEFAULT 0 NOT NULL
);


ALTER TABLE subs.subcontrib OWNER TO wxde;

--
-- Name: subradius; Type: TABLE; Schema: subs; Owner: wxde; Tablespace: 
--

CREATE TABLE subradius (
    subid integer DEFAULT 0 NOT NULL,
    lat integer DEFAULT 0 NOT NULL,
    lng integer DEFAULT 0 NOT NULL,
    radius integer DEFAULT 0 NOT NULL
);


ALTER TABLE subs.subradius OWNER TO wxde;

--
-- Name: subscription; Type: TABLE; Schema: subs; Owner: wxde; Tablespace: 
--

CREATE TABLE subscription (
    id integer DEFAULT 0 NOT NULL,
    expires timestamp without time zone DEFAULT '2010-01-01 00:00:00'::timestamp without time zone NOT NULL,
    lat1 integer,
    lng1 integer,
    lat2 integer,
    lng2 integer,
    obstypeid integer,
    minvalue double precision,
    maxvalue double precision,
    qchrun integer,
    qchflags integer,
    password character varying(15) DEFAULT ''::character varying NOT NULL,
    format character varying(8) DEFAULT 'CSV'::character varying NOT NULL,
    cycle smallint DEFAULT (20)::smallint NOT NULL,
    contactname character varying(64) DEFAULT NULL::character varying,
    contactemail character varying(128) DEFAULT NULL::character varying,
    owner_name character varying(15) DEFAULT ''::character varying NOT NULL,
    ispublic smallint DEFAULT (0)::smallint NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500)
);


ALTER TABLE subs.subscription OWNER TO wxde;

--
-- Name: substation; Type: TABLE; Schema: subs; Owner: wxde; Tablespace: 
--

CREATE TABLE substation (
    subid integer DEFAULT 0 NOT NULL,
    stationid integer DEFAULT 0 NOT NULL
);


ALTER TABLE subs.substation OWNER TO wxde;

--
-- Name: subuser; Type: TABLE; Schema: subs; Owner: wxde; Tablespace: 
--

CREATE TABLE subuser (
    subid integer DEFAULT 0 NOT NULL,
    user_name character varying(15) NOT NULL
);


ALTER TABLE subs.subuser OWNER TO wxde;

--
-- Data for Name: subcontrib; Type: TABLE DATA; Schema: subs; Owner: wxde
--

COPY subcontrib (subid, contribid) FROM stdin;
2013111100	2
\.


--
-- Data for Name: subradius; Type: TABLE DATA; Schema: subs; Owner: wxde
--

COPY subradius (subid, lat, lng, radius) FROM stdin;
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: subs; Owner: wxde
--

COPY subscription (id, expires, lat1, lng1, lat2, lng2, obstypeid, minvalue, maxvalue, qchrun, qchflags, password, format, cycle, contactname, contactemail, owner_name, ispublic, name, description) FROM stdin;
2013111100	2014-06-13 19:01:01.397	\N	\N	\N	\N	0	\N	\N	\N	\N	123456	CSV	60	George Zheng	GEORGE.ZHENG@leidos.com		0	VDT Subscription	\N
\.


--
-- Data for Name: substation; Type: TABLE DATA; Schema: subs; Owner: wxde
--

COPY substation (subid, stationid) FROM stdin;
2013111100	42
2013111100	43
2013111100	44
2013111100	45
2013111100	46
2013111100	47
2013111100	48
2013111100	49
2013111100	50
2013111100	51
2013111100	52
2013111100	53
2013111100	54
2013111100	55
2013111100	56
2013111100	57
2013111100	58
2013111100	59
2013111100	60
2013111100	61
2013111100	62
2013111100	63
2013111100	64
2013111100	65
2013111100	66
2013111100	67
2013111100	68
2013111100	69
2013111100	70
2013111100	71
2013111100	72
2013111100	73
2013111100	74
2013111100	75
2013111100	76
2013111100	77
2013111100	78
2013111100	79
2013111100	80
2013111100	81
2013111100	82
2013111100	83
2013111100	84
2013111100	85
2013111100	86
2013111100	87
2013111100	88
2013111100	89
2013111100	90
2013111100	91
2013111100	92
2013111100	93
2013111100	94
2013111100	95
2013111100	96
2013111100	97
2013111100	98
2013111100	99
2013111100	100
2013111100	101
2013111100	102
2013111100	103
2013111100	104
2013111100	105
2013111100	106
2013111100	107
2013111100	108
2013111100	109
2013111100	110
2013111100	111
2013111100	112
2013111100	113
2013111100	114
2013111100	115
2013111100	116
2013111100	117
2013111100	118
2013111100	119
2013111100	120
2013111100	121
2013111100	122
2013111100	123
2013111100	124
2013111100	125
2013111100	126
2013111100	127
2013111100	128
2013111100	129
2013111100	130
2013111100	131
2013111100	132
2013111100	133
2013111100	134
2013111100	135
2013111100	5286
2013111100	5287
2013111100	4845
2013111100	4846
2013111100	4847
2013111100	5285
2013111100	5280
2013111100	5282
2013111100	5283
2013111100	5462
2013111100	5463
2013111100	5464
2013111100	5465
2013111100	5466
2013111100	5467
2013111100	5468
2013111100	5469
2013111100	5470
2013111100	5471
2013111100	5472
2013111100	5473
2013111100	4844
2013111100	5255
2013111100	5281
2013111100	5284
\.


--
-- Data for Name: subuser; Type: TABLE DATA; Schema: subs; Owner: wxde
--

COPY subuser (subid, user_name) FROM stdin;
\.


--
-- Name: subcontrib_pkey; Type: CONSTRAINT; Schema: subs; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY subcontrib
    ADD CONSTRAINT subcontrib_pkey PRIMARY KEY (subid, contribid);


--
-- Name: subradius_pkey; Type: CONSTRAINT; Schema: subs; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY subradius
    ADD CONSTRAINT subradius_pkey PRIMARY KEY (subid);


--
-- Name: subscription_pkey; Type: CONSTRAINT; Schema: subs; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: substation_pkey; Type: CONSTRAINT; Schema: subs; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY substation
    ADD CONSTRAINT substation_pkey PRIMARY KEY (subid, stationid);


--
-- Name: subuser_pkey; Type: CONSTRAINT; Schema: subs; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY subuser
    ADD CONSTRAINT subuser_pkey PRIMARY KEY (subid, user_name);


--
-- Name: subs; Type: ACL; Schema: -; Owner: wxde
--

REVOKE ALL ON SCHEMA subs FROM PUBLIC;
REVOKE ALL ON SCHEMA subs FROM wxde;
GRANT ALL ON SCHEMA subs TO wxde;


--
-- Name: subcontrib; Type: ACL; Schema: subs; Owner: wxde
--

REVOKE ALL ON TABLE subcontrib FROM PUBLIC;
REVOKE ALL ON TABLE subcontrib FROM wxde;
GRANT ALL ON TABLE subcontrib TO wxde;
GRANT SELECT ON TABLE subcontrib TO wxdero;


--
-- Name: subradius; Type: ACL; Schema: subs; Owner: wxde
--

REVOKE ALL ON TABLE subradius FROM PUBLIC;
REVOKE ALL ON TABLE subradius FROM wxde;
GRANT ALL ON TABLE subradius TO wxde;
GRANT SELECT ON TABLE subradius TO wxdero;


--
-- Name: subscription; Type: ACL; Schema: subs; Owner: wxde
--

REVOKE ALL ON TABLE subscription FROM PUBLIC;
REVOKE ALL ON TABLE subscription FROM wxde;
GRANT ALL ON TABLE subscription TO wxde;
GRANT SELECT ON TABLE subscription TO wxdero;


--
-- Name: substation; Type: ACL; Schema: subs; Owner: wxde
--

REVOKE ALL ON TABLE substation FROM PUBLIC;
REVOKE ALL ON TABLE substation FROM wxde;
GRANT ALL ON TABLE substation TO wxde;
GRANT SELECT ON TABLE substation TO wxdero;


--
-- Name: subuser; Type: ACL; Schema: subs; Owner: wxde
--

REVOKE ALL ON TABLE subuser FROM PUBLIC;
REVOKE ALL ON TABLE subuser FROM wxde;
GRANT ALL ON TABLE subuser TO wxde;


--
-- PostgreSQL database dump complete
--

