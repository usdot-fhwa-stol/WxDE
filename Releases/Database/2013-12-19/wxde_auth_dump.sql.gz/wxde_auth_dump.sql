--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: wxde
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO wxde;

SET search_path = auth, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: country; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE country (
    country_code character(2) NOT NULL,
    country_name character varying(50) NOT NULL
);


ALTER TABLE auth.country OWNER TO wxde;

--
-- Name: feedback; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE feedback (
    id integer NOT NULL,
    name character varying(100),
    email character varying(100) NOT NULL,
    section character varying(100) NOT NULL,
    description character varying(500) NOT NULL,
    feedback_type_id integer NOT NULL,
    user_name character varying(15),
    date_created date,
    timestamp_created timestamp without time zone
);


ALTER TABLE auth.feedback OWNER TO wxde;

--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: auth; Owner: wxde
--

CREATE SEQUENCE feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.feedback_id_seq OWNER TO wxde;

--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: wxde
--

ALTER SEQUENCE feedback_id_seq OWNED BY feedback.id;


--
-- Name: feedback_type; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE feedback_type (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE auth.feedback_type OWNER TO wxde;

--
-- Name: feedback_type_id_seq; Type: SEQUENCE; Schema: auth; Owner: wxde
--

CREATE SEQUENCE feedback_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.feedback_type_id_seq OWNER TO wxde;

--
-- Name: feedback_type_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: wxde
--

ALTER SEQUENCE feedback_type_id_seq OWNED BY feedback_type.id;


--
-- Name: organization_type; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE organization_type (
    organization_type character varying(32) NOT NULL,
    organization_type_name character varying(32) NOT NULL
);


ALTER TABLE auth.organization_type OWNER TO wxde;

--
-- Name: user_role; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE user_role (
    user_name character varying(15) NOT NULL,
    user_role character varying(15) NOT NULL
);


ALTER TABLE auth.user_role OWNER TO wxde;

--
-- Name: user_table; Type: TABLE; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE TABLE user_table (
    user_name character varying(15) NOT NULL,
    user_password character varying(100),
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    organization character varying(32) NOT NULL,
    organization_type character varying(32) NOT NULL,
    country character varying(2) NOT NULL,
    email character varying(50),
    password_guid character varying(100),
    guid character varying(100),
    verified boolean,
    date_created date,
    date_password_reset date
);


ALTER TABLE auth.user_table OWNER TO wxde;

--
-- Name: id; Type: DEFAULT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback ALTER COLUMN id SET DEFAULT nextval('feedback_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback_type ALTER COLUMN id SET DEFAULT nextval('feedback_type_id_seq'::regclass);


--
-- Data for Name: country; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY country (country_code, country_name) FROM stdin;
US	United States
CA	Canada
AF	Afghanistan
AL	Albania
DZ	Algeria
AS	American Samoa
AD	Andorra
AO	Angola
AI	Anguilla
AQ	Antarctica
AG	Antigua And Barbuda
AR	Argentina
AM	Armenia
AW	Aruba
AU	Australia
AT	Austria
AZ	Azerbaijan
BS	Bahamas
BH	Bahrain
BD	Bangladesh
BB	Barbados
BY	Belarus
BE	Belgium
BZ	Belize
BJ	Benin
BM	Bermuda
BT	Bhutan
BO	Bolivia
BA	Bosnia And Herzegovina
BW	Botswana
BV	Bouvet Island
BR	Brazil
IO	British Indian Ocean Territory
BN	Brunei Darussalam
BG	Bulgaria
BF	Burkina Faso
BI	Burundi
KH	Cambodia
CM	Cameroon
CV	Cape Verde
KY	Cayman Islands
CF	Central African Republic
TD	Chad
CL	Chile
CN	China
CX	Christmas Island
CC	Cocos (keeling) Islands
CO	Colombia
KM	Comoros
CG	Congo
CD	Congo, The Democratic Republic Of The
CK	Cook Islands
CR	Costa Rica
CI	Cote D'ivoire
HR	Croatia
CU	Cuba
CY	Cyprus
CZ	Czech Republic
DK	Denmark
DJ	Djibouti
DM	Dominica
DO	Dominican Republic
TP	East Timor
EC	Ecuador
EG	Egypt
SV	El Salvador
GQ	Equatorial Guinea
ER	Eritrea
EE	Estonia
ET	Ethiopia
FK	Falkland Islands (malvinas)
FO	Faroe Islands
FJ	Fiji
FI	Finland
FR	France
GF	French Guiana
PF	French Polynesia
TF	French Southern Territories
GA	Gabon
GM	Gambia
GE	Georgia
DE	Germany
GH	Ghana
GI	Gibraltar
GR	Greece
GL	Greenland
GD	Grenada
GP	Guadeloupe
GU	Guam
GT	Guatemala
GN	Guinea
GW	Guinea-bissau
GY	Guyana
HT	Haiti
HM	Heard Island And Mcdonald Islands
VA	Holy See (vatican City State)
HN	Honduras
HK	Hong Kong
HU	Hungary
IS	Iceland
IN	India
ID	Indonesia
IQ	Iraq
IE	Ireland
IL	Israel
IT	Italy
JM	Jamaica
JP	Japan
JO	Jordan
KZ	Kazakstan
KE	Kenya
KI	Kiribati
KR	Korea, Republic Of
KV	Kosovo
KW	Kuwait
KG	Kyrgyzstan
LA	Lao People's Democratic Republic
LV	Latvia
LB	Lebanon
LS	Lesotho
LR	Liberia
LY	Libyan Arab Jamahiriya
LI	Liechtenstein
LT	Lithuania
LU	Luxembourg
MO	Macau
MK	Macedonia, The Former Yugoslav Republic Of
MG	Madagascar
MW	Malawi
MY	Malaysia
MV	Maldives
ML	Mali
MT	Malta
MH	Marshall Islands
MQ	Martinique
MR	Mauritania
MU	Mauritius
YT	Mayotte
MX	Mexico
FM	Micronesia, Federated States Of
MD	Moldova, Republic Of
MC	Monaco
MN	Mongolia
ME	Montenegro
MS	Montserrat
MA	Morocco
MZ	Mozambique
MM	Myanmar
NA	Namibia
NR	Nauru
NP	Nepal
NL	Netherlands
AN	Netherlands Antilles
NC	New Caledonia
NZ	New Zealand
NI	Nicaragua
NE	Niger
NG	Nigeria
NU	Niue
NF	Norfolk Island
MP	Northern Mariana Islands
NO	Norway
OM	Oman
PK	Pakistan
PW	Palau
PS	Palestinian Territory, Occupied
PA	Panama
PG	Papua New Guinea
PY	Paraguay
PE	Peru
PH	Philippines
PN	Pitcairn
PL	Poland
PT	Portugal
PR	Puerto Rico
QA	Qatar
RE	Reunion
RO	Romania
RU	Russian Federation
RW	Rwanda
SH	Saint Helena
KN	Saint Kitts And Nevis
LC	Saint Lucia
PM	Saint Pierre And Miquelon
VC	Saint Vincent And The Grenadines
WS	Samoa
SM	San Marino
ST	Sao Tome And Principe
SA	Saudi Arabia
SN	Senegal
SC	Seychelles
RS	Serbia
SL	Sierra Leone
SG	Singapore
SK	Slovakia
SI	Slovenia
SB	Solomon Islands
SO	Somalia
ZA	South Africa
SS	South Sudan
GS	South Georgia And The South Sandwich Islands
ES	Spain
LK	Sri Lanka
SD	Sudan
SR	Suriname
SJ	Svalbard And Jan Mayen
SZ	Swaziland
SE	Sweden
CH	Switzerland
TW	Taiwan, Province Of China
TJ	Tajikistan
TZ	Tanzania, United Republic Of
TH	Thailand
TG	Togo
TK	Tokelau
TO	Tonga
TT	Trinidad And Tobago
TN	Tunisia
TR	Turkey
TM	Turkmenistan
TC	Turks And Caicos Islands
TV	Tuvalu
UG	Uganda
UA	Ukraine
AE	United Arab Emirates
GB	United Kingdom
UM	United States Minor Outlying Islands
UY	Uruguay
UZ	Uzbekistan
VU	Vanuatu
VE	Venezuela
VN	Viet Nam
VG	Virgin Islands, British
VI	Virgin Islands, U.s.
WF	Wallis And Futuna
EH	Western Sahara
YE	Yemen
ZM	Zambia
ZW	Zimbabwe
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY feedback (id, name, email, section, description, feedback_type_id, user_name, date_created, timestamp_created) FROM stdin;
1	\N	george.zheng@saic.com	http://10.10.10.28/wdeMap.jsp?lat=46&lon=-108&zoom=4	first test	1	\N	\N	\N
2	\N	GEORGE.ZHENG@saic.com	http://10.10.10.28/index.jsp	second test	1	\N	\N	\N
3	Luke Skywalker	jedi@jedi.com	http://10.10.10.28/auth/feedbacks.jsp#	Never gonna give you up..\nNever gonna let you down..\nNever gonna turn around,\nAnd dessert you, yum yum.	1	jedi	\N	\N
5	HAHAHA I AM NOT LOGGED IN	email@business.comssss	http://10.10.10.28/auth/newSubscriptions.jsp	An preost wes on leoden, Laȝamon was ihoten\nHe wes Leovenaðes sone -- liðe him be Drihten.\nHe wonede at Ernleȝe at æðelen are chirechen,\nUppen Sevarne staþe, sel þar him þuhte,\nOnfest Radestone, þer he bock radde. 	1	\N	\N	\N
6	Mohammed Mohammed Smith	jah@jah.com	http://10.10.10.28/userAccountRetrieval.jsp	ಬಾ ಇಲ್ಲಿ ಸಂಭವಿಸು ಇಂದೆನ್ನ ಹೃದಯದಲಿ\nನಿತ್ಯವೂ ಅವತರಿಪ ಸತ್ಯಾವತಾರ\n\nಮಣ್ಣಾಗಿ ಮರವಾಗಿ ಮಿಗವಾಗಿ ಕಗವಾಗೀ...\nಮಣ್ಣಾಗಿ ಮರವಾಗಿ ಮಿಗವಾಗಿ ಕಗವಾಗಿ\nಭವ ಭವದಿ ಭತಿಸಿಹೇ ಭವತಿ ದೂರ\nನಿತ್ಯವೂ ಅವತರಿಪ ಸತ್ಯಾವತಾರ || ಬಾ ಇಲ್ಲಿ || 	1	\N	\N	\N
7		asdf@asdf.com	http://10.10.10.28/dataMap.jsp	refffgdsafgdsfgdsaf	1	\N	\N	\N
8	Chuckerin Black	chuckerin.black@saic.com	http://10.10.10.28/auth/feedbacks.jsp	fghyjytjyth	1	chuckerin	\N	\N
9	Chuckerin Black	chuckerin.black@saic.com	http://10.10.10.28/auth/feedbacks.jsp	trhfgh	1	chuckerin	\N	\N
\.


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: wxde
--

SELECT pg_catalog.setval('feedback_id_seq', 9, true);


--
-- Data for Name: feedback_type; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY feedback_type (id, name) FROM stdin;
1	Feedback
2	New Feature
4	Data Bug
5	Broken Link Bug
3	UI Bug
\.


--
-- Name: feedback_type_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: wxde
--

SELECT pg_catalog.setval('feedback_type_id_seq', 5, true);


--
-- Data for Name: organization_type; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY organization_type (organization_type, organization_type_name) FROM stdin;
PRIVPROFIT	Private for profit
LOCGOV	Local Government
STATEGOV	State Government
FEDGOV	Federal Government
UNIVERSITY	University
OTHER	Other
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY user_role (user_name, user_role) FROM stdin;
zheng	wde_admin
zheng	wde_user
wde_user	wde_user
wde_admin	wde_user
wde_admin	wde_admin
user1	wde_user
chuckerin	wde_user
jedi	wde_user
bobbyhaas	wde_user
bobbyhaas	wde_admin
booboo	wde_user
chuckerin	wde_admin
jedi	wde_admin
dsims	wde_user
sam	wde_user
vader	wde_user
Mruno Bars	wde_user
Jimmmy	wde_user
Spam	wde_user
\.


--
-- Data for Name: user_table; Type: TABLE DATA; Schema: auth; Owner: wxde
--

COPY user_table (user_name, user_password, first_name, last_name, organization, organization_type, country, email, password_guid, guid, verified, date_created, date_password_reset) FROM stdin;
wde_admin	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	wde	admin	DOT	FEDGOV	US	admin@somewhere.com	\N	\N	\N	\N	\N
wde_user	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	wde	user	DOT	FEDGOV	US	user@somewhere.com	\N	\N	\N	\N	\N
user1	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	user	1	test	PRIVPROFIT	CA	user1@abc.com	\N	\N	\N	\N	\N
jedi	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Luke	Skywalker	Jedi Council	PRIVPROFIT	US	jedi@jedi.com	\N	\N	\N	\N	\N
bobbyhaas	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Bobby	Haas	SAIC	PRIVPROFIT	US	haasr@saic.com	\N	\N	\N	\N	\N
booboo	f207795b5f1af74e45efcaa36d62ecd5cc4fdfd5d500fcd3689cb76ccb81c1e5	Boo	Boo	boo	PRIVPROFIT	US	booboo@boo.com	\N	\N	\N	\N	\N
zheng	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	George	Zheng	SAICaa	PRIVPROFIT	US	GEORGE.ZHENG@leidos.com	\N	\N	\N	\N	\N
vader	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Anakin	Skywalker	Justice League	PRIVPROFIT	US	chuckerin@gmail.com	\N	\N	t	\N	\N
sam	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Sam	Serious	Activist	OTHER	US	devon.sims28@gmail.com	\N	\N	t	\N	\N
dsims	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	De'Von 	Sims	Leidos	UNIVERSITY	BH	devon.l.sims@leidos.com	\N	\N	t	\N	\N
Mruno Bars	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Robert	Roth	Leidos	PRIVPROFIT	US	rothattack@gmail.com	\N	\N	t	\N	\N
chuckerin	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Chuckerin	Black	Leidos	PRIVPROFIT	US	chuckerin.black@leidos.com	\N	\N	t	\N	\N
Jimmmy	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Jimmy	Johns	Subs	PRIVPROFIT	US	test@test.com	\N	afb6c8d3-0744-4e73-a305-1af22a78959b	f	\N	\N
Spam	5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8	Spam	SaveButton	HereWeGo	PRIVPROFIT	US	spam@test.com	\N	d5317d54-3bcd-470a-b1b8-7b576f38f89b	f	\N	\N
\.


--
-- Name: PK_USER_ROLE; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT "PK_USER_ROLE" PRIMARY KEY (user_name, user_role);


--
-- Name: pk_country_code; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT pk_country_code PRIMARY KEY (country_code);


--
-- Name: pk_feedback_id; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT pk_feedback_id PRIMARY KEY (id);


--
-- Name: pk_id; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY feedback_type
    ADD CONSTRAINT pk_id PRIMARY KEY (id);


--
-- Name: pk_organization_type; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY organization_type
    ADD CONSTRAINT pk_organization_type PRIMARY KEY (organization_type);


--
-- Name: pk_username; Type: CONSTRAINT; Schema: auth; Owner: wxde; Tablespace: 
--

ALTER TABLE ONLY user_table
    ADD CONSTRAINT pk_username PRIMARY KEY (user_name);


--
-- Name: fki_country; Type: INDEX; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE INDEX fki_country ON user_table USING btree (country);


--
-- Name: fki_organization_type; Type: INDEX; Schema: auth; Owner: wxde; Tablespace: 
--

CREATE INDEX fki_organization_type ON user_table USING btree (organization_type);


--
-- Name: FK_USER_ROLE; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT "FK_USER_ROLE" FOREIGN KEY (user_name) REFERENCES user_table(user_name);


--
-- Name: fk_country; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY user_table
    ADD CONSTRAINT fk_country FOREIGN KEY (country) REFERENCES country(country_code);


--
-- Name: fk_feedback_type_id; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT fk_feedback_type_id FOREIGN KEY (feedback_type_id) REFERENCES feedback_type(id);


--
-- Name: fk_organization_type; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY user_table
    ADD CONSTRAINT fk_organization_type FOREIGN KEY (organization_type) REFERENCES organization_type(organization_type);


--
-- Name: fk_user_name; Type: FK CONSTRAINT; Schema: auth; Owner: wxde
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT fk_user_name FOREIGN KEY (user_name) REFERENCES user_table(user_name);


--
-- Name: auth; Type: ACL; Schema: -; Owner: wxde
--

REVOKE ALL ON SCHEMA auth FROM PUBLIC;
REVOKE ALL ON SCHEMA auth FROM wxde;
GRANT ALL ON SCHEMA auth TO wxde;


--
-- PostgreSQL database dump complete
--

