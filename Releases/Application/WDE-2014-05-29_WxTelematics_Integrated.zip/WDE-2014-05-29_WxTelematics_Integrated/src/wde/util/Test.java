/************************************************************************
 * Source filename: Test.java
 * 
 * Creation date: May 28, 2014
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {
    public static void main(String args[])
    {
        String timeStr ="2014-05-28 21:30:53 UTC";
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date d = df.parse(timeStr);
            System.out.println("success");
        }
        catch (Exception e) {
            e.printStackTrace();
        } 
    }
}
