/************************************************************************
 * Source filename: ApplicationInterfaceServlet.java
 * 
 * Creation date: May 9, 2014
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.qeds;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.realm.GenericPrincipal;

import wde.WDEMgr;
import wde.dao.DatabaseManager;
import wde.util.Config;
import wde.util.ConfigSvc;

public class ApplicationInterfaceServlet extends HttpServlet {
    private DatabaseManager dm = null;
    private String connId = null;
    private String subDir = null;
    
    public ApplicationInterfaceServlet() {
        if (dm == null) {
            WDEMgr.getInstance();
            dm = DatabaseManager.getInstance();
            connId = dm.getConnection();
            
            Config config = ConfigSvc.getInstance().getConfig("wde.qeds.QedsMgr");
            subDir = config.getString("subscription", "./");
            if (!subDir.endsWith("/"))
                subDir += "/";
        }
    }
    
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    {
        doPost(request, response);
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response)
    {
        String path = request.getServletPath();
        
        if (path.contains("downloadSubscription")) {
            String uuid = request.getParameter("uuid");
            String fileName = request.getParameter("file");
    
            if (uuid != null && fileName != null)
                retrieveSubscriptionResult(uuid, fileName, response);
        }
    }
    
    public void retrieveSubscriptionResult(String uuid, String fileName, HttpServletResponse response) {
        // lookup subId from UUID
        String queryStr = "SELECT id from subs.subscription where guid='" + uuid + "'"; 
        ResultSet rs = dm.query(connId, queryStr);
        
        String subId = null;
        PrintWriter printWriter = null;
        
        try {
            printWriter = response.getWriter();
            
            if (rs.next())
                subId = String.valueOf(rs.getInt("id"));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
        
        if (subId == null) {
            printWriter.write("No subscription found for UUID " + uuid);
            return;
        }

        try
        {
            BufferedReader oReader = new BufferedReader(new FileReader(subDir + subId + "/" + fileName));
            
            String sLine;
            while ((sLine = oReader.readLine()) != null)
                printWriter.write(sLine + "\r\n");

            oReader.close();
        }
        catch (Exception e)
        {
            printWriter.write(fileName + "for UUID " + uuid + " does not exist.");
        }
    }
}
