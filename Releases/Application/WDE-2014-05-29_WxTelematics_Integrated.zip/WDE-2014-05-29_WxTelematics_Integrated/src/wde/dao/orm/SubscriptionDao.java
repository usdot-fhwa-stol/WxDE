package wde.dao.orm;

import java.util.List;

import wde.data.Subscription;

public interface SubscriptionDao {

	List<Subscription> getSubscriptionsByOwner(String user);
	List<Subscription> getSubscriptionsByMember(String user);
	List<Subscription> getPublicSubscriptions(String user);
	List<Subscription> getSubscriptions(String user);
	Subscription getSubscription(Integer subscriptionId);

}
