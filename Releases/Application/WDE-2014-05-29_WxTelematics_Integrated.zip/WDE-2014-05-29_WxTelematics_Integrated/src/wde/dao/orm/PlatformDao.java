package wde.dao.orm;

import java.util.List;

import wde.data.Platform;

public interface PlatformDao {

	public List<Platform> getPlatforms(Integer contributorId);
	public List<Platform> getPlatforms();
}
