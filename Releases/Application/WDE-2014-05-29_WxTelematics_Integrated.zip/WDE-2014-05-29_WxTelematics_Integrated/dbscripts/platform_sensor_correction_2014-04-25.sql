# Executed in dev, test, demo, archive, prod

# remove the second platform with platformcode 260134

delete from meta.sensor where platformid in 
(
5686, 6112, 6139, 6144, 7614, 7616, 7619, 7624, 7625, 7628, 7629, 7631, 7632, 7633, 7634, 7635, 
7640, 7641, 7643, 7644, 7645, 7646, 7646, 7647, 7648, 7650, 7651, 7652, 7653, 7654, 7655, 7656
);

delete from meta.platform where id in 
(
5686, 6112, 6139, 6144, 7614, 7616, 7619, 7624, 7625, 7628, 7629, 7631, 7632, 7633, 7634, 7635, 
7640, 7641, 7643, 7644, 7645, 7646, 7646, 7647, 7648, 7650, 7651, 7652, 7653, 7654, 7655, 7656
);

update meta.sensor set totime='2013-03-06 19:51:25.147+00' where platformid in (700, 570);
update meta.platform set totime='2013-03-06 19:51:25.147+00' where id in (700, 570);

update meta.sensor set totime='2013-03-06 20:20:28.158+00' where platformid=5835;
update meta.platform set totime='2013-03-06 20:20:28.158+00' where id=5835;

update meta.sensor set totime='2013-05-01 00:00:00+00' where platformid=5898;
update meta.platform set totime='2013-05-01 00:00:00+00' where id=5898;

update meta.sensor set totime='2013-03-06 19:51:26.325+00' where platformid=1147;
update meta.platform set totime='2013-03-06 19:51:26.325+00' where id=1147;

update meta.sensor set totime='2013-12-14 19:00:00-05' where platformid=6131;
update meta.platform set totime='2013-12-14 19:00:00-05' where id=6131;

700 vs 1056

5835 vs 5987

5898 vs 6205

570 vs 1055

1147 vs 3323

6131 vs 6156