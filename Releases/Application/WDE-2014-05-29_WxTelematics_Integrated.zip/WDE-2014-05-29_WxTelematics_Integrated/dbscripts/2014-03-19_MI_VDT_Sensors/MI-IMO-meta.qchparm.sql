# applied to dev, test, demo, archive, prod

INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2649,'2014-03-17',410,5733,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2650,'2014-03-17',411,554,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2651,'2014-03-17',412,2000005,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2652,'2014-03-17',414,2000008,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2653,'2014-03-17',415,2000004,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2654,'2014-03-17',416,2000002,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2655,'2014-03-17',417,2000009,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2656,'2014-03-17',419,2000012,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2657,'2014-03-17',420,51138,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2658,'2014-03-17',421,575,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2659,'2014-03-17',422,5733,true);
INSERT INTO meta.qchparm (id,updatetime,sensortypeid,obstypeid,isdefault) VALUES (2660,'2014-03-17',423,581,true);
