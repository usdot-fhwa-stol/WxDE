# executed on dev, demo, test, archive, production

update meta.source set name='WxDE';

# Add source to represent VDT
insert into meta.source(staticid, updatetime, name) values(2, '2013-10-16', 'VDT');

# the following query identifies 158 MN IMOs
select * from meta.platform where category='M' and contribid=2 and totime is null

# the following query identifies 1262 sensors from MN IMOs
select s.* from meta.sensor s, meta.platform p where s.platformid=p.id and p.category='M' and s.contribid=2 and s.totime is null

# add platforms for MN IMO
#create table meta.platformv as select * from meta.platform where category='M' and contribid=2 and totime is null
#update meta.platformv set id=id+10000, staticid=staticid+10000, category='V'
#insert into meta.platform select * from meta.platformv
#drop table meta.platformv

# add sensors for MN IMO; There are no sensor with id or staticid in [40000000, 120000000], 
# qchparmid won't be needed
#create table meta.sensorv as select s.* from meta.sensor s, meta.platform p where s.platformid=p.id and p.category='M' and s.contribid=2 and s.totime is null
#update meta.sensorv set id=id+40000000, staticid=staticid+40000000, platformid=platformid+10000, sourceid=2
#insert into meta.sensor select * from meta.sensorv
#drop table meta.sensorv

# Need to add new obstype
update meta.obstype set obstype='mobileWipers' where obstype='mobileWipersYesNo';
update meta.obstype set obstype='mobileHeadlights' where obstype='mobileHeadlightsYesNo';

# add quality flags
insert into meta.qualityflag values(4, 2, '2013-10-22 13:00:00-04', null, 13, 0, '{Combined_Algorithm, Climate_Range, Model_Analysis, Nearest_Surface_Station, Neighboring_Vehicle, Persistence, Sensor_Range, Standard_Deviation, Spatial_Barnes, Spatial_IQR, Time_Step, Overall_Dew_Temperature, Filtering}')

# Introduce new platforms/sensors encountered with the VDT data
