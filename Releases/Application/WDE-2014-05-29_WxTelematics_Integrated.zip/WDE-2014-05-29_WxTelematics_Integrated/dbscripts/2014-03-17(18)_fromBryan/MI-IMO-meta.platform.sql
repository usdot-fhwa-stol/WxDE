# applied to prod (by Bryan on 3/18/2014, dev, test, demo, archive)

ALTER SEQUENCE meta.platform_id_seq restart with 6164;
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260063,'2014-03-17','7345485070','M','MDOT Vehicle Sawyer Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260064,'2014-03-17','7345485104','M','MDOT Vehicle Kalamazoo Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260065,'2014-03-17','7345484746','M','MDOT Vehicle Sawyer Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260066,'2014-03-17','7345455150','M','MDOT Vehicle Kalamazoo Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260067,'2014-03-17','7346456014','M','MDOT Vehicle Kalamazoo Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260068,'2014-03-17','7346450495','M','MDOT Vehicle Marshall Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260069,'2014-03-17','7345485483','M','MDOT Vehicle Coloma Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260070,'2014-03-17','7346457726','M','MDOT Vehicle Marshall Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260071,'2014-03-17','7346455973','M','MDOT Vehicle Kalamazoo Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260072,'2014-03-17','7346450908','M','MDOT Vehicle Kalamazoo Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260073,'2014-03-17','7345485150','M','MDOT Vehicle Marshall Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260074,'2014-03-17','7345485872','M','MDOT Vehicle Kalamazoo Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260075,'2014-03-17','7346455356','M','MDOT Vehicle Coloma Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260076,'2014-03-17','7346451579','M','MDOT Vehicle Coloma Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260077,'2014-03-17','7345483772','M','MDOT Vehicle Marshall Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260078,'2014-03-17','7346458073','M','MDOT Vehicle Sawyer Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260079,'2014-03-17','7346453996','M','MDOT Vehicle Coloma Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260080,'2014-03-17','7346456448','M','MDOT Vehicle Coloma Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260081,'2014-03-17','7346457578','M','MDOT Vehicle Sawyer Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260082,'2014-03-17','7346458451','M','MDOT Vehicle Coloma Garage',26,5710,56);
INSERT INTO meta.platform (staticid,updatetime,platformcode,category,description,contribid,siteid,maintcontactid) VALUES (260083,'2014-03-17','7346452768','M','MDOT Vehicle Detroit',26,5710,56);
