$( function(){
	//start/show loader.gif
	$('#loading').fadeIn()
	
	var locHash = location.hash.split("#")[1]
		hashSource = locHash.split('.')[0],
		dataSource = locHash.split('.')[1],
		jsonSource = '/resources/platforms/contributor/' + hashSource

	$('#sourceName').html(dataSource)
	
	//for functionality/effect for the loader.gif
	setTimeout( function() {
	
	$.ajax({url:jsonSource, dataType: 'json', success: populatePlatform, cache: false})
	
	function populatePlatform(data) {
		
		$.each(data.platform, function(key, value){
			$('.reports-table').append(
				'<tr>'
					+ '<td>'
					+ value.platformCode
					+ '</td>'
					+ '<td class="align-center">'
					+ value.category
					+ '</td>'
					+ '<td>'
					+ value.description
					+ '</td>'
					+ '<td>'
					+ value.locBaseLat
					+ '</td>'
					+ '<td>'
					+ value.locBaseLong
					+ '</td>'
					+ '<td class="align-center">'
					+ value.locBaseElev
					+ '</td>'
					+ '<td>'
					+ value.updateTime
					+ '</td>'
				+ '</tr>')
		})
	}
		$('#loading').fadeOut()

	}, 1000)//end setTimeout()

	
	var table = $('#sortable-table')

	$('#sort-description, #sort-update').css("cursor", "pointer").wrapInner(
			'<span class="explode" title="Click to sort this column"/>').each(
			function() {

				var th = $(this), thIndex = th.index(), inverse = true, caret
				th.bind("click", function() {

					table.find('td').filter(function() {

						return $(this).index() === thIndex

					}).sortElements(
							function(a, b) {

								return $.text([ a ]) > $.text([ b ]) ? inverse ? -1
										: 1 : inverse ? 1 : -1

							}, function() {

								// parentNode is the element we want to move
								return this.parentNode;

							});

					if (inverse == false)
						caret = "icon-sort-up"
					else
						caret = "icon-sort-down"

					$(this).find(".icon-stack").html(
							'<i class="icon-sort" style="color: #AAA;"></i>'
									+ '<i class="' + caret + '"></i>');

					inverse = !inverse

				});

			});

	
})//end of jQuery