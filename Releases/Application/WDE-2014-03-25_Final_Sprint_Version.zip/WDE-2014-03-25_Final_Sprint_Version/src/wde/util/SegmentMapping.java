package wde.util;


import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;

import ucar.ma2.ArrayChar;
import ucar.ma2.ArrayDouble;
import ucar.ma2.ArrayInt;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;


public class SegmentMapping implements Comparable<SegmentMapping>
{
	public static final String[] OBS_TYPES = 
	{
		"204 | icePercent", 
		"205 | precip10min", 
		"206 | precipIntensity", 
		"207 | precipType", 
		"541 | essLatitude", 
		"542 | essLongitude", 
		"543 | essVehicleSpeed", 
		"544 | essVehicleBearing", 
		"545 | essVehicleOdometer", 
		"551 | essReferenceHeight", 
		"554 | essAtmosphericPressure", 
		"574 | essWetBulbTemp", 
		"575 | essDewpointTemp", 
		"576 | essMaxTemp", 
		"577 | essMinTemp", 
		"581 | essRelativeHumidity", 
		"583 | essAdjacentSnowDepth", 
		"584 | essRoadwaySnowDepth", 
		"585 | essRoadwaySnowpackDepth", 
		"586 | essPrecipYesNo", 
		"587 | essPrecipRate", 
		"588 | essSnowfallAccumRate", 
		"589 | essPrecipSituation", 
		"592 | essTotalSun", 
		"593 | essCloudSituation", 
		"595 | essInstantaneousSolarRadiation", 
		"596 | essTotalRadiation", 
		"597 | essTotalRadiationPeriod", 
		"5101 | essVisibility", 
		"5102 | essVisibilitySituation", 
		"5121 | essMobileFriction", 
		"5122 | essMobileObservationGroundState", 
		"5123 | essMobileObservationPavement", 
		"5134 | essPaveTreatmentAmount", 
		"5135 | essPaveTreatmentWidth", 
		"5141 | essCO", 
		"5142 | essCO2", 
		"5143 | essNO", 
		"5144 | essNO2", 
		"5145 | essSO2", 
		"5146 | essO3", 
		"5733 | essAirTemperature", 
		"5810 | essIceThickness", 
		"5811 | essPrecipitationStartTime", 
		"5812 | essPrecipitationEndTime", 
		"5813 | essPrecipitationOneHour", 
		"5814 | essPrecipitationThreeHours", 
		"5815 | essPrecipitationSixHours", 
		"5816 | essPrecipitationTwelveHours", 
		"5817 | essPrecipitation24Hours", 
		"51137 | essSurfaceStatus", 
		"51138 | essSurfaceTemperature", 
		"51139 | essPavementTemperature", 
		"51165 | essSubSurfaceTemperature", 
		"51166 | essSubSurfaceMoisture", 
		"51167 | essSubSurfaceSensorError", 
		"51332 | essPaveTreatProductType", 
		"51333 | essPaveTreatProductForm", 
		"51334 | essPercentProductMix", 
		"56104 | windSensorAvgSpeed", 
		"56105 | windSensorAvgDirection", 
		"56106 | windSensorSpotSpeed", 
		"56107 | windSensorSpotDirection", 
		"56108 | windSensorGustSpeed", 
		"56109 | windSensorGustDirection", 
		"58212 | waterLevelSensorReading", 
		"511310 | essSurfaceWaterDepth", 
		"511311 | essSurfaceSalinity", 
		"511313 | essSurfaceFreezePoint", 
		"511314 | essSurfaceBlackIceSignal", 
		"511315 | essPavementSensorError", 
		"511316 | essSurfaceIceOrWaterDepth", 
		"511317 | essSurfaceConductivityV2", 
		"511319 | pavementSensorTemperatureDepth", 
		"511371 | essSurfaceStatus2", 
		"561010 | windSensorSituation", 
		"2000000 | mobileHeadlights", 
		"2000001 | mobileWipers", 
		"2000002 | mobileABS", 
		"2000003 | mobileBrakeBoost", 
		"2000004 | mobileBrakeStatus", 
		"2000005 | mobileHeading", 
		"2000006 | mobileLatAccel", 
		"2000007 | mobileLongAccel", 
		"2000008 | mobileSpeed", 
		"2000009 | mobileStab", 
		"2000010 | mobileSteeringAngle", 
		"2000011 | mobileSteeringRate", 
		"2000012 | mobileTrac", 
		"2000013 | mobileYawRate", 
		"2001000 | total_num_msg", 
		"2001001 | model_air_temp", 
		"2001002 | model_bar_press", 
		"2001003 | nss_air_temp_mean", 
		"2001004 | nss_bar_press_mean", 
		"2001005 | nss_dew_temp_mean", 
		"2001006 | nss_hourly_precip_mean", 
		"2001007 | nss_prevail_vis_mean", 
		"2001008 | nss_wind_dir_mean", 
		"2001009 | nss_wind_speed_mean", 
		"2001010 | radar_cref", 
		"2001011 | radar_precip_flag", 
		"2001012 | radar_precip_type", 
		"2001013 | cloud_mask", 
		"2001014 | num_msg_valid_air_temp", 
		"2001015 | air_temp_iqr25", 
		"2001016 | air_temp_iqr75", 
		"2001017 | air_temp_max", 
		"2001018 | air_temp_mean", 
		"2001019 | air_temp_median", 
		"2001020 | air_temp_min", 
		"2001021 | air_temp_stdev", 
		"2001022 | air_temp_var", 
		"2001023 | num_msg_valid_air_temp2", 
		"2001024 | air_temp2_iqr25", 
		"2001025 | air_temp2_iqr75", 
		"2001026 | air_temp2_max", 
		"2001027 | air_temp2_mean", 
		"2001028 | air_temp2_median", 
		"2001029 | air_temp2_min", 
		"2001030 | air_temp2_stdev", 
		"2001031 | air_temp2_var", 
		"2001032 | num_msg_valid_bar_press", 
		"2001033 | bar_press_iqr25", 
		"2001034 | bar_press_iqr75", 
		"2001035 | bar_press_max", 
		"2001036 | bar_press_mean", 
		"2001037 | bar_press_median", 
		"2001038 | bar_press_min", 
		"2001039 | bar_press_stdev", 
		"2001040 | bar_press_var", 
		"2001041 | num_msg_valid_dew_temp", 
		"2001042 | dew_temp_iqr25", 
		"2001043 | dew_temp_iqr75", 
		"2001044 | dew_temp_max", 
		"2001045 | dew_temp_mean", 
		"2001046 | dew_temp_median", 
		"2001047 | dew_temp_min", 
		"2001048 | dew_temp_stdev", 
		"2001049 | dew_temp_var", 
		"2001050 | num_msg_valid_heading", 
		"2001051 | heading_iqr25", 
		"2001052 | heading_iqr75", 
		"2001053 | heading_max", 
		"2001054 | heading_mean", 
		"2001055 | heading_median", 
		"2001056 | heading_min", 
		"2001057 | heading_stdev", 
		"2001058 | heading_var", 
		"2001059 | num_msg_valid_hoz_accel_lat", 
		"2001060 | hoz_accel_lat_iqr25", 
		"2001061 | hoz_accel_lat_iqr75", 
		"2001062 | hoz_accel_lat_max", 
		"2001063 | hoz_accel_lat_mean", 
		"2001064 | hoz_accel_lat_median", 
		"2001065 | hoz_accel_lat_min", 
		"2001066 | hoz_accel_lat_stdev", 
		"2001067 | hoz_accel_lat_var", 
		"2001068 | num_msg_valid_hoz_accel_lon", 
		"2001069 | hoz_accel_lon_iqr25", 
		"2001070 | hoz_accel_lon_iqr75", 
		"2001071 | hoz_accel_lon_max", 
		"2001072 | hoz_accel_lon_mean", 
		"2001073 | hoz_accel_lon_median", 
		"2001074 | hoz_accel_lon_min", 
		"2001075 | hoz_accel_lon_stdev", 
		"2001076 | hoz_accel_lon_var", 
		"2001077 | num_msg_valid_abs", 
		"2001078 | num_abs_engaged", 
		"2001079 | num_abs_not_equipped", 
		"2001080 | num_abs_off", 
		"2001081 | num_abs_on", 
		"2001082 | num_msg_valid_brakes", 
		"2001083 | num_brakes_all_off", 
		"2001084 | num_brakes_all_on", 
		"2001085 | num_brakes_lf_active", 
		"2001086 | num_brakes_lr_active", 
		"2001087 | num_brakes_rf_active", 
		"2001088 | num_brakes_rr_active", 
		"2001089 | num_msg_valid_brakes_boost", 
		"2001090 | num_brakes_boost_not_equipped", 
		"2001091 | num_brakes_boost_off", 
		"2001092 | num_brakes_boost_on", 
		"2001093 | num_msg_valid_lights", 
		"2001094 | num_lights_automatic_control", 
		"2001095 | num_lights_drl", 
		"2001096 | num_lights_fog", 
		"2001097 | num_lights_hazard", 
		"2001098 | num_lights_high_beam", 
		"2001099 | num_lights_left_turn", 
		"2001100 | num_lights_low_beam", 
		"2001101 | num_lights_off", 
		"2001102 | num_lights_parking", 
		"2001103 | num_lights_right_turn", 
		"2001104 | num_msg_valid_stab", 
		"2001105 | num_stab_engaged", 
		"2001106 | num_stab_not_equipped", 
		"2001107 | num_stab_off", 
		"2001108 | num_stab_on", 
		"2001109 | num_msg_valid_trac", 
		"2001110 | num_trac_engaged", 
		"2001111 | num_trac_not_equipped", 
		"2001112 | num_trac_off", 
		"2001113 | num_trac_on", 
		"2001114 | num_msg_valid_wipers", 
		"2001115 | num_wipers_automatic", 
		"2001116 | num_wipers_high", 
		"2001117 | num_wipers_intermittent", 
		"2001118 | num_wipers_low", 
		"2001119 | num_wipers_not_equipped", 
		"2001120 | num_wipers_off", 
		"2001121 | num_wipers_washer", 
		"2001122 | num_msg_valid_speed", 
		"2001123 | speed_iqr25", 
		"2001124 | speed_iqr75", 
		"2001125 | speed_max", 
		"2001126 | speed_mean", 
		"2001127 | speed_median", 
		"2001128 | speed_min", 
		"2001129 | speed_ratio", 
		"2001130 | speed_stdev", 
		"2001131 | speed_var", 
		"2001132 | num_msg_valid_steering_angle", 
		"2001133 | steering_angle_iqr25", 
		"2001134 | steering_angle_iqr75", 
		"2001135 | steering_angle_max", 
		"2001136 | steering_angle_mean", 
		"2001137 | steering_angle_median", 
		"2001138 | steering_angle_min", 
		"2001139 | steering_angle_stdev", 
		"2001140 | steering_angle_var", 
		"2001141 | num_msg_valid_steering_rate", 
		"2001142 | steering_rate_max", 
		"2001143 | steering_rate_mean", 
		"2001144 | steering_rate_median", 
		"2001145 | steering_rate_min", 
		"2001146 | steering_rate_stdev", 
		"2001147 | steering_rate_var", 
		"2001148 | num_msg_valid_surface_temp", 
		"2001149 | surface_temp_iqr25", 
		"2001150 | surface_temp_iqr75", 
		"2001151 | surface_temp_max", 
		"2001152 | surface_temp_mean", 
		"2001153 | surface_temp_median", 
		"2001154 | surface_temp_min", 
		"2001155 | surface_temp_stdev", 
		"2001156 | surface_temp_var", 
		"2001157 | num_msg_valid_yaw", 
		"2001158 | yaw_iqr25", 
		"2001159 | yaw_iqr75", 
		"2001160 | yaw_max", 
		"2001161 | yaw_mean", 
		"2001162 | yaw_median", 
		"2001163 | yaw_min", 
		"2001164 | yaw_stdev", 
		"2001165 | yaw_var", 
		"2001166 | all_hazards", 
		"2001167 | pavement_condition", 
		"2001168 | precipitation", 
		"2001169 | visibility"
	};

	String m_sName;
	String m_sId;
	ArrayList<Double> m_oLat = null;
	ArrayList<Double> m_oLon = null;


	SegmentMapping()
	{
	}


	SegmentMapping(String sName, String sId)
	{
		m_sName = sName;
		m_sId = sId;
		m_oLat = new ArrayList();
		m_oLon = new ArrayList();
	}


	@Override
	public int compareTo(SegmentMapping oRhs)
	{
		return m_sName.compareTo(oRhs.m_sName);
	}


	public static void main(String[] sArgs)
	{
		try
		{
			String sNcFile = sArgs[0];
			String sSqlFile = sArgs[1];
			String sUpdateDate = sArgs[2];
			int nPlatformId = Integer.parseInt(sArgs[3]);
			int nPlatformStaticId = Integer.parseInt(sArgs[4]);
			int nContribId = Integer.parseInt(sArgs[5]);
			int nSiteId = Integer.parseInt(sArgs[6]);

			FileWriter oWriter = new FileWriter(sSqlFile);

			StringBuilder sBuffer1 = new StringBuilder();
			StringBuilder sBuffer2 = new StringBuilder();
			ArrayList<SegmentMapping> oSegMaps = new ArrayList();
			SegmentMapping oSearch = new SegmentMapping();

			NetcdfFile oNcFile = NetcdfFile.open(sNcFile);
			Variable oSegName = oNcFile.findVariable("seg_name");
			Variable oSegId = oNcFile.findVariable("seg_id");
			Variable oLat = oNcFile.findVariable("latitude");
			Variable oLon = oNcFile.findVariable("longitude");

			ArrayChar.D2 oSegs1 = (ArrayChar.D2)oSegName.read();
			ArrayInt.D1 oSegs2 = (ArrayInt.D1)oSegId.read();
			ArrayDouble.D1 oLats = (ArrayDouble.D1)oLat.read();
			ArrayDouble.D1 oLons = (ArrayDouble.D1)oLon.read();

			// accumulate lat lon points by segment name
			int[] nShape1 = oSegs1.getShape();
			for (int nRow = 0; nRow < nShape1[0]; nRow++)
			{
				sBuffer1.setLength(0);
				sBuffer2.setLength(0);
				for (int nCol = 0; nCol < nShape1[1]; nCol++)
				{
					if (oSegs1.get(nRow, nCol) != 0)
						sBuffer1.append(oSegs1.get(nRow, nCol));
				}
				if (oSegs2.get(nRow) != 0)
					sBuffer2.append(oSegs2.get(nRow));

				oSearch.m_sName = sBuffer1.toString();
				oSearch.m_sId = sBuffer2.toString();
				int nIndex = Collections.binarySearch(oSegMaps, oSearch);
				if (nIndex < 0)
				{
					nIndex = ~nIndex;
					oSegMaps.add(nIndex, new SegmentMapping(oSearch.m_sName, oSearch.m_sId));
				}
				SegmentMapping oSegMap = oSegMaps.get(nIndex);

				oSegMap.m_oLat.add(new Double(oLats.get(nRow)));
				oSegMap.m_oLon.add(new Double(oLons.get(nRow)));
			}

			// create platform SQL insert statements
			oWriter.write(String.format("alter sequence meta.platform_id_seq " + 
				"restart with %d;\r\n", nPlatformId));

			for (int nIndex = 0; nIndex < oSegMaps.size(); nIndex++)
			{
				SegmentMapping oSegMap = oSegMaps.get(nIndex);
				int nMid = oSegMap.m_oLat.size() / 2;

				oWriter.write(String.format
				(
					"INSERT INTO meta.platform (staticid, updatetime, " + 
					"platformcode, category, description, " + 
					"contribid, siteid, locbaselat, locbaselong) " + 
					"VALUES (%d, '%s', '%s', 'S', " + 
					"'MDOT VDT road segment %s', %d, %d, %f, %f);\r\n",
					nIndex + nPlatformStaticId, sUpdateDate, oSegMap.m_sName, 
					oSegMap.m_sName, nContribId, nSiteId, 
					oSegMap.m_oLat.get(nMid), oSegMap.m_oLon.get(nMid))
				);
			}
			oNcFile.close();


			// create sensor SQL insert statements while platforms are in memory
			int nSensorId = Integer.parseInt(sArgs[7]);
			int nQchparmId = Integer.parseInt(sArgs[8]);

			oWriter.write(String.format("alter sequence meta.sensor_id_seq " + 
				"restart with %d;\r\n", nSensorId));

			for (int nSegIndex = 0; nSegIndex < oSegMaps.size(); nSegIndex++)
			{
				for (int nIndex = 0; nIndex < OBS_TYPES.length; nIndex++)
				{
					oWriter.write(String.format
					(
						"INSERT INTO meta.sensor " + 
						"(sourceid, staticid, updatetime, platformid, " + 
						"contribid, sensorindex, obstypeid, qchparmid, " + 
						"distgroup) VALUES(2, %d, '%s', %d, %d, 0, %s, %d, 2);\r\n", 
						nIndex + (nPlatformStaticId + nSegIndex) * 1000, 
						sUpdateDate, nPlatformId + nSegIndex, nContribId, 
						OBS_TYPES[nIndex].split(" | ")[0], nIndex + nQchparmId)
					);
				}
			}
			oWriter.close();
		}
		catch (Exception oException)
		{
			System.out.println
			(
				"usage:\r\n\r\n" + 
				"First create a new site for the contrib segments and determine " + 
				"the site id, contrib id, and starting qchparm id; then derive " + 
				"the starting platform id and sensor id from the database.\r\n\r\n" + 
				"There are nine required command line parameters:\r\n\r\n" + 
				"<input NC file path and file name> contains the road segments\r\n" + 
				"<output SQL file path and file name> SQL statements are stored here\r\n" + 
				"<update date> use the format YYYY-MM-DD i.e. 2014-01-01\r\n" + 
				"<starting platform id> determined from first step\r\n" + 
				"<starting platform static id> contrib id * 1000 + 1 works well\r\n" + 
				"<contrib id> determined in the first step\r\n" + 
				"<site id> created in the first step\r\n" + 
				"<starting sensor id> determined from first step\r\n" + 
				"<starting qchparm id> determined from firs step\r\n"
			);
			oException.printStackTrace();
		}
	}
}
