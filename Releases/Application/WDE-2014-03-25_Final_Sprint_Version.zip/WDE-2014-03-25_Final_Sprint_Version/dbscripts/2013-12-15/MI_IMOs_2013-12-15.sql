# Executed on all instances

alter sequence meta.platform_id_seq restart with 6122;
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260021, '2013-12-15', '1FTNF21506ED19601', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260022, '2013-12-15', '1FTNF21578EA79398', 'M', 'MDOT Vehicle 2008 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260023, '2013-12-15', '1FTNF205X8EA62466', 'M', 'MDOT Vehicle 2008 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260024, '2013-12-15', '1FTNF21548ED93073', 'M', 'MDOT Vehicle 2008 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260025, '2013-12-15', '1FTNF2B55AEB36850', 'M', 'MDOT Vehicle 2010 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260026, '2013-12-15', '1FTNF20555EB72630', 'M', 'MDOT Vehicle 2005 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260027, '2013-12-15', '1FTNX20576EB72501', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260028, '2013-12-15', '1FTNF20546ED10174', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260029, '2013-12-15', '1FTNX20546EB72505', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260030, '2013-12-15', '1FTNF2B57AEB36851', 'M', 'MDOT Vehicle 2010 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260031, '2013-12-15', '1FTNX20566EB72506', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);

INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260032, '2013-12-15', '2GTEC190191117903', 'M', 'MDOT Vehicle 2006 Ford Taurus', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260033, '2013-12-15', '1FTNX20516EA69199', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260034, '2013-12-15', '2D8HN44E39R620444', 'M', 'MDOT Vehicle 2009 Dodge Caravan', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260035, '2013-12-15', '1FTNF20546EC02296', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);

INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260036, '2013-12-15', '1FTNF20505EB79520', 'M', 'MDOT Vehicle 2005 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260037, '2013-12-15', '1FTNX205X8ED86191', 'M', 'MDOT Vehicle 2008 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260038, '2013-12-15', '1GTR2TE00CZ167180', 'M', 'MDOT Vehicle 2012 GMC Sierra', 26, 5710, 56);

INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260039, '2013-12-15', '2G1WB57K291307138', 'M', 'MDOT Vehicle 2005 Ford Taurus', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260040, '2013-12-15', '1FTSX21586ED19605', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260041, '2013-12-15', '1FT7X2A65DEA64620', 'M', 'MDOT Vehicle 2013 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260042, '2013-12-15', '1FTSX21508EA62460', 'M', 'MDOT Vehicle 2007 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260043, '2013-12-15', '1GNDV23W18D197092', 'M', 'MDOT Vehicle 2008 Chevy Uplander', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260044, '2013-12-15', '1FT7X2B69DEA64621', 'M', 'MDOT Vehicle 2013 Ford F250', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260045, '2013-12-15', '1FTNX20506EB72503', 'M', 'MDOT Vehicle 2006 Ford F250', 26, 5710, 56);

INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260046, '2013-12-15', '1FAFP53216A146819', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260047, '2013-12-15', '1FAFP532X5A302208', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260048, '2013-12-15', '1FDWX305X8ED93082', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260049, '2013-12-15', '1FT7X2B61DEB30885', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260050, '2013-12-15', '1FT7X2B63DEB30886', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260051, '2013-12-15', '1FTFX1CFXDKE95183', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260052, '2013-12-15', '1FTFX1EF0DKE72458', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260053, '2013-12-15', '1FTNF20529EA14137', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260054, '2013-12-15', '1FTNF20548EA62463', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260055, '2013-12-15', '1FTNF2B57AEB36851', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260056, '2013-12-15', '1FTNX20506EB72498', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260057, '2013-12-15', '1FTNX20548ED86185', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260058, '2013-12-15', '1FTNX20556EB72500', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260059, '2013-12-15', '1FTSX21549EA50989', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260060, '2013-12-15', '1FTSX21555EB72609', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260061, '2013-12-15', '1FTSX21588ED93058', 'M', 'MDOT Vehicle', 26, 5710, 56);
INSERT INTO meta.platform (staticid, updatetime, platformcode, category, description, contribid, siteid, maintcontactid) VALUES (260062, '2013-12-15', '1FTWX31565EB96246', 'M', 'MDOT Vehicle', 26, 5710, 56);

# It turned out that the following two platforms are duplicates
delete from meta.platform where id=6128 or id=6132;