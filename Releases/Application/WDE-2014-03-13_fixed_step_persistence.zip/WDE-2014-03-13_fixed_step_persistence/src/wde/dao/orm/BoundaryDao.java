package wde.dao.orm;

import java.util.List;

import wde.data.Boundary;

public interface BoundaryDao {

	public Boundary getBoundary(String code);
	
	public List<Boundary> getBoundaries();
	
}
