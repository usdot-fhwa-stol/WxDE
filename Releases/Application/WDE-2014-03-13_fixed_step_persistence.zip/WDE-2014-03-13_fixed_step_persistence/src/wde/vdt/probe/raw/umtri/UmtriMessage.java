/************************************************************************
 * Source filename: AmeritrakMessage.java
 * 
 * Creation date: Mar 11, 2014
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.vdt.probe.raw.umtri;

import java.util.Date;

import org.apache.log4j.Logger;

public class UmtriMessage {
    
    private static final Logger logger = Logger.getLogger(UmtriMessage.class);
    
    private Date currentTime = null;
    
    private Date recTime = null;

    private double latitudePosition;

    private double longitudePosition;

    private float altitude;

    private float compassHeading;

    private float speed;

    private short brakes;

    private short antilockBrakingSystem;

    private short electronicStabilityControl;

    private short tractionControlBrakingEvent;

    private short ambientAirTemperature;

    private float dewPoint;

    private float humidity;

    private float surfaceTemp;

    public UmtriMessage(Date recTime, String[] rawData) {
        
    }
    
    /**
     * @return the currentTime
     */
    public Date getCurrentTime() {
        return currentTime;
    }

    /**
     * @return the recTime
     */
    public Date getRecTime() {
        return recTime;
    }

    /**
     * @return the latitudePosition
     */
    public double getLatitudePosition() {
        return latitudePosition;
    }

    /**
     * @return the longitudePosition
     */
    public double getLongitudePosition() {
        return longitudePosition;
    }

    /**
     * @return the altitude
     */
    public float getAltitude() {
        return altitude;
    }

    /**
     * @return the compassHeading
     */
    public float getCompassHeading() {
        return compassHeading;
    }

    /**
     * @return the speed
     */
    public float getSpeed() {
        return speed;
    }

    /**
     * @return the brakes
     */
    public short getBrakes() {
        return brakes;
    }

    /**
     * @return the antilockBrakingSystem
     */
    public short getAntilockBrakingSystem() {
        return antilockBrakingSystem;
    }

    /**
     * @return the electronicStabilityControl
     */
    public short getElectronicStabilityControl() {
        return electronicStabilityControl;
    }

    /**
     * @return the tractionControlBrakingEvent
     */
    public short getTractionControlBrakingEvent() {
        return tractionControlBrakingEvent;
    }

    /**
     * @return the ambientAirTemperature
     */
    public short getAmbientAirTemperature() {
        return ambientAirTemperature;
    }

    /**
     * @return the dewPoint
     */
    public float getDewPoint() {
        return dewPoint;
    }

    /**
     * @return the humidity
     */
    public float getHumidity() {
        return humidity;
    }

    /**
     * @return the surfaceTemp
     */
    public float getSurfaceTemp() {
        return surfaceTemp;
    } 
}
