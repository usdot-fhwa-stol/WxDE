package wde.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.SimpleTimeZone;

public class DateTimeHelper {
    
    private static SimpleDateFormat timeFormatter;
    
    static {
        timeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleTimeZone stz = new SimpleTimeZone(-21600000, "USA/Central", Calendar.MARCH, 8, -Calendar.SUNDAY, 
            7200000, Calendar.NOVEMBER, 3, -Calendar.SUNDAY, 7200000, 3600000);
        timeFormatter.setTimeZone(stz);
    }

    /**
     * @return the timeFormatter
     */
    public static SimpleDateFormat getTimeFormatter() {
        return timeFormatter;
    }
}
