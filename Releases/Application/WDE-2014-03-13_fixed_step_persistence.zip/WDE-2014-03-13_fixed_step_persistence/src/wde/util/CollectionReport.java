/************************************************************************
 * Source filename: CollectionReport.java
 * 
 * Creation date: Aug 6, 2013
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.util;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import wde.dao.DatabaseManager;

public class CollectionReport {
    private static final Logger logger = Logger.getLogger(CollectionReport.class);
    
    private static final int NUM_OF_MILLI_SECONDS_IN_A_DAY = 86400000;
    
    private Properties prop = null;
    private String startDateStr = null;
    private String endDateStr = null;
    private String reportPath = null;
    private HashMap<String, int[]> collectionMap = null;
    private DatabaseManager db = null;
    private String connId = null;
    private int interval = 1;

    /**
     * 
     */
    public CollectionReport(String startDateStr, String endDateStr, String intervalStr)
    {
        prop = new Properties();
        loadPropertiesFile();
        this.startDateStr = startDateStr;
        this.endDateStr = endDateStr;
        collectionMap = new HashMap<>();
        db = DatabaseManager.getInstance();
        connId = db.getConnection();
        interval = Integer.parseInt(intervalStr);
    }
    
    void generateReport()
    {
        String timeFormat = "yyyy-MM-dd";
        
        SimpleDateFormat timeFormatter = new SimpleDateFormat(timeFormat);
        Date workingDate = null;
        Date endDate = null;
        
        try {
            workingDate = timeFormatter.parse(startDateStr);
            endDate = timeFormatter.parse(endDateStr);
        }
        catch (ParseException e) {
            e.printStackTrace();
            System.exit(-1);
        }
        long size = (endDate.getTime() - workingDate.getTime()) / (NUM_OF_MILLI_SECONDS_IN_A_DAY * interval) + 1;
        logger.info("size: " + size);

        int index = 0;
        int intervalCounter = 0;
        String headerStr = "Contributor Name";
        while (workingDate.getTime() < endDate.getTime()) {

            String currentTableDate = timeFormatter.format(workingDate);
            
            // Need to fix the header
            if (intervalCounter == 0)
                headerStr += "," + currentTableDate;
            else if (intervalCounter == (interval - 1))
                headerStr += " to " + currentTableDate;

            try {
                String sql = "select c.name, p.category, count(*) from meta.contrib c, " +
                    "obs.\"obs_" + currentTableDate + "\"" + " o, meta.sensor s, meta.platform p "+
                    "where o.sensorid = s.id and s.platformid = p.id and p.contribId = c.id " + 
                    "group by c.name, p.category order by c.name, p.category";
                
                logger.info(sql);
                
                ResultSet rs = db.query(connId, sql);
                while (rs != null && rs.next()) {
                    String key = rs.getString("name") + " (" + rs.getString("category") + ")";
                    int count = rs.getInt("count");
                    int[] values = null;
                    if (collectionMap.get(key) == null) {
                        values = new int[(int)size];
                        collectionMap.put(key, values);
                    }
                    else {
                        values = collectionMap.get(key);
                    }
                    values[index] += count;
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }

            // progress one day
            workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            intervalCounter++;
            if (intervalCounter >= interval) {
                index++;
                intervalCounter = 0;
            }
        }

        // Writing content of collectionMap into the csv file
        try {
            BufferedWriter file = new BufferedWriter(new FileWriter(reportPath));
            file.write(headerStr);
            file.write("\r\n");
            Set<String> keySet = collectionMap.keySet();
            ArrayList<String> keyList = new ArrayList(keySet);
            java.util.Collections.sort(keyList);
            for (String key : keyList) {
                int[] values = collectionMap.get(key);
                file.write(key);
                for (int i = 0; i < values.length; i++)
                    file.write(", " + values[i]);
                
                file.write("\r\n");
            }
     
            file.write("\r\n");
            file.close();
            
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } 
    }
    
    /**
     * @param args
     */
    public static void main(String args[])
    {
        DOMConfigurator.configure("config/wde_log4j.xml");
        CollectionReport cr = new CollectionReport(args[0], args[1], args[2]);
        cr.generateReport();
    }
    
    /**
     * 
     */
    private void loadPropertiesFile()
    {
        logger.info("Loading properties file");
        
        String separator = System.getProperty("file.separator");
        String path = System.getProperty("user.dir") + separator + "config" + separator + "wdecr_config.properties";

        try
        {
            FileInputStream fis = new FileInputStream(path);
            prop.load(fis);
            fis.close();
 
            reportPath = prop.getProperty("reportpath");
        }
        catch (IOException e)
        {
            e.printStackTrace();
            System.exit(-1);
        }
    }
}
