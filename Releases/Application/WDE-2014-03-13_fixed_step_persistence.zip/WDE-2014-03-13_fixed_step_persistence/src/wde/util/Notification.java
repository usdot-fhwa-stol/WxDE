/************************************************************************
 * Source filename: Notification.java
 * 
 * Creation date: Sep 3, 2013
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class Notification {
    
    private static Logger logger = Logger.getLogger(Notification.class);
    
    private static Notification instance = null;
    public static boolean isStandAlone = false;
    private static final String defaultEmail = "wxde_support@leidoshost.net";
    
    private Config config = null;
    private Properties props = null;

    public static Notification getInstance() {
        if (instance == null)
            instance = new Notification();

        return instance;
    }

    private Notification()
    {
        String str = "mail.leidoshost.net";
        props = new Properties();
        
        if (!isStandAlone) {
            config = ConfigSvc.getInstance().getConfig(Notification.this);            
            str = config.getString("mail.smtp.host", null);
        }
        
        logger.info("mail.smtp.host:" + str);
        props.put("mail.smtp.host", str);
    }
    
    public void sendEmail(ArrayList<InternetAddress> recipients, String subject, String messageBody, String filePath, String fileDisplayName)
    {
        if (recipients.isEmpty()) {
            logger.info("sendEmail invoked with empty recipients");
            return;
        }
        
        Session session = Session.getInstance(props);
        
        try {

            // send one message when status changes to unacceptable
            // and a second message when normal operation resumes
            MimeMessage message = new MimeMessage(session);
            message.setSentDate(new Date());
    
            for (int nIndex = 0; nIndex < recipients.size(); nIndex++)
                message.setRecipient(Message.RecipientType.TO, recipients.get(nIndex));
    
            String str = defaultEmail;
            
            if (!isStandAlone)
                str = config.getString("bcc", null);

            logger.info("bcc: " + str);
            message.setRecipient(Message.RecipientType.BCC, new InternetAddress(str));
    
            if (!isStandAlone)
                str = config.getString("mail.from", null);
            
            logger.info("from: " + str);
            message.setFrom(new InternetAddress(str));
    
             // create and fill the first message part
            MimeBodyPart msgText = new MimeBodyPart();
            msgText.setText(messageBody);
            
            // create the Multipart message and add the parts to it
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(msgText);
            
            // create the second message part
            if (filePath != null) {
                File file = new File(filePath);
                if (file.exists()) {     
                    MimeBodyPart msgFile = new MimeBodyPart();
                    msgFile.attachFile(filePath);
                    msgFile.setFileName(fileDisplayName);
                    multipart.addBodyPart(msgFile);
                }
            }
    
            // add the Multipart to the message
            message.setContent(multipart);
    
            message.setSubject(subject);
            
            Transport.send(message); // very last step
            
            if (isStandAlone)
                System.out.println("Mail sent to: " + recipients.get(0).getAddress());
        }
        catch (MessagingException me) {
            logger.error(me.getMessage());
            me.printStackTrace();
        }
        catch (IOException ie) {
            logger.error(ie.getMessage());
            ie.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        
        Notification.isStandAlone = true;
        
        Notification notification = Notification.getInstance();
        
        ArrayList<InternetAddress> recipients = new ArrayList<>();
        InternetAddress me = null;
        try {
            me = new InternetAddress("george.zheng@leidos.com");
            recipients.add(me);
        }
        catch (AddressException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        notification.sendEmail(recipients, "notification test", args[0], args[1], args[2]);
    }
}
