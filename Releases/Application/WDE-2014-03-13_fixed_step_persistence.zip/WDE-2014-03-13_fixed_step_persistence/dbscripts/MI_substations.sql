# Executed on dev, test, demo, archive, prod

insert into subs.substation values(2013111100,	5286	);
insert into subs.substation values(2013111100,	5287	);
insert into subs.substation values(2013111100,	4845	);
insert into subs.substation values(2013111100,	4846	);
insert into subs.substation values(2013111100,	4847	);
insert into subs.substation values(2013111100,	5285	);
insert into subs.substation values(2013111100,	5280	);
insert into subs.substation values(2013111100,	5282	);
insert into subs.substation values(2013111100,	5283	);
insert into subs.substation values(2013111100,	5462	);
insert into subs.substation values(2013111100,	5463	);
insert into subs.substation values(2013111100,	5464	);
insert into subs.substation values(2013111100,	5465	);
insert into subs.substation values(2013111100,	5466	);
insert into subs.substation values(2013111100,	5467	);
insert into subs.substation values(2013111100,	5468	);
insert into subs.substation values(2013111100,	5469	);
insert into subs.substation values(2013111100,	5470	);
insert into subs.substation values(2013111100,	5471	);
insert into subs.substation values(2013111100,	5472	);
insert into subs.substation values(2013111100,	5473	);
insert into subs.substation values(2013111100,	4844	);
insert into subs.substation values(2013111100,	5255	);
insert into subs.substation values(2013111100,	5281	);
insert into subs.substation values(2013111100,	5284	);