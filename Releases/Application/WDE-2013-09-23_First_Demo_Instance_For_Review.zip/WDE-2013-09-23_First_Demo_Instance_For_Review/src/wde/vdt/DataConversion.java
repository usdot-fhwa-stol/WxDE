/************************************************************************
 * Source filename: DataConversion.java
 * 
 * Creation date: Sep 19, 2013
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.vdt;

import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;

import ucar.ma2.Array;
import ucar.ma2.ArrayChar;
import ucar.ma2.ArrayDouble;
import ucar.ma2.DataType;
import ucar.ma2.Index;
import ucar.ma2.InvalidRangeException;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.NetcdfFileWriteable;

public class DataConversion {
    
    private static DataConversion instance = null;
    
    private DataConversion()
    {
        // Any initialization can be placed here
    }
    
    public static DataConversion getInstance()
    {
        if (instance == null)
            instance = new DataConversion();

        return instance;
    }

    /**
     * @param data
     * @return
     */
    public NetcdfFile createNcFileFromData(ArrayList<Byte> data, String dataSetName)
    {
        NetcdfFile ncFile = null;

        // Create an array to copy bytes into
        byte[] byteArray = new byte[data.size()];
        
        ListIterator<Byte> byteIterator = data.listIterator(0);
        
        int nByte = -1;
        
        // Copy all the bytes
        while(byteIterator.hasNext())
            byteArray[++nByte] = byteIterator.next();
        
        try {
            // Create the NetcdfFile object from the byte array
            ncFile = NetcdfFile.openInMemory(dataSetName, byteArray);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        return ncFile;
    }
    
    public void readDataFromNcFile()
    {
        
    }
    
    public void createNcFile(String filepath) throws IOException {
        // Create new netcdf-3 file with the given filename, with fill = false. 
        // Seting fill = true causes everything to be written twice: first with the fill value, 
        // then with the data values. If you know you will write all the data, 
        // you dont need to use fill. If you don't know if all the data will be written, 
        // turning fill on ensures that any values not written will have the fill value. 
        // Otherwise those values will be undefined: possibly zero, or possibly garbage. 
        NetcdfFileWriteable ncfile = NetcdfFileWriteable.createNew(filepath, false);

        // Create two Dimensions, named lat and lon, of lengths 64 and 128 respectively, and add them to the file.
        Dimension latDim = ncfile.addDimension("lat", 64);
        Dimension lonDim = ncfile.addDimension("lon", 128);

        // define Variable
        ArrayList<Dimension> dims = new ArrayList<>();
        dims.add(latDim);
        dims.add(lonDim);

        // Create a list consisting of the two Dimension, and create a Variable named temperature, of type double, with shape (lat, lon) 
        ncfile.addVariable("temperature", DataType.DOUBLE, dims);

        // Add an Attribute to the temperature variable, with name units and value K. 
        ncfile.addVariableAttribute("temperature", "units", "K");

        // Create a 1D Array of length 3, whose values are {1,2,3}. Attributes can be scalars or 1D arrays of any type and length. 
        Array data = Array.factory(int.class, new int[] { 3 }, new int[] { 1, 2, 3 });

        // Add an attribute to the temperature Variable, with name scale and value (1,2,3).
        ncfile.addVariableAttribute("temperature", "scale", data);

        // add a string-valued variable: char svar(80)
        Dimension svar_len = ncfile.addDimension("svar_len", 80);
        dims = new ArrayList<>();
        dims.add(svar_len);

        // Create a Variable named svar of type character with length 80. 
        ncfile.addVariable("svar", DataType.CHAR, dims);

        // string array: char names(3, 80)
        Dimension names = ncfile.addDimension("names", 3);
        ArrayList<Dimension> dima = new ArrayList<>();
        dima.add(names);
        dima.add(svar_len);
        
        // Create a 2D Variable named names of type character with shape (3,80).
        ncfile.addVariable("names", DataType.CHAR, dima);

        // Create a scalar Variable named scalar of type double. Note that the empty ArrayList means that it is a scalar, ie has no Dimensions.
        ncfile.addVariable("scalar", DataType.DOUBLE, new ArrayList());

        // Create various global Attributes of different types. 
        ncfile.addGlobalAttribute("yo", "face");
        ncfile.addGlobalAttribute("versionD", new Double(1.2));
        ncfile.addGlobalAttribute("versionF", new Float(1.2));
        ncfile.addGlobalAttribute("versionI", new Integer(1));
        ncfile.addGlobalAttribute("versionS", new Short((short)2));
        ncfile.addGlobalAttribute("versionB", new Byte((byte)3));

        // create the file
        try {
            // Create the file. At this point the (empty) file will be written to disk, 
            // and the metadata (Dimensions, Variables and Atributes) is fixed and cannot be changed or added.
            ncfile.create();
        }
        catch (IOException e) {
            // The ncfile.getLocation() method will return the filename. 
            System.err.println("ERROR creating file " + ncfile.getLocation() + "\n" + e);
        }

        // Write data to the new file or open an existing file
        // NetcdfFileWriteable ncfile = NetcdfFileWriteable.openExisting(filepath, true);

        // Much of the work of writing is constructing the data Arrays. 
        // Here we create a 2D Array of shape (lat, lon) and fill it with some values.
        ArrayDouble A = new ArrayDouble.D2(latDim.getLength(), lonDim.getLength());
        int i, j;
        Index ima = A.getIndex();
        for (i = 0; i < latDim.getLength(); i++) {
            for (j = 0; j < lonDim.getLength(); j++) {
                A.setDouble(ima.set(i, j), (double)(i * 1000000 + j * 1000));
            }
        }

        // A newly created Java integer array is guarenteed to be initialized to zeros.
        int[] origin = new int[2];
        try {
            // We write the data to the temperature Variable, with origin all zeros. 
            // The shape is taken from the data Array.
            ncfile.write("temperature", origin, A);
        }
        catch (IOException e) {
            System.err.println("ERROR writing file");
        }
        catch (InvalidRangeException e) {
            e.printStackTrace();
        }

        // write char variable as String
        try {
            // The ArrayChar class has special methods to make it convenient to work with Strings. 
            // Note that we use the type and rank specific constructor ArrayChar.D1. 
            // The setString(String val) method is for rank one ArrayChar objects.
            ArrayChar ac2 = new ArrayChar.D1(svar_len.getLength());
            ac2.setString("Two pairs of ladies stockings!");

            // Write the data. Since we dont pass in an origin parameter, it is assumed to be all zeroes. 
            ncfile.write("svar", ac2);
        }
        catch (IOException e) {
            System.err.println("ERROR writing Achar2");
        }
        catch (InvalidRangeException e) {
            e.printStackTrace();
        }

        // write String array
        try {
            // The setString(int index, String val) method is for rank two ArrayChar objects.
            ArrayChar ac2 = new ArrayChar.D2(names.getLength(), svar_len.getLength());
            ac2.setString(0, "0 pairs of ladies stockings!");
            ac2.setString(1, "1 pair of ladies stockings!");
            ac2.setString(2, "2 pairs of ladies stockings!");
            ncfile.write("names", ac2);
        }
        catch (IOException e) {
            System.err.println("ERROR writing Achar4");
        }
        catch (InvalidRangeException e) {
            e.printStackTrace();
        }

        // write scalar data
        try {
            // Working with type and rank specific Array objects provides convenient set() methods. 
            // Here, we have a rank-0 (scalar) double Array, whose set() methods sets the scalar value.
            ArrayDouble.D0 datas = new ArrayDouble.D0();
            datas.set(222.333);
            ncfile.write("scalar", datas);
        }
        catch (IOException e) {
            System.err.println("ERROR writing scalar");
        }
        catch (InvalidRangeException e) {
            e.printStackTrace();
        }

        try {
            // This ensures writing the data to disk. 
            // NetcdfFileWriteable.flush() will flush to disk without closing.
            ncfile.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        DataConversion dc = DataConversion.getInstance();
        try {
            String filepath = "c:\\tmp\\testWrite.nc";
            dc.createNcFile(filepath);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
