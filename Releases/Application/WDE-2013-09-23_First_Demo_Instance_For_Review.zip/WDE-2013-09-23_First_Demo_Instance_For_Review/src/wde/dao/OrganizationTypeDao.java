package wde.dao;

import java.util.List;

import wde.data.OrganizationType;

public interface OrganizationTypeDao {
	
	public List<OrganizationType> getOrganizationTypes();

}
