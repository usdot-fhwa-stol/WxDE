/************************************************************************
 * Source filename: QualityCheckFlags.java
 * 
 * Creation date: May 1, 2013
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.util;

public class QualityCheckFlags {

    private int runFlags;
    
    private int passFlags;

    public QualityCheckFlags(int rf, int pf) {
        runFlags = rf;
        passFlags = pf;
    }
    
    /**
     * @return the runFlags
     */
    public int getRunFlags() {
        return runFlags;
    }

    /**
     * @return the passFlags
     */
    public int getPassFlags() {
        return passFlags;
    }
}
