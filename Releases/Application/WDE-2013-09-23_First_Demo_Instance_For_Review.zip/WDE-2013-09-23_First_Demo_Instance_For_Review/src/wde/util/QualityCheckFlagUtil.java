/************************************************************************
 * Source filename: QualityCheckFlags.java
 * 
 * Creation date: Apr 30, 2013
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.util;

public class QualityCheckFlagUtil {

    private static final int qcLength = 12;
    private static String padding = "000000000000";
    private static char[] qcChars = {'/', '-', 'N', 'P'};
    
    public static int getQcLength() {
        return qcLength;
    }
    
    public static char[] getQcCharFlags(int runFlags, int passFlags) {
        char[] qcCharFlags = new char[qcLength];
        
        String runFlagStr = Integer.toBinaryString(runFlags);
        runFlagStr = padding.substring(runFlagStr.length()) + runFlagStr;
        
        String passFlagStr = Integer.toBinaryString(passFlags);
        passFlagStr = padding.substring(passFlagStr.length()) + passFlagStr;
        
        for (int i = 0; i < qcLength; i++) {
            String key = "" + runFlagStr.charAt(i) + passFlagStr.charAt(i);
            qcCharFlags[11-i] = qcChars[Integer.parseInt(key, 2)];
        }
        
        return qcCharFlags;
    }
    
    public static QualityCheckFlags getFlags(char[] flagStr) {
        QualityCheckFlags qcf = null;
        int rf = 0;
        int pf = 0;
        for (int i = qcLength-1; i >= 0; i--) {
            switch (flagStr[i]) {
                case '/':
                    break;
                case '-':
                    pf += 1;
                    break;
                case 'N':
                    rf += 1;
                    break;
                case 'P':
                    rf += 1;
                    pf += 1;
                    break;
            }
            rf = rf << 1;
            pf = pf << 1;
        }
        rf = rf >> 1;
        pf = pf >> 1;
        
        qcf = new QualityCheckFlags(rf, pf);
        
        return qcf;
    }
    
    public static void main(String[] args) {
        char[] qcCharFlags = getQcCharFlags(5, 7);
        for (int i = 0; i < 12; i++)
            System.out.println(qcCharFlags[i]);
        
        System.out.println(String.valueOf(qcCharFlags));
        
        QualityCheckFlags qcf = getFlags(qcCharFlags);
        System.out.println(qcf.getRunFlags());
        System.out.println(qcf.getPassFlags());
    }
}
