$.fn.makeItFade=function(playSpeed){var slideIndex=0,arrSlide=$(this).children(),totalSlides=arrSlide.size()-1;$.fn.fadeAway=function(){this.animate({"opacity":0},"slow").animate({"right":999},0)};$.fn.fadeInto=function(){this.animate({"right":"25px"},0).animate({"opacity":1},"slow")};$("#play").hide();$.fn.nextPlease=function(){$(this[slideIndex]).fadeAway();slideIndex++;if(slideIndex>totalSlides)slideIndex=0;$(this[slideIndex]).fadeInto()};$.fn.bringSexyBack=function(){$(this[slideIndex]).fadeAway();
slideIndex--;if(slideIndex<0)slideIndex=totalSlides;$(this[slideIndex]).fadeInto()};$("#next").click(function(){arrSlide.nextPlease()});$("#prev").click(function(){$(arrSlide).bringSexyBack()});$("#play").click(function(){$(this).hide();$("#pause").show();$("#play-box").prop("checked",true)});$("#pause").click(function(){$(this).hide();$("#play").show();$("#play-box").prop("checked",false)});setInterval(function(){if($("#play-box").is(":checked"))$(arrSlide).nextPlease()},playSpeed)};


// Easy jQuery fader plugin 2013
// author: Robert Roth
// newFader.min.js
