var forgotPassword = false, // if true user forgot password, else user forgot User ID
	currentStep = 0,
	arrStep = $('#retrievalSteps > #steps').children(),
	arrHeader = $('#stepsHeaders').children();

// preparations for the app to work properly
// separated for flexibility and readability
initialSettings = function(){
	for (var i = 1; i < arrStep.length; i++)
		$(arrStep[i]).css({marginLeft : '20px', opacity : 0}).hide(0);
	$(arrHeader[0]).css({color : '#555', cursor : 'text'});
	currentStep = 0;
};

// animate next step
nextStep = function(){
	$(arrStep[currentStep]).animate({marginLeft : '-20px', opacity : 0}, 500).hide(0);
	$(arrHeader[currentStep]).css({cursor : 'pointer'}).animate({color : '#CCC'}, 500).addClass('active');
	$(arrStep[++currentStep]).show(0).delay(500).animate({marginLeft : '0px', opacity : 1}, 500);
	$(arrHeader[currentStep]).css({cursor : 'text'}).animate({color : '#555'}, 500);
};

// going back a previous step
prevStep = function(){
	$(arrStep[currentStep]).animate({marginLeft : '20px', opacity : 0}, 500).hide(0);
	$(arrHeader[currentStep]).css({cursor : 'not-allowed'}).animate({color : '#CCC'}, 500);
	$(arrStep[--currentStep]).delay(600).show(0).animate({marginLeft : '0px', opacity : 1}, 500);
	$(arrHeader[currentStep]).css({cursor : 'text'}).animate({color : '#555'}, 500);
};

$(function(){
	
	initialSettings();
	
	$("#forgotPassword").click(function(){
		nextStep();
		$('input[name="email"]').focus();
		forgotPassword = true;

		$("#backStep, #step"+currentStep).click(function(){
			$("#backStep, #step"+currentStep).off(0);
			prevStep();
		});
	});
	
	$("#forgotUserID").click(function(event){
		nextStep();
		$('input[name="email"]').focus();
		forgotPassword = false;

		$("#backStep, #step"+currentStep).click(function(){
			$("#backStep, #step"+currentStep).off(0);
			prevStep();
		});
	});
	
	$('#submitEmail').click(function(e) {
		e.preventDefault();
		nextStep();
		for (var i = currentStep - 1; i >= 0; i-- )
			$(arrHeader[i]).css({cursor : 'not-allowed'}).animate({color : '#CCC'}, 500).off(0);
	});
});