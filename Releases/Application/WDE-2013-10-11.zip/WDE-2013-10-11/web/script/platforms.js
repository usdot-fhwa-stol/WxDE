$( function(){
	//start/show loader.gif
	$('#loading').fadeIn()
	
	var locHash = location.hash.split("#")[1]
		hashSource = locHash.split('.')[0],
		dataSource = locHash.split('.')[1],
		jsonSource = '/resources/platforms/contributor/' + hashSource

	$('#sourceName').html(dataSource)
	
	//for functionality/effect for the loader.gif
	setTimeout( function() {	
	$.getJSON(jsonSource, populatePlatform)
	
	function populatePlatform(data) {
		
		$.each(data.platform, function(key, value){
			strToTime = value.toTime
			if (strToTime == undefined || typeof strToTime == 'object') {
				strToTime = "<td class=\"align-center\"><span style=\"color: #999\">none</span></td>"
				saveToTime = "none"
			} else {
				strToTime = '<td>'+ strToTime +'</td>'
			}
			$('.reports-table').append(
				'<tr>'
					+ '<td>'
					+ value.platformCode
					+ '</td>'
					+ '<td class="align-center">'
					+ value.category
					+ '</td>'
					+ '<td>'
					+ value.description
					+ '</td>'
					+ '<td>'
					+ value.locBaseLat
					+ '</td>'
					+ '<td>'
					+ value.locBaseLong
					+ '</td>'
					+ '<td class="align-center">'
					+ value.locBaseElev
					+ '</td>'
					+ '<td>'
					+ value.updateTime
					+ '</td>'
					+ strToTime
				+ '</tr>')
		})
	}
		$('#loading').fadeOut()

	}, 1000)//end setTimeout()

	
	var table = $('#sortable-table')

	$('#sort-update, #sort-to-time').css("cursor", "pointer").wrapInner(
			'<span class="explode" title="Click to sort this column"/>').each(
			function() {

				var th = $(this), thIndex = th.index(), inverse = false, caret
				th.bind("click", function() {

					table.find('td').filter(function() {

						return $(this).index() === thIndex

					}).sortElements(
							function(a, b) {

								return $.text([ a ]) > $.text([ b ]) ? inverse ? -1
										: 1 : inverse ? 1 : -1

							}, function() {

								// parentNode is the element we want to move
								return this.parentNode;

							});

					if (inverse == true)
						caret = "icon-sort-up"
					else
						caret = "icon-sort-down"

					$(this).find(".icon-stack").html(
							'<i class="icon-sort" style="color: #AAA;"></i>'
									+ '<i class="' + caret + '"></i>');

					inverse = !inverse

				});

			});

	
})//end of jQuery