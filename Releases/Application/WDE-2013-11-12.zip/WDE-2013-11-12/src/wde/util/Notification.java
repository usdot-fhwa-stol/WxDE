/************************************************************************
 * Source filename: Notification.java
 * 
 * Creation date: Sep 3, 2013
 * 
 * Author: zhengg
 * 
 * Project: WDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class Notification {
    
    private static Logger logger = Logger.getLogger(Notification.class);
    
    private static Notification instance = null;
    private Config config = null;
    private Properties props = null;
    
    public static Notification getInstance() {
        if (instance == null)
            instance = new Notification();

        return instance;
    }

    private Notification()
    {
        config = ConfigSvc.getInstance().getConfig(Notification.this);
        
        props = new Properties();
        String str = config.getString("mail.smtp.host", null);
        logger.info("mail.smtp.host:" + str);
        props.put("mail.smtp.host", config.getString("mail.smtp.host", null));
    }
    
    public void sendEmail(ArrayList<InternetAddress> recipients, String subject, String messageBody, String filePath, String fileDisplayName)
    {
        if (recipients.isEmpty()) {
            logger.info("sendEmail invoked with empty recipients");
            return;
        }
        
        Session session = Session.getInstance(props);
        
        try {

            // send one message when status changes to unacceptable
            // and a second message when normal operation resumes
            MimeMessage message = new MimeMessage(session);
            message.setSentDate(new Date());
    
            for (int nIndex = 0; nIndex < recipients.size(); nIndex++)
                message.setRecipient(Message.RecipientType.TO, recipients.get(nIndex));
    
            String str = config.getString("bcc", null);
            logger.info("bcc: " + str);
            message.setRecipient(Message.RecipientType.BCC, new InternetAddress(config.getString("bcc", null)));
    
            str = config.getString("mail.from", null);
            logger.info("from: " + str);
            message.setFrom(new InternetAddress(config.getString("mail.from", null)));
            //message.setFrom(new InternetAddress("george.zheng@leidos.com"));
    
             // create and fill the first message part
            MimeBodyPart msgText = new MimeBodyPart();
            msgText.setText(messageBody);
    
            // create the second message part
            MimeBodyPart msgFile = new MimeBodyPart();
            if (filePath != null) {
                msgFile.attachFile(filePath);
                msgFile.setFileName(fileDisplayName);
            }
    
            // create the Multipart message and add the parts to it
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(msgText);
            multipart.addBodyPart(msgFile);
    
            // add the Multipart to the message
            message.setContent(multipart);
    
            message.setSubject(subject);
            
            Transport.send(message); // very last step
            
            System.out.println("Done");
        }
        catch (MessagingException me) {
            logger.error(me.getMessage());
            me.printStackTrace();
        }
        catch (IOException ie) {
            logger.error(ie.getMessage());
            ie.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
              
        Notification notification = Notification.getInstance();
        
        ArrayList<InternetAddress> recipients = new ArrayList<>();
        InternetAddress me = null;
        try {
            me = new InternetAddress("george.zheng@leidos.com");
        }
        catch (AddressException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        recipients.add(me);
        
        notification.sendEmail(recipients, "notification test", args[0], args[1], args[2]);
    }
}
