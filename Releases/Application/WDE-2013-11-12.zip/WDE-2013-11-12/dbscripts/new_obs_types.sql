# Executed on dev, test, demo

insert into meta.obstype values(2000002, '2013-11-07 14:02:16', 'mobileABS', null, 'anti-lock brake status', null, TRUE, null);
insert into meta.obstype values(2000003, '2013-11-07 14:02:16', 'mobileBrakeBoost', null, 'brake boost applied status', null, TRUE, null);
insert into meta.obstype values(2000004, '2013-11-07 14:02:16', 'mobileBrakeStatus', null, 'brake applied status', null, TRUE, null);
insert into meta.obstype values(2000005, '2013-11-07 14:02:16', 'mobileHeading', 'degrees clockwise from true North', 'heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2000006, '2013-11-07 14:02:16', 'mobileLatAccel', '10^-1 meters per second squared', 'horizontal lateral acceleration', 'm/s^2', TRUE, 'ft/s^2');
insert into meta.obstype values(2000007, '2013-11-07 14:02:16', 'mobileLongAccel', '10^-1 meters per second squared', 'horizontal longitudinal acceleration', 'm/s^2', TRUE, 'ft/s^2');
insert into meta.obstype values(2000008, '2013-11-07 14:02:16', 'mobileSpeed', '10^-1 meters per second', 'vehicle speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2000009, '2013-11-07 14:02:16', 'mobileStab', null, 'stability control status', null, TRUE, null);
insert into meta.obstype values(2000010, '2013-11-07 14:02:16', 'mobileSteeringAngle', 'degrees clockwise from true North', 'steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2000011, '2013-11-07 14:02:16', 'mobileSteeringRate', 'degrees per second', 'steering wheel angle rate of change', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2000012, '2013-11-07 14:02:16', 'mobileTrac', null, 'traction control state', null, TRUE, null);
insert into meta.obstype values(2000013, '2013-11-07 14:02:16', 'mobileYawRate', 'degrees per second', 'yaw rate', 'deg/s', TRUE, 'deg/s');

insert into conf.unit values(13, 'm/s^2', 'ft/s^2', 3.28084, 1, 0);