# Executed on dev, test

# 1. Add additional columns for mobile/VDT data
ALTER TABLE obs.invalidObs ADD COLUMN sourceid integer;
ALTER TABLE obs.invalidObs ADD COLUMN latitude integer;
ALTER TABLE obs.invalidObs ADD COLUMN longitude integer;
ALTER TABLE obs.invalidObs ADD COLUMN qchcharflag character(1)[];

# 2. initialize these columns for existing data in the table
UPDATE obs.invalidObs SET sourceid=1;

# 3. Update WxDE App to use additional columns

# 4. Remove obs with sensorid -1 as we don't have anyway to recover them
DELETE FROM obs."obs_2013-11-05" where sourceid=2 and sensorid=-1