#executed on test

# startday is for 2014 and endday is for 2013
update conf.timezone set startmonth='MARCH', startday=9, endmonth='NOVEMBER', endday=3, enddayofweek='-SUNDAY';