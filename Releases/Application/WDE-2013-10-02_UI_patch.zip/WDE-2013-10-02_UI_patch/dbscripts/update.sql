-- Update table distgroup
update meta.distgroup set description = 'Do not send platforms nor observations' where id=1;
insert into meta.distgroup values(0, 'Show platforms but not observations');

-- Update distgroup of sensor table for those that don't belong to (Alaska, Colorado, Delaware, Idaho, Illinois, Iowa, Kansas, Michigan,
-- Minnesota, Missouri, Montana, Nevada, New Hampshire, New Jersey, New York, North Dakota, Oregon, Texas, Vermont, Wisconsin, Wyoming)
update meta.sensor set distgroup=0 where contribid not in (1, 10, 12, 16, 17, 70, 66, 72, 19, 20, 71, 68, 26, 
2, 28, 29, 31, 32, 33, 35, 37, 40, 46, 47, 51, 52) and contribid<>4 and distgroup=2

-- update meta.platform
update meta.platform set platformcode='FremontJunction' where platformcode='FreemontJunction'

-- update invalidobs
 