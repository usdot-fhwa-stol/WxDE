package wde.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import wde.data.Feedback;


public class FeedbackDaoImpl implements FeedbackDao {
	
	@Override
	public void insertNewFeedback(Feedback feedback) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);

		try {
			session.insert("wde.FeedbackMapper.insertNewFeedback", feedback);
		} finally {
			session.close();
		}			
	}
}
