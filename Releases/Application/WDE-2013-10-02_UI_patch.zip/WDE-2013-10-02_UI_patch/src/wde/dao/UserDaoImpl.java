package wde.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import wde.data.User;
import wde.util.ShaHasher;


public class UserDaoImpl implements UserDao {

	@Override
	public void insertNewUser(User user) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);

		//Hash the Password
		user.setPassword(ShaHasher.hash(user.getPassword()));

		try {
			session.insert("wde.UserMapper.insertNewUser", user);
		} finally {
			session.close();
		}			
	}

	@Override
	public User getUser(String userId) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);
		User user = null;
		try {
			user = session.selectOne("wde.UserMapper.selectUser", userId);
		} finally {
			session.close();
		}
		return user;
	}

	@Override
	public void updateUser(User user) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);

		//Hash the Password
		user.setPassword(ShaHasher.hash(user.getPassword()));

		try {
			session.insert("wde.UserMapper.updateUser", user);
		} finally {
			session.close();
		}			
	}

}
