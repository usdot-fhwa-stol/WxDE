package wde.dao;

import wde.data.Feedback;


public interface FeedbackDao {
	
	public void insertNewFeedback(Feedback feedback);

}
