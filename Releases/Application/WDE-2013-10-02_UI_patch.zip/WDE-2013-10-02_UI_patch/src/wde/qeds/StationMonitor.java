// Copyright (c) 2010 Mixon/Hill, Inc. All rights reserved.
/**
 * @file StationMonitor.java
 */
package wde.qeds;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import wde.WDEMgr;
import wde.dao.DatabaseManager;
import wde.dao.ObservationDao;
import wde.dao.PlatformDao;
import wde.dao.SensorDao;
import wde.metadata.IPlatform;
import wde.metadata.ISensor;
import wde.obs.IObs;
import wde.obs.IObsSet;
import wde.util.Config;
import wde.util.ConfigSvc;
import wde.util.Introsort;
import wde.util.Scheduler;
import wde.util.threads.AsyncQ;

/**
 * Wraps all cached stations and their corresponding set of observations
 * together to be registered and processed by the WDE manager.
 * <p>
 * Singleton class whose instance can be retrieved with the
 * {@link StationMonitor#getInstance()}.
 * </p>
 * <p>
 * Extends {@code AsyncQ<IObsSet>} to allow processing of the observations set
 * as it is enqueued.
 * </p>
 */
public class StationMonitor extends AsyncQ<IObsSet>
{
    private static final Logger logger = Logger.getLogger(StationMonitor.class);
    
	/**
	 * Configured timeout, defaults to 14400000. Determines when stations
	 * should be flagged as having new observations (if it has been updated
	 * since the timeout).
	 */
	private static long TIMEOUT = 14400000;
	/**
	 * Pointer to station monitor instance.
	 */
	private static StationMonitor g_oInstance = new StationMonitor();
	/**
	 * List of stations, and their corresponding observations.
	 */
	private final ArrayList<StationObs> m_oStationList = new ArrayList<>();
	/**
	 * Pointer to {@code WDEMgr} singleton instance.
	 */
	private WDEMgr wdeMgr = WDEMgr.getInstance();
	/**
	 * Pointer to {@code PlatformDao}.
	 */
	private PlatformDao platformDao = PlatformDao.getInstance();
	/**
	 * Pointer to {@code Sensors} cache.
	 */
	private SensorDao sensorDao = SensorDao.getInstance();
	/**
	 * Station-observation pair used for searching the stations list.
	 */
	private StationObs m_oSearchStation = new StationObs();
	/**
	 * Comparator enforces ordering by station-id.
	 */
	private SortByStation m_oSortByStation = new SortByStation();
	/**
	 * Object used to schedule removal time of expired obs and mobile stations.
	 */
	private Cleanup m_oCleanup = new Cleanup();
	

	/**
	 * <b> Accessor </b>
	 * @return singleton instance of {@code StationMonitor}.
	 */
	public static StationMonitor getInstance()
	{
		return g_oInstance;
	}
	

	/**
	 * Creates new instances of {@code StationMonitor}. Configures the station
	 * monitor. Populates the station list with cached stations. Updates the
	 * station distribution group with the corresponding cached sensor
	 * distribution group. Registers the station monitor with the system
	 * manager.
	 */
	private StationMonitor()
	{
		// apply the station monitor configuration
		ConfigSvc oConfigSvc = ConfigSvc.getInstance();
		Config oConfig = oConfigSvc.getConfig(this);

		// increase the queue depth for more thread concurrency
		TIMEOUT = oConfig.getLong("timeout", TIMEOUT);

		// initialize the platform list
		ArrayList<IPlatform> platforms = platformDao.getActivePlatforms();

		synchronized(this)
		{
			int nIndex = platforms.size();
			m_oStationList.ensureCapacity(nIndex);
			while (nIndex-- > 0)
			{
				IPlatform platform = platforms.get(nIndex);
				if (platform == null)
				    logger.info("***********found one platform that is null");

				if (platform.getCategory() == 'M')
					continue; // only permanent stations are initialized here

				StationObs oStationObs = new StationObs(platform);
				if (platform.getContribId() == 4)
					oStationObs.m_nDistGroup = 1;
				m_oStationList.add(oStationObs);
			}

			// sort the newly acquired stations by id
			Introsort.usort(m_oStationList, m_oSortByStation);
		}
		initialize();

		// schedule cleanup process every five minutes
		Scheduler.getInstance().schedule(m_oCleanup, 13, 300);

        // register the station monitor with system manager
		wdeMgr.register(getClass().getName(), this);
		logger.info("Completing constructor");
	}

	
	/**
	 * Populates the current set of platforms with the most recent observations 
	 * from storage. This is used to hot start the in-memory view that supports 
	 * browser map and other data interfaces.
	 */
	private void initialize()
	{
		logger.info("restore StationMonitor begin");
		GregorianCalendar oNow = new GregorianCalendar();
		oNow.setTimeInMillis(oNow.getTimeInMillis() - TIMEOUT);
		long lEnd = oNow.getTimeInMillis() + 2 * TIMEOUT;

		DatabaseManager oDbMgr = DatabaseManager.getInstance();
		String sConnId = oDbMgr.getConnection();

        try
        {
			String sPrevTable = "";
    		while (oNow.getTimeInMillis() < lEnd)
    		{
    		    String sTableName = String.format("obs_%d-%02d-%02d", 
					oNow.get(Calendar.YEAR), oNow.get(Calendar.MONTH) + 1, 
					oNow.get(Calendar.DAY_OF_MONTH));
				
				if (sTableName.compareTo(sPrevTable) == 0)
					break; // quit when last table name needed is reached

				sPrevTable = sTableName; // save current table name
				DatabaseMetaData oDbMeta = oDbMgr.getMetaData(sConnId);
                ResultSet oTables = oDbMeta.getTables(null, null, sTableName, null);
                if (!oTables.next())
				{
                    oTables.close();
                    logger.debug(sTableName + " does not exist");
                    break;
                }
                oTables.close();
            
				String sQuery = String.format("SELECT obstypeid, sourceid, " + 
					"sensorid, obstime, recvtime, latitude, longitude, " + 
					"elevation, value, confvalue, qchcharflag, qchintflag " + 
					"FROM obs.\"%s\" WHERE recvtime >= '%d-%02d-%02d %02d:%02d'", 
					sTableName, oNow.get(Calendar.YEAR), oNow.get(Calendar.MONTH) + 1, 
					oNow.get(Calendar.DAY_OF_MONTH), oNow.get(Calendar.HOUR_OF_DAY), 
					oNow.get(Calendar.MINUTE));

				ResultSet oResultSet = oDbMgr.query(sConnId, sQuery);
				while (oResultSet != null && oResultSet.next())
					updatePlatform(ObservationDao.retrieveObs(oResultSet));

				oResultSet.close();
           
    			// increment time by one day
    			oNow.setTimeInMillis(oNow.getTimeInMillis() + TIMEOUT);
    		}
        }
        catch (Exception oException)
        {
			logger.error("StationMonitor initialize", oException);
        }

		oDbMgr.releaseConnection(sConnId);
		logger.info("restore StationMonitor end");
	}

	
	/**
	 * Connects observations with platforms. If the platform is not in the list,
	 * one is created and added to the list. Otherwise, the observation
	 * is added to the set of observations contained by the corresponding
	 * platform. The platform is then updated with the current time to indicate 
	 * that it contains current information.
	 * @param iObs individual observation to associate with a platform.
	 */
	private void updatePlatform(IObs iObs)
	{
		StationObs oStation = null;
		
		// find the sensor and then the station to which it belongs
		ISensor iSensor = sensorDao.getSensor(iObs.getSensorId());
		if (iSensor == null)
			return;

		IPlatform platform = platformDao.getPlatform(iSensor.getPlatformId());
		if (platform == null)
			return;

		synchronized(m_oStationList)
		{
			// search for the station in the managed list
			m_oSearchStation.m_nId = platform.getId();
			m_oSearchStation.m_nLat = iObs.getLatitude();
			m_oSearchStation.m_nLon = iObs.getLongitude();

			int nStationIndex = Collections.binarySearch(m_oStationList,
				m_oSearchStation, m_oSortByStation);

			// add new stations as they become available
			if (nStationIndex < 0)
			{
				oStation = new StationObs(platform);
				oStation.m_nLat = iObs.getLatitude(); // copy obs location
				oStation.m_nLon = iObs.getLongitude(); // for mobile platforms
				oStation.m_tElev = iObs.getElevation();
				m_oStationList.add(~nStationIndex, oStation);
			}
			else
				oStation = m_oStationList.get(nStationIndex);
		}

		// update the station distribution group to the highest available
		if (iSensor.getDistGroup() > oStation.m_nDistGroup)
			oStation.m_nDistGroup = iSensor.getDistGroup();

		// set the latest update timestamp
		if (oStation.addObs(iObs) && 
			iObs.getObsTimeLong() > oStation.m_lLastUpdate)
			oStation.m_lLastUpdate = iObs.getObsTimeLong();
	}

	
	/**
	 * Traverses the provided observation set and determines which platform 
	 * should be updated with the new observation data. The observation set is 
	 * then queued to the system manager for subsequent processing.
	 * @param iObsSet set of observations to process.
	 */
    @Override
	public void run(IObsSet iObsSet)
	{
		// add the obs to the station and set the latest update timestamp
		int nObsIndex = iObsSet.size();
		while (nObsIndex-- > 0)
			updatePlatform(iObsSet.get(nObsIndex));
		
		// queue the obs set for the next process
		wdeMgr.queue(iObsSet);
	}


	/**
	 * Retrieves the station from the list corresponding to the provided
	 * station id.
	 * @param nId id of the station of interest.
	 * @return the station corresponding to the supplied id if contained in the
	 * list, else null.
	 */
    StationObs getStation(int nId, int nLat, int nLon)
    {
        synchronized(m_oStationList)
        {
            m_oSearchStation.m_nId = nId;
			m_oSearchStation.m_nLat = nLat;
			m_oSearchStation.m_nLon = nLon;

			int nIndex = Collections.binarySearch(m_oStationList,
                    m_oSearchStation, m_oSortByStation);

            if (nIndex >= 0)
                return m_oStationList.get(nIndex);
        }

        return null;
    }
	

	/**
	 * <b> Accessor </b>
	 * @return a copy of the station-obs list.
	 */
	ArrayList<StationObs> getStations()
	{
        ArrayList<StationObs> oStations = new ArrayList<>();

        synchronized(m_oStationList)
        {
			int nIndex = m_oStationList.size();
			oStations.ensureCapacity(nIndex);
			while (nIndex-- > 0)
				oStations.add(m_oStationList.get(nIndex));
        }
		
		return oStations;
	}


	/**
	 * Implements {@code Comparator<StationObs>} to enforce an ordering based
	 * off station id.
	 */
	private class SortByStation implements Comparator<StationObs>
	{
        /**
         * <b> Default Constructor </b>
		 * <p>
		 * Creates new instances of {@code SortByStationId}
		 * </p>
         */
		private SortByStation()
		{
		}


		/**
		 * Compares the provided {@code StationObs} by station id.
		 *
		 * @param oLhs object to compare to {@code oRhs}
		 * @param oRhs object to compare to {@code oLhs}
		 * @return 0 if the objects match by station id and geo-coordinates.
		 */
		@Override
		public int compare(StationObs oLhs, StationObs oRhs)
		{
			int nDiff = oLhs.m_nId - oRhs.m_nId;
			if (nDiff != 0)
				return nDiff;

			nDiff = oLhs.m_nLat - oRhs.m_nLat;
			if (nDiff != 0)
				return nDiff;

			return (oLhs.m_nLon - oRhs.m_nLon);
		}
	}


	private class Cleanup implements Runnable
	{
		Cleanup()
		{
		}


		@Override
		public void run()
		{
			long lNow = System.currentTimeMillis();
			long lExpired = lNow - TIMEOUT;
			long lExpiredMobile = lNow - 3600000; // one hour timeout

            synchronized(m_oStationList)
            {
				int nIndex = m_oStationList.size();
				while (nIndex-- > 0)
				{
					StationObs oStation = m_oStationList.get(nIndex);

					// flag all stations that have obs older than the timeout
					oStation.m_bHasObs = (oStation.m_lLastUpdate >= lExpired);

					if (oStation.m_iStation.getCategory() == 'M')
					{
						// expired mobile stations get removed from the list
						if (oStation.m_lLastUpdate < lExpiredMobile)
							m_oStationList.remove(nIndex);
					}
				}
			}
		}
	}
}
