package wde.ws;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import wde.dao.orm.FeedbackDao;
import wde.dao.orm.FeedbackDaoImpl;
import wde.data.Feedback;


@Path("feedback")
public class FeedbackResource {
	
    @Context
    HttpServletRequest request;
    @Context
    HttpServletResponse response;
    @Context
    ServletContext context;
    
    private FeedbackDao feedbackDao;

	@POST
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public void postNewUser(Feedback feedback) {
		feedbackDao = new FeedbackDaoImpl();
		if (request.getRemoteUser() != null) {
			feedback.setUserName(request.getRemoteUser());
		}
		feedbackDao.insertNewFeedback(feedback);
	}

	@GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List<Feedback> getFeedbacks(){
    	feedbackDao = new FeedbackDaoImpl();
    	List<Feedback> feedbacks = feedbackDao.getFeedbacks();
    	return feedbacks;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("test/{id}")
    public String testForward(@PathParam("id") Integer id) {
    	
    	String url = "/frequentlyAskedQuestions.jsp";
    	if (id == 1) {
    		url = "/termsOfUse.jsp";
    	} else if (id == 2) {
    		url = "/changeLog.jsp";
    	}
    	
    	RequestDispatcher dispatcher =  context.getRequestDispatcher(url);
    	try {
			dispatcher.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return null;
    }
}
