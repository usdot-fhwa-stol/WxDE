package wde.dao.orm;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import wde.dao.WdeDbSessionManager;
import wde.data.Contributor;

public class ContributorDaoImpl implements ContributorDao {

	@Override
	public List<Contributor> getContributors() {
		SqlSessionFactory sqlMapper = WdeDbSessionManager
				.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);
		List<Contributor> retList = null;
		try {
			retList = session
					.selectList("wde.MetadataMapper.selectDisplayContributers");
		} finally {
			session.close();
		}
		return retList;
	}

}
