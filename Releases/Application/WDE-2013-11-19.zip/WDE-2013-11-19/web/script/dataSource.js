$(function() {
	//start/show loader.gif
	$('#loading').fadeIn('slow');
	
	var exitLinkURL = '',
	    strDisclaimer = "",
	    saveDisclaimer = "";

	var jsonContributors;
    var str = '';
    var line = '';
    
    function JSON2CSV(objArray) {

        var array = objArray.contributor;

        var str = '';
        var line = '';

        for (var index in array[0]) {
            var value = index + "";
            line += '"' + value.replace(/"/g, '""') + '",';
        }

        line = line.slice(0, -1);
        str += line + ',\r\n';

        for (var i = 0; i < array.length; i++) {
            var line = '';

            for (var index in array[i]) {
                if (typeof array[i][index] != 'object') {
                    var val = array[i][index] + "";
                    line += '"' + val.replace(/"/g, '""') + '",';
                } else {
                	line += ',';
                }
            }

            line = line.slice(0, -1);
            str += line + ',\r\n';
        }
        return str;
        
    }
    
    //for functionality/effect for the loader.gif
	setTimeout( function() {

		$.ajax({url:'/resources/contributors', dataType: 'json', success: populateData, cache: false});

		function populateData(data) {
			jsonContributors = JSON2CSV(data);
	        $.each( 
					data.contributor,
					function(key, value) {
						strDisclaimer = value.disclaimer;
						if (strDisclaimer == undefined || typeof strDisclaimer == 'object') {
							strDisclaimer = "<td class=\"align-center\"><span style=\"color: #999\">none</span></td>";
							saveDisclaimer = "none";
						}
						else {
							saveDisclaimer = strDisclaimer;
							strDisclaimer = '<td class=\"align-center\"><a href="'
								+ strDisclaimer
								+ '" class="btn-dark align-center exit-link"><i class="icon-file-text-alt"></i> View</a>';
						};
									
						$('.reports-table').append(
							'<tr>'
								+ '<td id="sourceName" data-type="'
								+ value.name
								+ '">'
								+ value.name
								+ '</td>'
								+ '<td>'
								+ value.agency
								+ '</td>'
								+ strDisclaimer
								+ '<td><a href="/auth/platforms.jsp#'
								+ value.contributorId + '.' + value.name
								+ '" class="btn-dark align-center"><i class="icon-file-text-alt"></i> View</a>'
							+ '</tr>');
					} //end function(key, value)
				); //end $.each
				
			$(".exit-link").click(
					function(e) {
						e.preventDefault();
						exitLinkURL = $(this).attr("href");
						$("#link").html(
								'<em style="text-decoration: underline; margin-right: 19px;">'
										+ exitLinkURL
										+ "</em>");
						$("#dialog").dialog("open");
					});
					
			$('#saveDataSource').on('click', function(){
				window.open("data:text/csv;charset=utf-8," + escape(jsonContributors));
			});
			
		}//end of function populateData()

		$('#loading').fadeOut();

	}, 1000);//end setTimeout()

	$("#dialog").dialog({
		autoOpen : false,
		resizable : false,
		height : "auto",
		width: "auto",
		modal : true,
		show : {
			effect : "fade",
			duration : 1E3
		},
		hide : {
			effect : "fade",
			duration : 1E3
		},
		buttons : {
			"Continue" : function() {
				$(this).dialog("close");
				window.open(exitLinkURL);
			},
			Cancel : function() {
				$(this).dialog("close");
			}
		}
	});
});

var table = $('#sortable-table');

$('#sort-name, #sort-agency').css("cursor", "pointer").wrapInner(
		'<span class="explode" title="Click to sort this column"/>').each(
		function() {

			var th = $(this), thIndex = th.index(), inverse = false, caret;
			th.bind("click", function() {

				table.find('td').filter(function() {

					return $(this).index() === thIndex;

				}).sortElements(
						function(a, b) {

							return $.text([ a ]) > $.text([ b ]) ? inverse ? -1
									: 1 : inverse ? 1 : -1;

						}, function() {

							// parentNode is the element we want to move
							return this.parentNode;

						});

				if (inverse == true)
					caret = "icon-sort-up";
				else
					caret = "icon-sort-down";

				$(this).find(".icon-stack").html(
						'<i class="icon-sort" style="color: #AAA;"></i>'
								+ '<i class="' + caret + '"></i>');

				inverse = !inverse;

			});

		});
