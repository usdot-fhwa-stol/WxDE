# Executed on all instances

insert into meta.obstype values(2000002, '2013-11-07 14:02:16', 'mobileABS', null, 'anti-lock brake status', null, TRUE, null);
insert into meta.obstype values(2000003, '2013-11-07 14:02:16', 'mobileBrakeBoost', null, 'brake boost applied status', null, TRUE, null);
insert into meta.obstype values(2000004, '2013-11-07 14:02:16', 'mobileBrakeStatus', null, 'brake applied status', null, TRUE, null);
insert into meta.obstype values(2000005, '2013-11-07 14:02:16', 'mobileHeading', 'degrees clockwise from true North', 'heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2000006, '2013-11-07 14:02:16', 'mobileLatAccel', '10^-1 meters per second squared', 'horizontal lateral acceleration', 'm/s^2', TRUE, 'ft/s^2');
insert into meta.obstype values(2000007, '2013-11-07 14:02:16', 'mobileLongAccel', '10^-1 meters per second squared', 'horizontal longitudinal acceleration', 'm/s^2', TRUE, 'ft/s^2');
insert into meta.obstype values(2000008, '2013-11-07 14:02:16', 'mobileSpeed', '10^-1 meters per second', 'vehicle speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2000009, '2013-11-07 14:02:16', 'mobileStab', null, 'stability control status', null, TRUE, null);
insert into meta.obstype values(2000010, '2013-11-07 14:02:16', 'mobileSteeringAngle', 'percent', 'steering wheel angle', '%', TRUE, '%');
insert into meta.obstype values(2000011, '2013-11-07 14:02:16', 'mobileSteeringRate', null, 'steering wheel angle rate of change', null, TRUE, null);
insert into meta.obstype values(2000012, '2013-11-07 14:02:16', 'mobileTrac', null, 'traction control state', null, TRUE, null);
insert into meta.obstype values(2000013, '2013-11-07 14:02:16', 'mobileYawRate', null, 'yaw rate', null, TRUE, null);

insert into conf.unit values(13, 'm/s^2', 'ft/s^2', 3.28084, 1, 0);