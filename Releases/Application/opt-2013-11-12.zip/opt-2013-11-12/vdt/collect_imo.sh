java -cp wde.jar:lib/log4j-1.2.13.jar:lib/netcdfAll-4.0.jar wde.cs.imo.MnDot 207.67.22.117 4501 5 /opt/vdt/data/raw/IMO/ ameritrak
