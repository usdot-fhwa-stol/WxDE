package wde.ws;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import wde.dao.orm.ContributorDaoImpl;
import wde.data.Contributor;

@Path("contributors")
public class ContributorResource {

	private ContributorDaoImpl contributorDao;
	
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List<Contributor> getContributors(){
    	contributorDao = new ContributorDaoImpl();
    	return contributorDao.getContributors();
    }
}
