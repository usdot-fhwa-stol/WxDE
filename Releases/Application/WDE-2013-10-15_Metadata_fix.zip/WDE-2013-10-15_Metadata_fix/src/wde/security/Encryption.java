/************************************************************************
 * Source filename: TripleDES.java
 * 
 * Creation date: February 11, 2013
 * 
 * Author: zhengg
 * 
 * Project: WxDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/
package wde.security;

import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Encryption
{
    private static String seed = "3J_^y1u275uJ6WxdeQrJMy";

    public Encryption(String _seed)
    {
        seed = _seed;
    }

    public static String encryptToString(String message) throws Exception
    {
        return Base64Encoder.encode(encrypt(message));
    }

    public static String decryptToString(String encodedString) throws Exception
    {
        return new String(decrypt(encodedString), "UTF-8");
    }

    public static String decryptToString(byte[] encodedBytes) throws Exception
    {
        return new String(decrypt(encodedBytes), "UTF-8");
    }

    public static byte[] encrypt(String message) throws Exception
    {
        final MessageDigest md = MessageDigest.getInstance("md5");
        final byte[] digestOfPassword = md.digest(seed.getBytes("utf-8"));

        final byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);

        for (int j = 0, k = 16; j < 8;)
        {
            keyBytes[k++] = keyBytes[j++];
        }

        final SecretKey key = new SecretKeySpec(keyBytes, "DESede");
        final IvParameterSpec iv = new IvParameterSpec(new byte[8]);
        final Cipher cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);

        final byte[] plainTextBytes = message.getBytes("utf-8");
        final byte[] cipherText = cipher.doFinal(plainTextBytes);

        return cipherText;
    }

    public static byte[] decrypt(String encodedString) throws Exception
    {

        byte[] message = Base64Decoder.decode(encodedString);
        final MessageDigest md = MessageDigest.getInstance("md5");
        final byte[] digestOfPassword = md.digest(seed.getBytes("utf-8"));

        final byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);

        for (int j = 0, k = 16; j < 8;)
        {
            keyBytes[k++] = keyBytes[j++];
        }

        final SecretKey key = new SecretKeySpec(keyBytes, "DESede");
        final IvParameterSpec iv = new IvParameterSpec(new byte[8]);
        final Cipher decipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");
        decipher.init(Cipher.DECRYPT_MODE, key, iv);

        final byte[] plainText = decipher.doFinal(message);

        return plainText;
    }

    public static byte[] decrypt(byte[] encodedBytes) throws Exception
    {
        final MessageDigest md = MessageDigest.getInstance("md5");
        final byte[] digestOfPassword = md.digest(seed.getBytes("utf-8"));

        final byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);

        for (int j = 0, k = 16; j < 8;)
        {
            keyBytes[k++] = keyBytes[j++];
        }

        final SecretKey key = new SecretKeySpec(keyBytes, "DESede");
        final IvParameterSpec iv = new IvParameterSpec(new byte[8]);
        final Cipher decipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");
        decipher.init(Cipher.DECRYPT_MODE, key, iv);

        final byte[] plainText = decipher.doFinal(encodedBytes);

        return plainText;
    }
    
    public static void main(String[] args) throws Exception
    {
        System.out.println();
        
        if(args != null && args.length > 0 && args[0].equalsIgnoreCase("-pwd")) {
            System.out.println("=-=-=-=-=-=-= BELOW IS YOUR PASSWORD ENCRYPTED IN 3DES =-=-=-=-=-=-=");
            System.out.println();
            System.out.println(Encryption.encryptToString(args[1]));
            System.out.println();
            System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        }
        else {
            System.out.println("Either no arguments were provided or invalid arguments were entered");
        }
    }
}
