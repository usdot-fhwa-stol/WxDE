package wde.util;
import java.util.ArrayList;
import java.util.Collections;

import ucar.ma2.ArrayChar;
import ucar.ma2.ArrayDouble;
import ucar.ma2.ArrayInt;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;


public class SegmentMapping implements Comparable<SegmentMapping>
{
	String m_sName;
	String m_sId;
	ArrayList<Double> m_oLat = new ArrayList();
	ArrayList<Double> m_oLon = new ArrayList();


	SegmentMapping()
	{
	}


	SegmentMapping(String sName, String sId)
	{
		m_sName = sName;
		m_sId = sId;
		m_oLat = new ArrayList();
		m_oLon = new ArrayList();
	}


	void print()
	{
		System.out.print(m_sName);
		for (int nIndex = 0; nIndex < m_oLat.size(); nIndex++)
		{
			System.out.print(" ");
			System.out.print(String.format("%06f", m_oLat.get(nIndex)));
			System.out.print(",");
			System.out.print(String.format("%06f", m_oLon.get(nIndex)));
		}
		System.out.println();
	}


	void printPlatform(int nIndex)
	{
		int nMid = m_oLat.size() / 2;

		System.out.println(String.format("INSERT INTO meta.platform (staticid, " +
			"updatetime, platformcode, segmentId, category, description, contribid, " +
			"siteid, locbaselat, locbaselong) VALUES (%d, '2013-12-11', '%s', '%s', " +
			"'S', 'MnDOT VDT road segment %s', 2, 5818, %f, %f);",
			nIndex + 20001, m_sName, m_sId, m_sName, m_oLat.get(nMid), m_oLon.get(nMid)));
	}


	@Override
	public int compareTo(SegmentMapping oRhs)
	{
		return m_sName.compareTo(oRhs.m_sName);
	}


	public static void main(String[] sArgs)
		throws Exception
	{
		StringBuilder sBuffer1 = new StringBuilder();
		StringBuilder sBuffer2 = new StringBuilder();
		ArrayList<SegmentMapping> oPlatforms = new ArrayList();
		SegmentMapping oSearch = new SegmentMapping();

		NetcdfFile oNcFile = NetcdfFile.open("C:/tmp/vdt/data/static/cdl/mn_roads.nc");
		Variable oSegName = oNcFile.findVariable("seg_name");
		Variable oSegId = oNcFile.findVariable("seg_id");
		Variable oLat = oNcFile.findVariable("latitude");
		Variable oLon = oNcFile.findVariable("longitude");

		ArrayChar.D2 oSegs1 = (ArrayChar.D2)oSegName.read();
		ArrayInt.D1 oSegs2 = (ArrayInt.D1)oSegId.read();
		ArrayDouble.D1 oLats = (ArrayDouble.D1)oLat.read();
		ArrayDouble.D1 oLons = (ArrayDouble.D1)oLon.read();

		int[] nShape1 = oSegs1.getShape();
		for (int nRow = 0; nRow < nShape1[0]; nRow++)
		{
		    sBuffer1.setLength(0);
		    sBuffer2.setLength(0);
			for (int nCol = 0; nCol < nShape1[1]; nCol++)
			{
				if (oSegs1.get(nRow, nCol) != 0)
				    sBuffer1.append(oSegs1.get(nRow, nCol));
			}
			if (oSegs2.get(nRow) != 0)
			    sBuffer2.append(oSegs2.get(nRow));

			oSearch.m_sName = sBuffer1.toString();
			oSearch.m_sId = sBuffer2.toString();
			int nIndex = Collections.binarySearch(oPlatforms, oSearch);
			if (nIndex < 0)
			{
				nIndex = ~nIndex;
				oPlatforms.add(nIndex, new SegmentMapping(oSearch.m_sName, oSearch.m_sId));
			}
			SegmentMapping oPlatform = oPlatforms.get(nIndex);

			oPlatform.m_oLat.add(new Double(oLats.get(nRow)));
			oPlatform.m_oLon.add(new Double(oLons.get(nRow)));
		}

		for (int nIndex = 0; nIndex < oPlatforms.size(); nIndex++)
			oPlatforms.get(nIndex).printPlatform(nIndex);

		oNcFile.close();
	}
}
