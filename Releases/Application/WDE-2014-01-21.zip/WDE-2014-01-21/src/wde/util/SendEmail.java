package wde.util;

import java.util.ArrayList;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;

import wde.data.Email;

public class SendEmail {
	
	public static void send(HttpServletRequest _req, Email email) {
		String serverName = _req.getServerName();
		System.out.println("Server Name -> " + serverName);
		
		SendEmail se = new SendEmail();
		// use gmail for local and test
    	if ("localhost".equals(serverName) || "10.10.10.28".equals(serverName)) {
    		se.sendGmail(email.getTo(), email.getSubject(), email.getBody());
    	} else {
    		se.sendEmail(email.getTo(), email.getSubject(), email.getBody());
    	}
	}
	
	public void sendEmail(String to, String subject, String body) {
    	ArrayList<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();
    	try {
			emailAddresses.add(new InternetAddress(to));
	    	Notification tryEmail = Notification.getInstance();
	    	tryEmail.sendEmail(emailAddresses, subject, body, null, null);
    	} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sendGmail(String to, String subject, String body) {
		final String strUsername = "weatherdataenvironment@gmail.com";
        final String strPassword = "W3@ther1";
        final String strFrom = "weatherdataenvironment@gmail.com";
        
        Properties mailProp = new Properties();
        mailProp.put("mail.smtp.auth", "true");
        mailProp.put("mail.smtp.stattls.enable", "true");
        mailProp.put("mail.smtp.host", "smtp.gmail.com"); //smtp server address
        mailProp.put("mail.smtp.port", "465"); //port for smtp server
        mailProp.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        
        Session mailSession;
        mailSession = Session.getInstance( mailProp, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(strUsername, strPassword);
                }
        });

        try {
            Message mailMsg = new MimeMessage(mailSession);
            mailMsg.setFrom(new InternetAddress(strFrom)); //from address
            mailMsg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to)); //to address
            mailMsg.setSubject(subject);
            mailMsg.setContent("<h:body style=background-color:white;"
                             + "font-family:verdana;"
                             + "color:#555;>"
                             + body + "<br/><br/>"
                             + "</body>", "text/html; charset=UTF-8");
            
            Transport.send(mailMsg);
            
            System.out.println("Email Sent");
            
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
	}
	
    public static void main(String[] args) {
		Email email = new Email();
		email.setTo("ROBERT.M.ROTH@leidos.com");
		email.setSubject("WXDE Email Subject");
		email.setBody("Hello World");
		
		SendEmail se = new SendEmail();
		se.sendGmail(email.getTo(), email.getSubject(), email.getBody());
    }
}
