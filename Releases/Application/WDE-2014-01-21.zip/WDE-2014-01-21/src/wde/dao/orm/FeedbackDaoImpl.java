package wde.dao.orm;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import wde.dao.WdeDbSessionManager;
import wde.data.Feedback;


public class FeedbackDaoImpl implements FeedbackDao {
	
	@Override
	public void insertNewFeedback(Feedback feedback) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);

		Date date = new Date();
		long milis = date.getTime();
		Timestamp timeStamp = new Timestamp(milis);

		feedback.setDateCreated(date);
		feedback.setTsCreated(timeStamp);
		
		try {
			session.insert("wde.FeedbackMapper.insertNewFeedback", feedback);
		} finally {
			session.close();
		}			
	}

	@Override
	public List<Feedback> getFeedbacks() {
		SqlSessionFactory sqlMapper = WdeDbSessionManager
				.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);
		List<Feedback> retList = null;
		try {
			retList = session
					.selectList("wde.FeedbackMapper.selectFeedbacks");
		} finally {
			session.close();
		}
		return retList;
	}

	@Override
	public void deleteFeedback(String id) {
		SqlSessionFactory sqlMapper = WdeDbSessionManager.getSqlSessionFactory();
		SqlSession session = sqlMapper.openSession(true);
		try {
			session.delete("wde.FeedbackMapper.deleteFeedback", id);
		} finally {
			session.close();
		}
	}
}
