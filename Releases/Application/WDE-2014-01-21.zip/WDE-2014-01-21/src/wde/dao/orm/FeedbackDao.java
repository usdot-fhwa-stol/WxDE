package wde.dao.orm;

import java.util.List;

import wde.data.Feedback;


public interface FeedbackDao {
	
	public void insertNewFeedback(Feedback feedback);
	public List<Feedback> getFeedbacks();
	public void deleteFeedback(String id);

}
