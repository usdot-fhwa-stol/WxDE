package wde.dao.orm;

import java.util.List;

import wde.data.Country;


public interface CountriesDao {

	public List<Country> getCountries();

}
