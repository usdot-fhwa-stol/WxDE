/************************************************************************
 * Source filename: ObservationDao.java
 * 
 * Creation date: Feb 26, 2013
 * 
 * Author: zhengg
 * 
 * Project: WxDE
 * 
 * Objective:
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.dao;

import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

import org.apache.log4j.Logger;

import wde.metadata.QualityFlag;

import wde.obs.ObsValue;
import wde.obs.Observation;

import wde.util.DatabaseArrayParser;
import wde.util.DateRange;
import wde.util.QueryString;
import wde.util.coord.CoordinateConversion;

public class ObservationDao {
    
    private static final Logger logger = Logger.getLogger(ObservationDao.class);
    
    private static final String SELECT_OBSTYPE_SENSOR_OBSTIME_QUERY = "SELECT * FROM obs.obs WHERE obsTypeId = ? AND sensorId = ? AND obsTime = ?";
    
    private static final String INSERT_QUERY = "INSERT INTO obs.obs (obsTypeId, sourceId, sensorId, obsTime, recvTime, "
        + "latitude, longitude, elevation, value, confValue, qchCharFlag, qchIntFlag)  "
        + "VALUES (?,?,?,?,?,?,?,?,?,?,?::character[],?::integer[])";
    
    private static final String INSERT_INVALIDOBS_QUERY = "INSERT INTO obs.invalidObs "
        + "(sourceId, contribId, platformCode, obsTypeId, sensorIndex, obsTime, recvTime, latitude, longitude, value, qchcharflag) "
        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::character[])";
    
    private static ObservationDao instance;

    private DatabaseManager db = null;
    
    private String connId = null;
    
    private String sharedConnId = null;
    
    private QualityFlagDao qfd = null;
    
    private int insertCounter;
    
    private int updateCounter;
    
    private DatabaseArrayParser dap = null;
    
    private PreparedStatement batchInsertStatement = null; 

    /**
     * @return ImageDao
     */
    public static ObservationDao getInstance() {
        if (instance == null)
            instance = new ObservationDao();

        return instance;
    }

    /**
     * @param obsTypeId
     * @param sensorId
     * @param obsTime
     * @return observation object from the database
     */
    public ArrayList<Observation> getObservations(int obsTypeId, int sensorId, Timestamp obsTime) {
        
        ArrayList<Observation> observations = new ArrayList<Observation>();

        PreparedStatement ps = db.prepareStatement(connId, SELECT_OBSTYPE_SENSOR_OBSTIME_QUERY);
        ResultSet rs = null;

        try {
            ps.setInt(1, obsTypeId);
            ps.setInt(2, sensorId);
            ps.setTimestamp(3, obsTime);
            rs = ps.executeQuery();

            while (rs != null && rs.next()) {
                observations.add(retrieveObs(rs));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        finally {
            try {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }

        return observations;
    }

    /**
     * @param obs
     * @param pStatement - use null for atomic insert; use batchInsertStatement for batch insert
     */
    public void insertObservation(Observation obs, PreparedStatement pStatement)
    {
        String qchCharFlagStr = null;
        String qchIntFlagStr = null;

        char[] charArr = obs.getQchCharFlag();
        if (charArr != null) {
            qchCharFlagStr = "";
            for (char aChar : charArr)
                qchCharFlagStr += "\"" + aChar + "\",";
            qchCharFlagStr = "{" + qchCharFlagStr.substring(0, qchCharFlagStr.length() - 1) + "}";
        }

        int[] intArr = obs.getQchIntFlag();
        if (intArr != null) {
            qchIntFlagStr = "";
            for (int anInt : intArr)
                qchIntFlagStr += anInt + ",";
            qchIntFlagStr = "{" + qchIntFlagStr.substring(0, qchIntFlagStr.length() - 1) + "}";
        }

        if (pStatement == null)
            pStatement = db.prepareStatement(connId, INSERT_QUERY);

        try {
            pStatement.setInt(1, obs.getObsTypeId());
            pStatement.setInt(2, obs.getSourceId());
            pStatement.setInt(3, obs.getSensorId());
            pStatement.setTimestamp(4, obs.getObsTime());
            pStatement.setTimestamp(5, obs.getRecvTime());
            pStatement.setInt(6, obs.getLatitude());
            pStatement.setInt(7, obs.getLongitude());
            pStatement.setInt(8, obs.getElevation());
            pStatement.setDouble(9, obs.getValue());
            pStatement.setFloat(10, obs.getConfValue());
            pStatement.setString(11, qchCharFlagStr);
            pStatement.setString(12, qchIntFlagStr);
            
            pStatement.executeUpdate();

            insertCounter++;
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
    }

    /**
     * @param obs
     * @param pStatement - use null for atomic insert; use batchInsertStatement for batch insert
     */
    public void insertInvalidObservation (
        int sourceId, int contribId, String platformCode, int obsTypeId, int sensorIndex, 
        Timestamp obsTime, Timestamp recvTime, int latitude, int longitude, double value, String qchCharFlagStr)
    {
        logger.debug("inserting invalid observation for sourceId: " + sourceId + " contribId: " + contribId
            + " platformCode: " + platformCode + " obsTypeId: " + obsTypeId
            + " sensorIndex: " + sensorIndex);
   
        PreparedStatement ps = db.prepareStatement(connId, INSERT_INVALIDOBS_QUERY);

        try {
            ps.setInt(1, sourceId);
            ps.setInt(2, contribId);
            ps.setString(3, platformCode);
            ps.setInt(4, obsTypeId);
            ps.setInt(5, sensorIndex);
            ps.setTimestamp(6, obsTime);
            ps.setTimestamp(7, recvTime);
            ps.setInt(8, latitude);
            ps.setInt(9, longitude);
            ps.setDouble(10, value);
            ps.setString(11, qchCharFlagStr);
            
            ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        finally {
            try {
                ps.close();
                ps = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
    }
    
    /**
     * @param observations
     * @return
     */
    public RecordCounter insertObservations(Collection<Observation> observations)
    {
        insertCounter = 0;
        updateCounter = 0;
        synchronized (sharedConnId) {
            db.updateAutoCommit(sharedConnId,  false);
            for (Observation obs : observations)
                insertObservation(obs, batchInsertStatement);

            db.updateAutoCommit(sharedConnId,  true);
        }
        logger.info("Inserted " + insertCounter + " records");
        logger.info("Updated " +  updateCounter + " records");
        
        RecordCounter rc = new RecordCounter();
        rc.setInsertCounter(insertCounter);
        rc.setUpdateCounter(updateCounter);
        
        return rc;
    }
    
    /**
     * Fix sensor ids that have been mis-allocated
     * 
     * @param dateStr
     */
    public void fixSensorIds(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        String table1 = "obs_" + dateStr;
        
        String sql = "select count(*) from information_schema.tables where table_name='" + table1 + "'";
        ResultSet rs = db.query(connId, sql);
        int count = 0;
        try {
            if (rs != null && rs.next())
                count = rs.getInt(1);
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }  
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
        if (count == 0) {
            logger.info("Table " + table + " doesn't exist"); 
            return;
        }
            
        sql = "UPDATE " + table + " o set sensorid=s.id1 from meta.sensor_mapping s where o.sensorid=s.id2 and o.obstime < s.time";
        int rows = db.update(connId, sql);
        logger.info("Updated " + rows + " sensor ids backward in " + table);
        
        sql = "UPDATE " + table + " o set sensorid=s.id2 from meta.sensor_mapping s where o.sensorid = s.id1 and o.obstime > s.time";
        rows = db.update(connId, sql);
        logger.info("Updated " + rows + " sensor ids forward in " + table);
    }
    
    /**
     * Remove older versions of observation duplicates
     * 
     * @param dateStr
     */
    public void detectDuplicates(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        
        String sql = "select sourceid, obstypeid, sensorid, obstime, count(*) from " + table 
            + "group by sourceid, obstypeid, sensorid, obstime having (count(*)>1);";
        ResultSet rs = db.query(connId, sql);
        try {
            if (rs != null && rs.next())
                System.out.println(" Table " + table + " has duplicates");
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }  
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
    }
    
    /**
     * Remove older versions of observation duplicates
     * 
     * @param dateStr
     */
    public void removeDuplicates(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        String table1 = "obs_" + dateStr;
        
        String sql = "select count(*) from information_schema.tables where table_name='" + table1 + "'";
        ResultSet rs = db.query(connId, sql);
        int count = 0;
        try {
            if (rs != null && rs.next())
                count = rs.getInt(1);
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }  
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
        if (count == 0) {
            logger.info("Table " + table + " doesn't exist"); 
            return;
        }
        
        sql = "ALTER TABLE " + table + " ADD COLUMN id integer";
        db.update(connId, sql);
        logger.info("Added column id to " + table);
        
        sql = "UPDATE " + table + " SET id = nextval('obs.obs_id_seq')";
        db.update(connId, sql);
        logger.info("Updated id values in " + table);
     
        sql = "DELETE from " + table + " o1 USING " + table + " o2 WHERE " 
            + "o1.sourceId = o2.sourceId AND "
            + "o1.obsTypeId = o2.obsTypeId AND "
            + "o1.sensorId = o2.sensorId AND "
            + "o1.obsTime = o2.obsTime AND "
            + "o1.id > o2.id";
        db.update(connId, sql);
        logger.info("Removed duplicates in " + table);
        
        sql = "ALTER TABLE " + table + " DROP COLUMN id";
        db.update(connId, sql);
        logger.info("Dropped column id in " + table);
    }
    
    /**
     * Vacuum the obs table for the given date to free up space
     * 
     * @param dateStr
     */
    public void vacuumTable(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        String table1 = "obs_" + dateStr;
        
        String sql = "select count(*) from information_schema.tables where table_name='" + table1 + "'";
        ResultSet rs = db.query(connId, sql);
        int count = 0;
        try {
            if (rs != null && rs.next())
                count = rs.getInt(1);
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }  
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
        if (count == 0) {
            logger.info("Table " + table + " doesn't exist"); 
            return;
        }
        
        sql = "VACUUM full " + table;
        db.update(connId, sql);
        logger.info("Vacuumed " + table);
    }
    
    public void dropTable(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        String table1 = "obs_" + dateStr;
        
        String sql = "select count(*) from information_schema.tables where table_name='" + table1 + "'";
        ResultSet rs = db.query(connId, sql);
        int count = 0;
        try {
            if (rs != null && rs.next())
                count = rs.getInt(1);
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }  
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
        if (count == 0) {
            logger.info("Table " + table + " doesn't exist"); 
            return;
        }
        
        sql = "drop table " + table;
        db.update(connId, sql);
        logger.info("Dropped " + table);
    }
    
    public void checkElevation(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        String sql = "select count(*) from " + table + " where elevation > 0";
        
        ResultSet rs = null;
        
        try {
            rs = db.query(connId, sql);

            if (rs != null && rs.next()) {
                logger.info(table + " contains " + rs.getInt("count") + " records with non-zero elevation"); 
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }  
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
    }
    
    public void fixElevationValue(String dateStr)
    {
        String table = "obs.\"obs_" + dateStr + "\"";
        String sql = "update " + table + " set elevation = elevation / 1000000";
        db.update(connId, sql);
        logger.info("Fixed elevation values in " + table);
    }
    
    /**
     * @param dateStr1
     * @param dateStr2
     * @param obsTypeIds
     */
    public void archiveObservations(String dateStr1, String dateStr2, Set<String> obsTypeIds)
    {
        ArrayList<Observation> observations = null;
        HashMap<String, ArrayList<Observation>> obsMap = new HashMap<>();
        Observation obs = null;
        String otgp = null;
        
        DateRange dr = new DateRange();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date bd = null;
        Date ed = null;
        
        try {
            bd = sdf.parse(dateStr1);
            ed = sdf.parse(dateStr2);
        }
        catch (ParseException pe) {
            pe.printStackTrace();
            return;
        }
        
        Timestamp beginDate = new Timestamp(bd.getTime());
        Timestamp endDate = new Timestamp(ed.getTime());
        dr.setBeginDate(beginDate);
        dr.setEndDate(endDate);
        
        for (String obsTypeId : obsTypeIds) {
            String obsTable = "obs.\"obs_" + dateStr1 + "\"";
            
            String sql = "WITH rows_to_move as (" 
                + "DELETE from "
                + obsTable + " WHERE "
                + "obsTypeId = " + obsTypeId + " RETURNING *) "
                + "SELECT * from rows_to_move";
            
            ResultSet rs = db.query(connId,  sql);
            
            logger.info("processing rows of obsTypeId: " + obsTypeId);
            
            try {
                int counter = 0;
                while (rs != null && rs.next()) {
                    obs = retrieveObs(rs);
                    String gridId = CoordinateConversion.latLon2UTM(obs.getLatitude(), obs.getLongitude(), true);
                    otgp = gridId + "-" + obsTypeId;
                    observations = obsMap.get(otgp);
                    if (observations == null) {
                        logger.info("create observations for obsTypeId: " + obsTypeId + " and gridId: " + gridId);
                        observations = new ArrayList<Observation>();
                        obsMap.put(otgp,  observations);
                    }
                    observations.add(obs);
                    counter++;
                }
                logger.info("finished adding " + counter + " records for obsTypeId: " + obsTypeId);
            }
            catch (SQLException e) {
                e.printStackTrace();
                logger.error(e.getMessage());
            }
            finally {
                try {
                    rs.close();
                    rs = null;
                }
                catch (SQLException se) {
                    // ignore
                }
            }
        }
        Set<String> otgps = obsMap.keySet();

        for (String otgpair : otgps) {
            observations = obsMap.get(otgpair);
            Collections.sort(observations);
            
            logger.info("start inserting " + observations.size() + " obs values for gridId-obsTypeId: " + otgpair);
            
            // Insert all records in observations in archiveObs
            // Insert ao
            int index = otgpair.indexOf('-');
            String sql = "INSERT INTO obs.archiveObs VALUES ("
                       + "'[" + QueryString.convert(dr.getBeginDate(), "", false)
                       + QueryString.convert(dr.getEndDate(), "", true) + ")', '"
                       + otgpair.substring(0, index) + "', "
                       + otgpair.substring(index+1) + ", ";

            String ovsStr = ""; 
            int counter = 0;
            for (Observation obs2 : observations) {
                ovsStr += "\"(" + getObsStr(obs2) + ")\", ";
                counter++;
            }

            sql += "'{" + ovsStr.substring(0, ovsStr.length()-2) + "}')";
            db.update(connId, sql);
            logger.info("inserted " + counter + " obs values for obsTypeId-gridId: " + otgpair);
        }
    }
    
    /**
     * Note the date range includes the begin date and does not include the end date
     * ;
     * @param dateStr1 - begin date
     * @param dateStr2 - end date
     * @param gridId
     * @param obsTypeId
     */
    public ObsValue[] getArchiveObs(String dateStr1, String dateStr2, String gridId, String obsTypeId) {
        
        ObsValue[] obsValues = null;
        String sql = "SELECT VALUE FROM obs.archiveobs WHERE duration = '[" + dateStr1 + "," + dateStr2 + ")'"
            + " AND gridId = '" + gridId + "'"
            + " AND obsTypeId = " + obsTypeId;
        ResultSet rs = db.query(connId,  sql);
        try {
            while (rs != null && rs.next()) {
                Array ovs = rs.getArray("value");
                String str = ovs.toString();
                ArrayList<String> strList = dap.postgresROW2StringList(str);

                obsValues = new ObsValue[strList.size()];
                int i = 0;
                for (String s : strList) {
                    obsValues[i++] = new ObsValue(s);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        finally {
            try {
                rs.close();
                rs = null;
            }
            catch (SQLException se) {
                // ignore
            }
        }
        
        return obsValues;
    }
    
    private String getObsStr(Observation obs) {
        String qchCharFlagStr = null;
        String qchIntFlagStr = null;

        QualityFlag qf = qfd.getQualityFlag(obs.getSourceId(), obs.getObsTime());
        
        int charFlagLen = qf.getQchCharFlagLen();
        int intFlagLen = qf.getQchIntFlagLen();
        
        if (charFlagLen > 0) {
            qchCharFlagStr = "";
            for (char aChar : obs.getQchCharFlag())
                qchCharFlagStr += aChar;
        }

        if (intFlagLen > 0) {
            qchIntFlagStr = "";
            for (int anInt : obs.getQchIntFlag())
                qchIntFlagStr += anInt + "|";
        }
        
        String str = QueryString.convertId(obs.getSourceId(), false) 
                   + QueryString.convertId(obs.getSensorId(), false) 
                   + QueryString.convert(obs.getObsTime(), "", false) 
                   + QueryString.convert(obs.getRecvTime(), "", false) 
                   + QueryString.convert(obs.getLatitude(), false)  
                   + QueryString.convert(obs.getLongitude(), false) 
                   + QueryString.convert(obs.getElevation(), false)
                   + QueryString.convert(obs.getValue(), false)
                   + QueryString.convert(obs.getConfValue(), false)
                   + qchCharFlagStr + ", "            
                   + qchIntFlagStr;
        
        return str;
    }
    
    /**
     * Constructor
     */
    private ObservationDao() {
        db = DatabaseManager.getInstance();
        connId = db.getConnection();
        sharedConnId = db.getConnection();
        qfd =  QualityFlagDao.getInstance();
        dap = new DatabaseArrayParser();      
        batchInsertStatement = db.prepareStatement(sharedConnId, INSERT_QUERY);
    }
    
    public static Observation retrieveObs(ResultSet rs) 
        throws SQLException
    {
        Observation obs = new Observation();
        obs.setObsTypeId(rs.getInt("obsTypeId"));
        obs.setSourceId(rs.getInt("sourceId"));
        obs.setSensorId(rs.getInt("sensorId"));
        obs.setObsTime(rs.getTimestamp("obsTime"));
        obs.setRecvTime(rs.getTimestamp("recvTime"));
        obs.setLatitude(rs.getInt("latitude"));
        obs.setLongitude(rs.getInt("longitude"));
        obs.setElevation(rs.getInt("elevation"));
        obs.setValue(rs.getDouble("value"));
        obs.setConfValue(rs.getFloat("confValue"));
        Array charArr = rs.getArray("qchCharFlag");
        if (charArr != null) {
            String[] strArray = (String[]) charArr.getArray();
            char[] charArray = new char[strArray.length];
            for (int i = 0; i < strArray.length; i++)
                charArray[i] = strArray[i].charAt(0);                
            obs.setQchCharFlag(charArray);
        }
        Array intArr = rs.getArray("qchIntFlag");
        if (intArr != null) {
            Integer[] IntArray = (Integer[]) intArr.getArray();
            int[] intArray = new int[IntArray.length];
            for (int i = 0; i < IntArray.length; i++)
                intArray[i] = IntArray[i];
            obs.setQchIntFlag(intArray);
        }
        return obs;
    }
}
