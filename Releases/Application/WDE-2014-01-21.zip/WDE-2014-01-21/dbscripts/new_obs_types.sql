# Executed on all instances

insert into meta.obstype values(2000002, '2013-11-07 14:02:16', 'mobileABS', null, 'anti-lock brake status', null, TRUE, null);
insert into meta.obstype values(2000003, '2013-11-07 14:02:16', 'mobileBrakeBoost', null, 'brake boost applied status', null, TRUE, null);
insert into meta.obstype values(2000004, '2013-11-07 14:02:16', 'mobileBrakeStatus', null, 'brake applied status', null, TRUE, null);
insert into meta.obstype values(2000005, '2013-11-07 14:02:16', 'mobileHeading', 'degrees clockwise from true North', 'heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2000006, '2013-11-07 14:02:16', 'mobileLatAccel', '10^-1 meters per second squared', 'horizontal lateral acceleration', 'm/s^2', TRUE, 'ft/s^2');
insert into meta.obstype values(2000007, '2013-11-07 14:02:16', 'mobileLongAccel', '10^-1 meters per second squared', 'horizontal longitudinal acceleration', 'm/s^2', TRUE, 'ft/s^2');
insert into meta.obstype values(2000008, '2013-11-07 14:02:16', 'mobileSpeed', '10^-1 meters per second', 'vehicle speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2000009, '2013-11-07 14:02:16', 'mobileStab', null, 'stability control status', null, TRUE, null);
insert into meta.obstype values(2000010, '2013-11-07 14:02:16', 'mobileSteeringAngle', 'degrees clockwise from true North', 'steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2000011, '2013-11-07 14:02:16', 'mobileSteeringRate', 'degrees per second', 'steering wheel angle rate of change', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2000012, '2013-11-07 14:02:16', 'mobileTrac', null, 'traction control state', null, TRUE, null);
insert into meta.obstype values(2000013, '2013-11-07 14:02:16', 'mobileYawRate', 'degrees per second', 'yaw rate', 'deg/s', TRUE, 'deg/s');

insert into conf.unit values(13, 'm/s^2', 'ft/s^2', 100, 30.48, 0);

insert into meta.obstype values(2001000, '2013-12-04 15:00:00', 'total_num_msg', null, 'total number of messages processed', null, TRUE, null);
insert into meta.obstype values(2001001, '2013-12-04 15:00:00', 'model_air_temp', '10^-1 degrees Celsius', 'air temperature from the model data', 'C', TRUE, 'F');
insert into meta.obstype values(2001002, '2013-12-04 15:00:00', 'model_bar_press', '10^-1 millibars, or 10^-1 hectopascals', 'barometric pressure from the model data', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001003, '2013-12-04 15:00:00', 'nss_air_temp_mean', '10^-1 degrees Celsius', 'mean air temperature for the nearest surface stations', 'C', TRUE, 'F');
insert into meta.obstype values(2001004, '2013-12-04 15:00:00', 'nss_bar_press_mean', '10^-1 millibars, or 10^-1 hectopascals', 'mean barometric pressure for the nearest surface stations', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001005, '2013-12-04 15:00:00', 'nss_dew_temp_mean', '10^-1 degrees Celsius', 'mean dew temp. for the nearest surface stations', 'C', TRUE, 'F');

# The following need conversion - discuss with Bryan
insert into meta.obstype values(2001006, '2013-12-04 15:00:00', 'nss_hourly_precip_mean', '10^-1 kg per sq meter', 'mean hourly precip for the nearest surface stations', 'cm', TRUE, 'in');
insert into meta.obstype values(2001007, '2013-12-04 15:00:00', 'nss_prevail_vis_mean', '10^-1 meters', 'mean prevailing vis. for the nearest surface stations', 'm', TRUE, 'ft');

insert into meta.obstype values(2001008, '2013-12-04 15:00:00', 'nss_wind_dir_mean', 'degrees clockwise from true North', 'mean wind_dir for the nearest surface stations', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001009, '2013-12-04 15:00:00', 'nss_wind_speed_mean', '10^-1 meters per second', 'mean wind_speed for the nearest surface stations', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001010, '2013-12-04 15:00:00', 'radar_cref', 'decibels relative to Z', 'composite reflectivity from radar grid', 'dBZ', TRUE, 'dBZ');
insert into meta.obstype values(2001011, '2013-12-04 15:00:00', 'radar_precip_flag', null, 'precip from radar grid', null, TRUE, null);
insert into meta.obstype values(2001012, '2013-12-04 15:00:00', 'radar_precip_type', null, 'precip type from radar grid', null, TRUE, null);
insert into meta.obstype values(2001013, '2013-12-04 15:00:00', 'cloud_mask', null, 'cloud mask from satellite grid', null, TRUE, null);

insert into meta.obstype values(2001014, '2013-12-04 15:00:00', 'num_msg_valid_air_temp', null, 'number of messages with valid air_temp values', null, TRUE, null);
insert into meta.obstype values(2001015, '2013-12-04 15:00:00', 'air_temp_iqr25', '10^-1 degrees Celsius', '25th percentile air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001016, '2013-12-04 15:00:00', 'air_temp_iqr75', '10^-1 degrees Celsius', '75th percentile air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001017, '2013-12-04 15:00:00', 'air_temp_max', '10^-1 degrees Celsius', 'maximum air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001018, '2013-12-04 15:00:00', 'air_temp_mean', '10^-1 degrees Celsius', 'average air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001019, '2013-12-04 15:00:00', 'air_temp_median', '10^-1 degrees Celsius', 'median air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001020, '2013-12-04 15:00:00', 'air_temp_min', '10^-1 degrees Celsius', 'minimum air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001021, '2013-12-04 15:00:00', 'air_temp_stdev', '10^-1 degrees Celsius', 'air temperature standard deviation', 'C', TRUE, 'F');
insert into meta.obstype values(2001022, '2013-12-04 15:00:00', 'air_temp_var', 'Celsius^2', 'air temperature variance', 'C^2', TRUE, 'F^2');

insert into conf.unit values(14, 'C^2', 'F^2', 25, 81, 0);

insert into meta.obstype values(2001023, '2013-12-04 15:00:00', 'num_msg_valid_air_temp2', null, 'number of messages with valid air_temp values', null, TRUE, null);
insert into meta.obstype values(2001024, '2013-12-04 15:00:00', 'air_temp2_iqr25', '10^-1 degrees Celsius', '25th percentile external air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001025, '2013-12-04 15:00:00', 'air_temp2_iqr75', '10^-1 degrees Celsius', '75th percentile external air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001026, '2013-12-04 15:00:00', 'air_temp2_max', '10^-1 degrees Celsius', 'maximum external air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001027, '2013-12-04 15:00:00', 'air_temp2_mean', '10^-1 degrees Celsius', 'average external air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001028, '2013-12-04 15:00:00', 'air_temp2_median', '10^-1 degrees Celsius', 'median external air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001029, '2013-12-04 15:00:00', 'air_temp2_min', '10^-1 degrees Celsius', 'minimum external air temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001030, '2013-12-04 15:00:00', 'air_temp2_stdev', '10^-1 degrees Celsius', 'external air temperature standard deviation', 'C', TRUE, 'F');
insert into meta.obstype values(2001031, '2013-12-04 15:00:00', 'air_temp2_var', 'Celsius^2', 'external air temperature variance', 'C^2', TRUE, 'F^2');

insert into meta.obstype values(2001032, '2013-12-04 15:00:00', 'num_msg_valid_bar_press', null, 'number of messages with valid bar_press values', null, TRUE, null);
insert into meta.obstype values(2001033, '2013-12-04 15:00:00', 'bar_press_iqr25', '10^-1 millibars, or 10^-1 hectopascals', '25th percentile barometric pressure', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001034, '2013-12-04 15:00:00', 'bar_press_iqr75', '10^-1 millibars, or 10^-1 hectopascals', '75th percentile barometric pressure', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001035, '2013-12-04 15:00:00', 'bar_press_max', '10^-1 millibars, or 10^-1 hectopascals', 'maximum barometric pressure', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001036, '2013-12-04 15:00:00', 'bar_press_mean', '10^-1 millibars, or 10^-1 hectopascals', 'minimum barometric pressure', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001037, '2013-12-04 15:00:00', 'bar_press_median', '10^-1 millibars, or 10^-1 hectopascals', 'median barometric pressure', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001038, '2013-12-04 15:00:00', 'bar_press_min', '10^-1 millibars, or 10^-1 hectopascals', 'minimum barometric pressure', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001039, '2013-12-04 15:00:00', 'bar_press_stdev', '10^-1 millibars, or 10^-1 hectopascals', 'barometric pressure standard deviation', 'mbar', TRUE, 'inHg');
insert into meta.obstype values(2001040, '2013-12-04 15:00:00', 'bar_press_var', 'mbar^2', 'barometric pressure standard deviation', 'mbar^2', TRUE, 'inHg^2');

# Check with Bryan
insert into conf.unit values(15, 'mbar^2', 'inHg^2', 1, 1146.76151325, 0);

insert into meta.obstype values(2001041, '2013-12-04 15:00:00', 'num_msg_valid_dew_temp', null, 'number of messages with valid dew_temp values', null, TRUE, null);
insert into meta.obstype values(2001042, '2013-12-04 15:00:00', 'dew_temp_iqr25', '10^-1 degrees Celsius', '25th percentile dew temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001043, '2013-12-04 15:00:00', 'dew_temp_iqr75', '10^-1 degrees Celsius', '75th percentile dew temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001044, '2013-12-04 15:00:00', 'dew_temp_max', '10^-1 degrees Celsius', 'maximum dew temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001045, '2013-12-04 15:00:00', 'dew_temp_mean', '10^-1 degrees Celsius', 'average dew temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001046, '2013-12-04 15:00:00', 'dew_temp_median', '10^-1 degrees Celsius', 'median dew temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001047, '2013-12-04 15:00:00', 'dew_temp_min', '10^-1 degrees Celsius', 'minimum dew temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001048, '2013-12-04 15:00:00', 'dew_temp_stdev', '10^-1 degrees Celsius', 'dew temperature standard deviation', 'C', TRUE, 'F');
insert into meta.obstype values(2001049, '2013-12-04 15:00:00', 'dew_temp_var', 'Celsius^2', 'dew temperature variance', 'C^2', TRUE, 'F^2');

insert into meta.obstype values(2001050, '2013-12-04 15:00:00', 'num_msg_valid_heading', null, 'number of messages with valid heading values', null, TRUE, null);
insert into meta.obstype values(2001051, '2013-12-04 15:00:00', 'heading_iqr25', 'degrees clockwise from true North', '25th percentile heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001052, '2013-12-04 15:00:00', 'heading_iqr75', 'degrees clockwise from true North', '75th percentile heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001053, '2013-12-04 15:00:00', 'heading_max', 'degrees clockwise from true North', 'maximum heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001054, '2013-12-04 15:00:00', 'heading_mean', 'degrees clockwise from true North', 'average heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001055, '2013-12-04 15:00:00', 'heading_median', 'degrees clockwise from true North', 'median heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001056, '2013-12-04 15:00:00', 'heading_min', 'degrees clockwise from true North', 'minimum heading', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001057, '2013-12-04 15:00:00', 'heading_stdev', 'degrees clockwise from true North', 'heading standard deviation', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001058, '2013-12-04 15:00:00', 'heading_var', 'degrees^2', 'heading variance', 'deg^2', TRUE, 'deg^2');

insert into meta.obstype values(2001059, '2013-12-04 15:00:00', 'num_msg_valid_hoz_accel_lat', null, 'number of messages with valid hoz_accel_lat values', null, TRUE, null);
insert into meta.obstype values(2001060, '2013-12-04 15:00:00', 'hoz_accel_lat_iqr25', '10^-1 meters per second squared', '25th percentile horizontal lateral acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001061, '2013-12-04 15:00:00', 'hoz_accel_lat_iqr75', '10^-1 meters per second squared', '75th percentile horizontal lateral acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001062, '2013-12-04 15:00:00', 'hoz_accel_lat_max', '10^-1 meters per second squared', 'maximum horizontal lateral acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001063, '2013-12-04 15:00:00', 'hoz_accel_lat_mean', '10^-1 meters per second squared', 'average horizontal lateral acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001064, '2013-12-04 15:00:00', 'hoz_accel_lat_median', '10^-1 meters per second squared', 'median horizontal lateral acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001065, '2013-12-04 15:00:00', 'hoz_accel_lat_min', '10^-1 meters per second squared', 'minimum horizontal lateral acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001066, '2013-12-04 15:00:00', 'hoz_accel_lat_stdev', '10^-1 meters per second squared', 'horizontal lateral acceleration standard deviation', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001067, '2013-12-04 15:00:00', 'hoz_accel_lat_var', null, 'horizontal lateral acceleration variance', null, TRUE, null);

insert into meta.obstype values(2001068, '2013-12-04 15:00:00', 'num_msg_valid_hoz_accel_lon', null, 'number of messages with valid hoz_accel_lon values', null, TRUE, null);
insert into meta.obstype values(2001069, '2013-12-04 15:00:00', 'hoz_accel_lon_iqr25', '10^-1 meters per second squared', '25th percentile horizontal longitudinal acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001070, '2013-12-04 15:00:00', 'hoz_accel_lon_iqr75', '10^-1 meters per second squared', '75th percentile horizontal longitudinal acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001071, '2013-12-04 15:00:00', 'hoz_accel_lon_max', '10^-1 meters per second squared', 'maximum horizontal longitudinal acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001072, '2013-12-04 15:00:00', 'hoz_accel_lon_mean', '10^-1 meters per second squared', 'average horizontal longitudinal acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001073, '2013-12-04 15:00:00', 'hoz_accel_lon_median', '10^-1 meters per second squared', 'median horizontal longitudinal acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001074, '2013-12-04 15:00:00', 'hoz_accel_lon_min', '10^-1 meters per second squared', 'minimum horizontal longitudinal acceleration', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001075, '2013-12-04 15:00:00', 'hoz_accel_lon_stdev', '10^-1 meters per second squared', 'horizontal longitudinal acceleration standard deviation', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001076, '2013-12-04 15:00:00', 'hoz_accel_lon_var', '10^-1 meters per second squared squared', 'horizontal longitudinal acceleration variance', '(m/s^2)^2', TRUE, '(ft/s^2)^2');

insert into meta.obstype values(2001077, '2013-12-04 15:00:00', 'num_msg_valid_abs', null, 'number of messages with valid abs value', null, TRUE, null);
insert into meta.obstype values(2001078, '2013-12-04 15:00:00', 'num_abs_engaged', null, 'number of messages with abs engaged', null, TRUE, null);
insert into meta.obstype values(2001079, '2013-12-04 15:00:00', 'num_abs_not_equipped', null, 'number of messages with abs not equipped', null, TRUE, null);
insert into meta.obstype values(2001080, '2013-12-04 15:00:00', 'num_abs_off', null, 'number of messages with abs off', null, TRUE, null);
insert into meta.obstype values(2001081, '2013-12-04 15:00:00', 'num_abs_on', null, 'number of messages with abs on', null, TRUE, null);

insert into meta.obstype values(2001082, '2013-12-04 15:00:00', 'num_msg_valid_brakes', null, 'number of messages with valid brakes values', null, TRUE, null);
insert into meta.obstype values(2001083, '2013-12-04 15:00:00', 'num_brakes_all_off', null, 'number of messages with all brakes off', null, TRUE, null);
insert into meta.obstype values(2001084, '2013-12-04 15:00:00', 'num_brakes_all_on', null, 'number of messages with all brakes on', null, TRUE, null);
insert into meta.obstype values(2001085, '2013-12-04 15:00:00', 'num_brakes_lf_active', null, 'number of messages with left front brake active', null, TRUE, null);
insert into meta.obstype values(2001086, '2013-12-04 15:00:00', 'num_brakes_lr_active', null, 'number of messages with left rear brake active', null, TRUE, null);
insert into meta.obstype values(2001087, '2013-12-04 15:00:00', 'num_brakes_rf_active', null, 'number of messages with right front brake active', null, TRUE, null);
insert into meta.obstype values(2001088, '2013-12-04 15:00:00', 'num_brakes_rr_active', null, 'number of messages with right rear brake active', null, TRUE, null);

insert into meta.obstype values(2001089, '2013-12-04 15:00:00', 'num_msg_valid_brakes_boost', null, 'num_brakes_boost_on', null, TRUE, null);
insert into meta.obstype values(2001090, '2013-12-04 15:00:00', 'num_brakes_boost_not_equipped', null, 'number of messages with brake boost not equipped', null, TRUE, null);
insert into meta.obstype values(2001091, '2013-12-04 15:00:00', 'num_brakes_boost_off', null, 'number of messages with brake boost off', null, TRUE, null);
insert into meta.obstype values(2001092, '2013-12-04 15:00:00', 'num_brakes_boost_on', null, 'number of messages with brake boost on', null, TRUE, null);

insert into meta.obstype values(2001093, '2013-12-04 15:00:00', 'num_msg_valid_lights', null, 'number of messages with valid lights value', null, TRUE, null);
insert into meta.obstype values(2001094, '2013-12-04 15:00:00', 'num_lights_automatic_control', null, 'number of messages with automatic lights control', null, TRUE, null);
insert into meta.obstype values(2001095, '2013-12-04 15:00:00', 'num_lights_drl', null, 'number of messages with daytime running lights On', null, TRUE, null);
insert into meta.obstype values(2001096, '2013-12-04 15:00:00', 'num_lights_fog', null, 'number of messages with fog lights on', null, TRUE, null);
insert into meta.obstype values(2001097, '2013-12-04 15:00:00', 'num_lights_hazard', null, 'number of messages with hazard lights on', null, TRUE, null);
insert into meta.obstype values(2001098, '2013-12-04 15:00:00', 'num_lights_high_beam', null, 'number of messages with high beam on', null, TRUE, null);
insert into meta.obstype values(2001099, '2013-12-04 15:00:00', 'num_lights_left_turn', null, 'number of messages with left turn signal on', null, TRUE, null);
insert into meta.obstype values(2001100, '2013-12-04 15:00:00', 'num_lights_low_beam', null, 'number of messages with low beam on', null, TRUE, null);
insert into meta.obstype values(2001101, '2013-12-04 15:00:00', 'num_lights_off', null, 'number of messages with all lights off', null, TRUE, null);
insert into meta.obstype values(2001102, '2013-12-04 15:00:00', 'num_lights_parking', null, 'number of messages with parking lights on', null, TRUE, null);
insert into meta.obstype values(2001103, '2013-12-04 15:00:00', 'num_lights_right_turn', null, 'number of messages with right turn signal on', null, TRUE, null);

insert into meta.obstype values(2001104, '2013-12-04 15:00:00', 'num_msg_valid_stab', null, 'number of messages with valid stab values', null, TRUE, null);
insert into meta.obstype values(2001105, '2013-12-04 15:00:00', 'num_stab_engaged', null, 'number of messages with stability control engaged', null, TRUE, null);
insert into meta.obstype values(2001106, '2013-12-04 15:00:00', 'num_stab_not_equipped', null, 'number of messages with stability control not equipped', null, TRUE, null);
insert into meta.obstype values(2001107, '2013-12-04 15:00:00', 'num_stab_off', null, 'number of messages with stability control off', null, TRUE, null);
insert into meta.obstype values(2001108, '2013-12-04 15:00:00', 'num_stab_on', null, 'number of messages with stability control on', null, TRUE, null);

insert into meta.obstype values(2001109, '2013-12-04 15:00:00', 'num_msg_valid_trac', null, 'number of messages with valid trac value', null, TRUE, null);
insert into meta.obstype values(2001110, '2013-12-04 15:00:00', 'num_trac_engaged', null, 'number of messages with traction control engaged', null, TRUE, null);
insert into meta.obstype values(2001111, '2013-12-04 15:00:00', 'num_trac_not_equipped', null, 'number of messages with traction control not equipped', null, TRUE, null);
insert into meta.obstype values(2001112, '2013-12-04 15:00:00', 'num_trac_off', null, 'number of messages with traction control off', null, TRUE, null);
insert into meta.obstype values(2001113, '2013-12-04 15:00:00', 'num_trac_on', null, 'number of messages with traction control on', null, TRUE, null);

insert into meta.obstype values(2001114, '2013-12-04 15:00:00', 'num_msg_valid_wipers', null, 'number of messages with valid wipers value', null, TRUE, null);
insert into meta.obstype values(2001115, '2013-12-04 15:00:00', 'num_wipers_automatic', null, 'number of messages with automatic wiper control on', null, TRUE, null);
insert into meta.obstype values(2001116, '2013-12-04 15:00:00', 'num_wipers_high', null, 'number of messages with wipers high', null, TRUE, null);
insert into meta.obstype values(2001117, '2013-12-04 15:00:00', 'num_wipers_intermittent', null, 'number of messages with wipers intermittent', null, TRUE, null);
insert into meta.obstype values(2001118, '2013-12-04 15:00:00', 'num_wipers_low', null, 'number of messages with wipers low', null, TRUE, null);
insert into meta.obstype values(2001119, '2013-12-04 15:00:00', 'num_wipers_not_equipped', null, 'number of messages with wiper sensor not equipped', null, TRUE, null);
insert into meta.obstype values(2001120, '2013-12-04 15:00:00', 'num_wipers_off', null, 'number of messages with wipers off', null, TRUE, null);
insert into meta.obstype values(2001121, '2013-12-04 15:00:00', 'num_wipers_washer', null, 'number of messages with wiper washer on', null, TRUE, null);

insert into meta.obstype values(2001122, '2013-12-04 15:00:00', 'num_msg_valid_speed', null, 'number of messages with valid speed values', null, TRUE, null);
insert into meta.obstype values(2001123, '2013-12-04 15:00:00', 'speed_iqr25', '10^-1 meters per second', '25th percentile speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001124, '2013-12-04 15:00:00', 'speed_iqr75', '10^-1 meters per second', '75th percentile speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001125, '2013-12-04 15:00:00', 'speed_max', '10^-1 meters per second', 'maximum speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001126, '2013-12-04 15:00:00', 'speed_mean', '10^-1 meters per second', 'average speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001127, '2013-12-04 15:00:00', 'speed_median', '10^-1 meters per second', 'median speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001128, '2013-12-04 15:00:00', 'speed_min', '10^-1 meters per second', 'minimum speed', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001129, '2013-12-04 15:00:00', 'speed_ratio', null, 'average speed to speed limit ratio', null, TRUE, null);
insert into meta.obstype values(2001130, '2013-12-04 15:00:00', 'speed_stdev', '10^-1 meters per second', 'speed standard deviation', 'm/s', TRUE, 'mph');
insert into meta.obstype values(2001131, '2013-12-04 15:00:00', 'speed_var', '10^-1 meters per second squared', 'speed variance', 'm/s^2', TRUE, 'ft/s^2');

insert into meta.obstype values(2001132, '2013-12-04 15:00:00', 'num_msg_valid_steering_angle', null, 'number of messages with valid steering_angle values', null, TRUE, null);
insert into meta.obstype values(2001133, '2013-12-04 15:00:00', 'steering_angle_iqr25', 'degrees clockwise from true North', '25th percentile steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001134, '2013-12-04 15:00:00', 'steering_angle_iqr75', 'degrees clockwise from true North', '75th percentile steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001135, '2013-12-04 15:00:00', 'steering_angle_max', 'degrees clockwise from true North', 'maximum steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001136, '2013-12-04 15:00:00', 'steering_angle_mean', 'degrees clockwise from true North', 'average steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001137, '2013-12-04 15:00:00', 'steering_angle_median', 'degrees clockwise from true North', 'median steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001138, '2013-12-04 15:00:00', 'steering_angle_min', 'degrees clockwise from true North', 'minimum steering wheel angle', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001139, '2013-12-04 15:00:00', 'steering_angle_stdev', 'degrees clockwise from true North', 'steering wheel angle standard deviation', 'deg', TRUE, 'deg');
insert into meta.obstype values(2001140, '2013-12-04 15:00:00', 'steering_angle_var', 'degrees squared', 'steering wheel angle variance', 'deg^2', TRUE, 'deg^2');

insert into meta.obstype values(2001141, '2013-12-04 15:00:00', 'num_msg_valid_steering_rate', null, 'number of messages with valid staeering_rate values', null, TRUE, null);
insert into meta.obstype values(2001142, '2013-12-04 15:00:00', 'steering_rate_max', 'degrees per second', 'maximum steering wheel angle rate of change', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001143, '2013-12-04 15:00:00', 'steering_rate_mean', 'degrees per second', 'average steering wheel angle rate of change', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001144, '2013-12-04 15:00:00', 'steering_rate_median', 'degrees per second', 'median steering wheel angle rate of change', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001145, '2013-12-04 15:00:00', 'steering_rate_min', 'degrees per second', 'minimum steering wheel angle rate of change', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001146, '2013-12-04 15:00:00', 'steering_rate_stdev', 'degrees per second', 'steering wheel angle rate of change standard deviation', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001147, '2013-12-04 15:00:00', 'steering_rate_var', '(degrees per second) squared', 'steering wheel angle rate of change variance', '(deg/s)^2', TRUE, '(deg/s)^2');

insert into meta.obstype values(2001148, '2013-12-04 15:00:00', 'num_msg_valid_surface_temp', null, 'number of messages with valid surface_temp values', null, TRUE, null);
insert into meta.obstype values(2001149, '2013-12-04 15:00:00', 'surface_temp_iqr25', '10^-1 degrees Celsius', '25th percentile surface temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001150, '2013-12-04 15:00:00', 'surface_temp_iqr75', '10^-1 degrees Celsius', '75th percentile surface temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001151, '2013-12-04 15:00:00', 'surface_temp_max', '10^-1 degrees Celsius', 'maximum surface temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001152, '2013-12-04 15:00:00', 'surface_temp_mean', '10^-1 degrees Celsius', 'average surface temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001153, '2013-12-04 15:00:00', 'surface_temp_median', '10^-1 degrees Celsius', 'median surface temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001154, '2013-12-04 15:00:00', 'surface_temp_min', '10^-1 degrees Celsius', 'minimum surface temperature', 'C', TRUE, 'F');
insert into meta.obstype values(2001155, '2013-12-04 15:00:00', 'surface_temp_stdev', '10^-1 degrees Celsius', 'surface temperature standard deviation', 'C', TRUE, 'F');
insert into meta.obstype values(2001156, '2013-12-04 15:00:00', 'surface_temp_var', 'Celsius^2', 'surface temperature variance', 'C^2', TRUE, 'F^2');

insert into meta.obstype values(2001157, '2013-12-04 15:00:00', 'num_msg_valid_yaw', null, 'yaw_var', null, TRUE, null);
insert into meta.obstype values(2001158, '2013-12-04 15:00:00', 'yaw_iqr25', 'degrees per second', '25th percentile yaw', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001159, '2013-12-04 15:00:00', 'yaw_iqr75', 'degrees per second', '75th percentile yaw', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001160, '2013-12-04 15:00:00', 'yaw_max', 'degrees per second', 'maximum yaw', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001161, '2013-12-04 15:00:00', 'yaw_mean', 'degrees per second', 'average yaw', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001162, '2013-12-04 15:00:00', 'yaw_median', 'degrees per second', 'median yaw', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001163, '2013-12-04 15:00:00', 'yaw_min', 'degrees per second', 'minimum yaw', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001164, '2013-12-04 15:00:00', 'yaw_stdev', 'degrees per second', 'yaw standard deviation', 'deg/s', TRUE, 'deg/s');
insert into meta.obstype values(2001165, '2013-12-04 15:00:00', 'yaw_var', '(degrees per second) squared', 'yaw variance', '(deg/s)^2', TRUE, '(deg/s)^2');

insert into meta.obstype values(2001166, '2013-12-04 15:00:00', 'all_hazards', null, 'all hazards', null, TRUE, null);
insert into meta.obstype values(2001167, '2013-12-04 15:00:00', 'pavement_condition', null, 'derived pavement condition field', null, TRUE, null);
insert into meta.obstype values(2001168, '2013-12-04 15:00:00', 'precipitation', null, 'derived precipitation field', null, TRUE, null);
insert into meta.obstype values(2001169, '2013-12-04 15:00:00', 'visibility', null, 'derived visibility field', null, TRUE, null);