package wde.ws;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;


@Path("email")
public class EmailResource {

	@Context
    protected UriInfo uriInfo;
    @Context
    protected HttpServletRequest req;

    @GET
    @Path("verifyEmail")
    public void verifyEmail() {
    	//TODO:  Verify Email
    }

    @GET
    @Path("forgotUserId")
    public void forgotUserId() {
    	//TODO:  Send out User Id
    }

    @GET
    @Path("forgotPassword")
    public void forgotPassword() {
    	//TODO:  Send out reset password email
    }

    @GET
    @Path("resetPassword")
    public void resetPassword() {
    	//TODO:  Reset Password
    }
}
