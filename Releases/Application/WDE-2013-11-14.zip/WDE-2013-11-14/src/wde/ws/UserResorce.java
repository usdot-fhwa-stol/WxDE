package wde.ws;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import wde.dao.orm.UserDao;
import wde.dao.orm.UserDaoImpl;
import wde.data.User;


@Path("user")
public class UserResorce {
	
    @Context
    protected UriInfo uriInfo;
    @Context
    protected HttpServletRequest req;

    private UserDao userDao;
	
	@GET
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public User getUser() {
		userDao = new UserDaoImpl();
    	return userDao.getUser(req.getRemoteUser());	
	}
	
	@POST
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public void postNewUser(User user) {

		userDao = new UserDaoImpl();
		userDao.insertNewUser(user);
		
		//TODO: post email verification
	}

	@PUT
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public void updateUser(User user) {
		userDao = new UserDaoImpl();
		user.setUser(req.getRemoteUser());
		userDao.updateUser(user);
		
		//TODO: send out email notification that account has changed
	}

}