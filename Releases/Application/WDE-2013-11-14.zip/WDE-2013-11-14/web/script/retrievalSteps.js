var webService = "",
	userEmail = "",
	errorMsg = $("#errorMsg"),
	currentStep = 0,
	arrStep = $('#retrievalSteps > #steps').children(),
	arrHeader = $('#stepsHeaders').children();

// preparations for the app to work properly
// separated for flexibility and readability
initialSettings = function(){
	for (var i = 1; i < arrStep.length; i++)
		$(arrStep[i]).css({marginLeft : '20px', opacity : 0}).hide(0);
	$(arrHeader[0]).css({color : '#555', cursor : 'text'});
	currentStep = 0;
};

// animate next step
nextStep = function(){
	$(arrStep[currentStep]).animate({marginLeft : '-20px', opacity : 0}, 500).hide(0);
	$(arrHeader[currentStep]).css({cursor : 'pointer'}).animate({color : '#CCC'}, 500).addClass('active');
	$(arrStep[++currentStep]).show(0).delay(500).animate({marginLeft : '0px', opacity : 1}, 500);
	$(arrHeader[currentStep]).css({cursor : 'text'}).animate({color : '#555'}, 500);
};

// going back a previous step
prevStep = function(){
	$(arrStep[currentStep]).animate({marginLeft : '20px', opacity : 0}, 500).hide(0);
	$(arrHeader[currentStep]).css({cursor : 'not-allowed'}).animate({color : '#CCC'}, 500);
	$(arrStep[--currentStep]).delay(600).show(0).animate({marginLeft : '0px', opacity : 1}, 500);
	$(arrHeader[currentStep]).css({cursor : 'text'}).animate({color : '#555'}, 500);
};



var isEmail = function($email) {
	  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	  if( !emailReg.test( $email ) ) {
	    return false;
	  } else {
	    return true;
	  }
};

$(function(){
	
	initialSettings();
	
	$("#forgotPassword").click(function(){
		errorMsg.hide();
		nextStep();
		$('input[name="email"]').focus();
		webService = "/resources/email/forgotPassword";

		$("#backStep, #step"+currentStep).click(function(){
			$("#backStep, #step"+currentStep).off(0);
			prevStep();
		});
	});
	
	$("#forgotUserID").click(function(event){
		errorMsg.hide();
		nextStep();
		$('input[name="email"]').focus();
		webService = "/resources/email/forgotUserId";

		$("#backStep, #step"+currentStep).click(function(){
			$("#backStep, #step"+currentStep).off(0);
			prevStep();
		});
	});
	
	$('#backStep2').on("click", function(){
		prevStep();
	});
	
	$('#submitEmail').click(function(e) {
		e.preventDefault();
		
		var emailInput = $(this).closest("form").find("#userEmail").find("input");
		
		userEmail = emailInput.val();
		
		if (!userEmail || !isEmail(userEmail)) {
			errorMsg.fadeIn(0);
			errorMsg.text("Please enter a valid email address.");
			emailInput.focus();
		} else {
	        var userInfo = new Object();
	        
	        userInfo.email = userEmail;
			
			$.ajax({
				url: webService,
			    type: "POST",
			    contentType: "application/json",
			    data: JSON.stringify(userInfo),
			    success: function(resp) {
			    	if (resp == 'true') {
			    		$('#backLogin').show(0);
			    		$('#backStep2').hide(0);
				    	$('#retrievalMsg').html(
				    			'An email was sent to '
				    			+ '<strong>' + userEmail+ '</strong>.'
				    			+ '<br>'
				    			+ 'Please check your <em>inbox</em> or <em>spam</em> folder.'
				    	);
			    	}
			    	else {
			    		$('#backLogin').hide(0);
			    		$('#backStep2').show(0);
				    	$('#retrievalMsg').html(
				    			'The email '
				    			+ '<strong>' + userEmail+ '</strong>'
				    			+ ' does not exist in our database.<br>'
				    			+ 'Please enter a <strong>valid</strong> email.'
				    	);
			    	}
			    },
			    error: function(resp) {
			    	$('#retrievalMsg').html(
			    			'The email '
			    			+ '<strong>' + userEmail+ '</strong>'
			    			+ ' does not exist in our database.<br>'
			    			+ 'Please enter a <strong>valid</strong> email.'
			    	);
			    }
			});
			
			nextStep();
			
			for (var i = currentStep - 1; i >= 0; i-- )
				$(arrHeader[i]).css({cursor : 'not-allowed'}).animate({color : '#CCC'}, 500).off(0);
		}

	});
	
});





