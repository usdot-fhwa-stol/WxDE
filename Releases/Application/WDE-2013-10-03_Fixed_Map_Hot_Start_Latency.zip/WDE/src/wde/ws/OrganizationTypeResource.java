package wde.ws;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import wde.dao.OrganizationTypeDao;
import wde.dao.OrganizationTypeDaoImpl;
import wde.data.OrganizationType;

@Path("organizationTypes")
public class OrganizationTypeResource {

	private OrganizationTypeDao organizaitonTypeDao;
	
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List<OrganizationType> getOrganziationTypes(){
    	organizaitonTypeDao = new OrganizationTypeDaoImpl();
    	return organizaitonTypeDao.getOrganizationTypes();
    }
}
