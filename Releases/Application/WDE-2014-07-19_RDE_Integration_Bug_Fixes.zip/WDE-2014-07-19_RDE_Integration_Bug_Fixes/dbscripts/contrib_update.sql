alter table meta.contrib add column postalcode character varying(5);
update meta.contrib c set postalcode=c1.postalcode from meta.contrib1 c1 where c.id=c1.id;