# applied to prod (by Bryan on 3/18/2014, dev, test, demo, archive)

INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,ignorevalues) VALUES (260201,7,2000005,'wde.cs.ascii.DataValue','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,unit,ignorevalues) VALUES (260201,8,2000008,'wde.cs.ascii.DataValue','mph','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,sensorindex,classname,unit,ignorevalues) VALUES (260201,9,2000008,1,'wde.cs.ascii.DataValue','mph','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,ignorevalues) VALUES (260201,10,2000004,'wde.cs.ascii.DataValue','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,ignorevalues) VALUES (260201,11,2000002,'wde.cs.ascii.DataValue','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,ignorevalues) VALUES (260201,12,2000009,'wde.cs.ascii.DataValue','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,ignorevalues) VALUES (260201,13,2000012,'wde.cs.ascii.DataValue','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,ignorevalues) VALUES (260201,14,2000012,'wde.cs.ascii.DataValue','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,unit,ignorevalues) VALUES (260201,15,51138,'wde.cs.ascii.DataValue','F','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,unit,ignorevalues) VALUES (260201,16,575,'wde.cs.ascii.DataValue','F','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,sensorindex,classname,unit,ignorevalues) VALUES (260201,17,5733,1,'wde.cs.ascii.DataValue','F','10001');
INSERT INTO conf.csvcoldef (collectorid,columnid,obstypeid,classname,unit,ignorevalues) VALUES (260201,18,581,'wde.cs.ascii.DataValue','%','10001');
