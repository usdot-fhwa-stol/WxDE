# applied to prod (by Bryan on 3/18/2014, dev, test, demo, archive)

INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (410,'2014-03-17','OEM','CAN air temp');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (411,'2014-03-17','OEM','CAN barometric pressure');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (423,'2014-03-17','OEM','GPS heading');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (412,'2014-03-17','OEM','GPS speed');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (413,'2014-03-17','OEM','CAN speed');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (414,'2014-03-17','OEM','CAN brake status');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (415,'2014-03-17','OEM','CAN ABS');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (416,'2014-03-17','OEM','CAN ESC');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (417,'2014-03-17','OEM','CAN traction ctrl engine');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (418,'2014-03-17','OEM','CAN traction ctrl brakes');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (419,'2014-03-17','Vaisala','Surface Patrol surface temp');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (420,'2014-03-17','Vaisala','Surface Patrol dew point temp');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (421,'2014-03-17','Vaisala','Surface Patrol air temp');
INSERT INTO meta.sensortype (staticid,updatetime,mfr,model) VALUES (422,'2014-03-17','Vaisala','Surface Patrol humidity');
