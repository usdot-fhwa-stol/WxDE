/************************************************************************
 * Source filename: ObservationCleanser.java
 * 
 * Creation date: Mar 12, 2013
 * 
 * Author: zhengg
 * 
 * Project: WxDE
 * 
 * Objective: Breaks the obs table into daily chunks to speed up later
 * processing
 * 
 * Developer's notes:
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 ***********************************************************************/

package wde.obs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.xml.DOMConfigurator;

import wde.dao.ObservationDao;
import wde.metadata.Sensor;

public class ObservationCleanser {

    private static final int NUM_OF_MILLI_SECONDS_IN_A_DAY = 86400000;
    
    /**
     * @param args
     */
    public static void main(String args[])
    {
        if (args.length < 3) {
            System.out.println("Please provide start date, end date, and mode (1 - fix sensors, 2 - remove duplicates, 3 - vacuum tables, 4 - drop tables, 5 - fix obs");
            System.exit(-1);
        }
        
        DOMConfigurator.configure("config/wde_log4j.xml");

        ObservationDao od = ObservationDao.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Date workingDate0 = null;
        Date endDate0 = null;
        Date workingDate = null;
        Date endDate = null;
        int mode = 0;
        
        try {
            workingDate0 = sdf.parse(args[0]);
            endDate0 = sdf.parse(args[1]);
            mode = Integer.parseInt(args[2]);
        }
        catch (ParseException e) {
            e.printStackTrace();
            System.exit(-1);
        }
        
        switch (mode) {

        case 0:
            System.out.println("Fixing sensor references");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                od.fixSensorIds(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;
        case 1:
            System.out.println("Detecting duplicates");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                od.detectDuplicates(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;
        case 2:
            System.out.println("Removing duplicates");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                od.removeDuplicates(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;
        case 3:
            System.out.println("Vacuuming tables");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                od.vacuumTable(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;
        case 4:
            System.out.println("Dropping tables");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                od.dropTable(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;     
        case 5:
            System.out.println("Fixing obs");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                od.fixObs(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;              
        case 6:
            System.out.println("identifying sensors that are mis-associated with observations");
            workingDate = workingDate0;
            endDate = endDate0;
            ArrayList<String> sensorList = new ArrayList<>();
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                System.out.println("checking table " + dateStr);
                od.findIncompatipleSensors(dateStr, sensorList);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            for (String sensorId : sensorList)
                System.out.println(sensorId);
            break;    
        case 7:
            System.out.println("identifying platforms missing sensors of necessary observation types");
            workingDate = workingDate0;
            endDate = endDate0;
            ArrayList<String> platformList = new ArrayList<>();
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                System.out.println("checking table " + dateStr);
                od.findPlatformMissingSensors(dateStr, platformList);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            for (String platform : platformList)
                System.out.println(platform);
            break;  
        case 8:
            System.out.println("fixing sensor references that are mis-associated with observations");
            workingDate = workingDate0;
            endDate = endDate0;
            while (workingDate.getTime() <= endDate.getTime() ) {
                String dateStr = sdf.format(workingDate);
                System.out.println("checking table " + dateStr);
                od.fixSensorReferences(dateStr);
                workingDate.setTime(workingDate.getTime() + NUM_OF_MILLI_SECONDS_IN_A_DAY);
            }
            break;              
        default:
            System.out.println("Unsupported mode: " + mode);
            break;
        }
    }
}
