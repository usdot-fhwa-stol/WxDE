package wde.dao.orm;

import java.util.List;
import wde.data.Contributor;


public interface ContributorDao {

	public List<Contributor> getContributors();

	public List<Contributor> getContributorsSubset();

}
