package wde.dao.orm;

import java.util.List;

import wde.data.DataMapState;

public interface DataMapDao {
	
	public DataMapState getDataMapState(String code);
	public List<DataMapState> getStates();

}
