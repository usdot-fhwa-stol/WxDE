// global variables
var QCH_MAX = 12;
var m_oMap;
var m_oInfoWindow;
var m_oMarkerMgr = null;
var m_nDefaultZoom;
var m_oStationXmlText;
var m_oMousePos = null;
var m_oStationCode = null;
var m_oClock = null;
var m_oObsTypes = null;

var m_oStations = new StationMgr();

// persistent marker icons
var m_oGrayIcon = new Object();
var m_oPurpleIcon = new Object();
var m_oBlueIcon = new Object();
var m_oBrownIcon = new Object();
var m_oGrayWhiteIcon = new Object();
var m_oWhiteIcon = new Object();

// the segment array
var routePaths = new Array();

var m_oQCh =
[
	[{im:"b",tx:""},{im:"nr",tx:"not run"}],
	[{im:"n",tx:"not passed"},{im:"p",tx:"passed"}]
];

// marker comparator object
var m_oMarkerCompare =
{
	compare : function(oMarkerL, oMarkerR)
	{
		
		// if the markers are null, then whatever is being compared against it is defaulted to greater than
		if (oMarkerL == null || oMarkerR == null) {
			return 1;
		}
		
		var oStationL = oMarkerL.m_oStation;
		var oStationR = oMarkerR.m_oStation;

		var nValue = oStationL.id - oStationR.id;
		if (nValue != 0)
			return nValue;

		if (oStationL.lt < oStationR.lt || oStationL.ln < oStationR.ln)
			return -1;

		if (oStationL.lt > oStationR.lt || oStationL.ln > oStationR.ln)
			return 1;

		return 0;
	}
};

var m_oCircleOverlay = null;

// The Barnes Spatial Radius is based on 69 miles per degree.
var m_oBarnesSpatialRadius = 1.0;

var m_bMapIsMoving = false;

var m_oTimeSendXml_1;
var m_oTimeReceiveXml_1;
var m_oTimeSendXml_2;
var m_oTimeReceiveXml_2;
//var m_oTimeDoneParsing;

var m_oViewport_NE_Lat;
var m_oViewport_NE_Lng;
var m_oViewPort_SW_Lat;
var m_oViewPort_SW_Lng;

var m_oRetrieve_NE_Lat;
var m_oRetrieve_NE_Lng;
var m_oRetrieve_SW_Lat;
var m_oRetrieve_SW_Lng;

var m_bShowASOS = false;

var m_oAllTests = new QChTests();

var m_sUrl;
var m_oStationData = new Array();
var m_oSelectedMarker;
var m_sCurrentUnits = "m";
var m_sCurrentSource = "w";

var m_dCircleX = [];
var m_dCircleY = [];


function LabelOverlay(oMarkerOptions)
{
	this.m_oLatLng = oMarkerOptions.position;
	this.m_oDataOver = null;
}


LabelOverlay.prototype = new google.maps.OverlayView();


LabelOverlay.prototype.onAdd = function()
{
	var oDiv = document.createElement("div");
	oDiv.id = "dataOver";
	oDiv.innerHTML = "";
	oDiv.style.position = "absolute";
	oDiv.style.visibility = "hidden"; // always create invisible

	this.m_oDataOver = oDiv;
	this.getPanes().floatShadow.appendChild(oDiv);
};


LabelOverlay.prototype.draw = function()
{
	var oProj = this.getProjection();
	var oPos = oProj.fromLatLngToDivPixel(this.m_oLatLng);

	var oDiv = this.m_oDataOver;
	oDiv.style.left = oPos.x + "px";
	oDiv.style.top = (oPos.y - 8) + "px"; // shift label up
};


LabelOverlay.prototype.onRemove = function()
{
	var oDiv = this.m_oDataOver;
	oDiv.parentNode.removeChild(oDiv);
	this.m_oDataOver = null;
};


LabelOverlay.prototype.setText = function(sText)
{
	var oDiv = this.m_oDataOver;
	if (sText.length == 0)
	{
		oDiv.style.visibility = "hidden";
		oDiv.innerHTML = sText;
	}
	else
	{
		oDiv.innerHTML = sText;
		oDiv.style.visibility = "visible";
	}
};


function onLoad()
{
	CreateIcon(m_oGrayIcon, "image/mm_12_gray.png", 12, 12, 5, 5);
	CreateIcon(m_oPurpleIcon, "image/mm_12_purple.png", 12, 12, 5, 5);
	CreateIcon(m_oBlueIcon, "image/mm_12_blue.png", 12, 12, 5, 5);
	CreateIcon(m_oBrownIcon, "image/mm_12_brown.png", 12, 12, 5, 5);
	CreateIcon(m_oGrayWhiteIcon, "image/mm_12_graywhite.png", 12, 12, 5, 5);
	CreateIcon(m_oWhiteIcon, "image/mm_12_white.png", 12, 12, 5, 5);

    // See if we are showing ASOS Stations.
    // NOTE: The m_bShowASOS flag is used to enable all internal MHI debugging options.
    m_bShowASOS = (document.URL.indexOf("showasos") >= 0);

    // Turn off the "Clear Circle" button if we are not showing ASOS stations.
    if (!m_bShowASOS)
    {
        var oClearCircle = document.getElementById("btn_circle");
        oClearCircle.style.display = "none";
    }

    // Create the array of Quality Check tests.
    BuildQChTests();

    // Fill the MapAreas listbox.
    FillMapAreaList();

    // Set the dimensions of the map viewport.
    var nHeight = GetWinDimension("height");
    var oDivMap = document.getElementById("map");

    oDivMap.style.height = (nHeight - 66) + "px";

    // Create the text node for the lat/long display.
    m_oMousePos = document.getElementById("latlong");
    m_oMousePos.appendChild(document.createTextNode(""));

    // Create the text node for the Platform Code display.
    m_oStationCode = document.getElementById("stationCode");
    m_oStationCode.appendChild(document.createTextNode(""));

    // Create the text node for the UTC time display.
    m_oClock = document.getElementById("timeUTC");
    m_oClock.appendChild(document.createTextNode(""));
    StartMapClock();

    // Make sure the Metric units are the default
    var oUnitType = document.getElementsByName("rbUnits");
    oUnitType[0].checked = true;

    // compute points based on unit circle
    var dY = 0.0;
    // right side
    for (dY = -1.0; dY < 1.0; dY += 0.01)
    {
    	m_dCircleY.push(dY);
    	m_dCircleX.push(Math.sqrt(1.0 - (dY * dY)));
    }
    // left side
    for (dY = 1.0; dY > -1.0; dY -= 0.01)
    {
    	m_dCircleY.push(dY);
    	m_dCircleX.push(-Math.sqrt(1.0 - (dY * dY)));
    }
    // copy the first point to the last point
    m_dCircleY.push(m_dCircleY[0]);
    m_dCircleX.push(m_dCircleX[0]);

    // Allow the browser window to get established before continuing.
    setTimeout(ContinueLoading, 100);
}

function ContinueLoading()
{
    // Load form defaults to center the map on the correct view
    loadDefaults(document.URL);

    // Get the list of observations.
    GetObsList();
}


// onUnload()
// This function unloads the Google Map stuff, and is called whenever the page
// is unloaded.
// There is an error in version 2.76 of the Google Maps API that causes
// IE to choke up an error.  Putting the GUnload() inside a try/catch
// block prevents the error from being displayed.
function onUnload()
{
    try
    {
        GUnload();
    }
    catch(e)
    {
    }
}


function parseUrl(oParams, sUrl)
{
    // Extract the parameters from the specified URL.
    var sTemp = sUrl.split("?");

    if (sTemp.length > 1)
    {
        var sParameters = sTemp[1].split("&");

        for (var i = 0; i < sParameters.length; i++)
        {
            var sParam = sParameters[i].split("=");
            if (sParam[0] == "lat")
                oParams.lat = parseFloat(sParam[1]);
            else if (sParam[0] == "lon")
                oParams.lon = parseFloat(sParam[1]);
            else if (sParam[0] == "zoom")
                oParams.zoom = parseInt(sParam[1]);
            else if (sParam[0] == "showasos")
                m_bShowASOS = true;
        }
    }
}

function loadDefaults(sUrl)
{
	var oParams = new Object();
	parseUrl(oParams, sUrl);

    var oMapOptions =
    {
      center: new google.maps.LatLng(oParams.lat, oParams.lon),
      zoom: oParams.zoom,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    m_oMap = new google.maps.Map(document.getElementById("map"), oMapOptions);

    google.maps.event.addListener(m_oMap, "mousemove", TrackMouseMovement);
//    google.maps.event.addListener(m_oMap, "moveend", MapWasZoomed);
    // Only allow the Barnes Spatial radius circle to be shown when debugging ASOS stations.
    if (m_bShowASOS)
    {
        google.maps.event.addListener(m_oMap, "singlerightclick", ShowCircle);
    }

//    ComputeBoundaries();

    // Make sure nothing is selected in the MapArea list.
    document.getElementById("jumpList").selectedIndex = 0;
	m_oInfoWindow = new google.maps.InfoWindow({maxWidth: 684});
}


// ComputeBoundaries()
// This function computes the two sets of boundaries that drive the map display.
// The Viewport is the region defined by what the user can see.
// The Retrieve is the region that is twice as big as the Viewport.
// This allows the user to move the map around a bit without triggering a data retrieval.
function ComputeBoundaries()
{
    // Base the Viewport on the visible extents of the map.
    var oBounds = m_oMap.getBounds();
    m_oViewport_NE_Lat = oBounds.getNorthEast().lat();
    m_oViewport_NE_Lng = oBounds.getNorthEast().lng();
    m_oViewport_SW_Lat = oBounds.getSouthWest().lat();
    m_oViewport_SW_Lng = oBounds().getSouthWest().lng();

    var centerLat = m_oMap.getCenter().lat();
    var centerLng = m_oMap.getCenter().lng();

    var deltaLng = (m_oViewport_NE_Lng - centerLng) * 2;
    var deltaLat = (m_oViewport_NE_Lat - centerLat) * 2;

    m_oRetrieve_NE_Lat = centerLat + deltaLat;
    m_oRetrieve_NE_Lng = centerLng + deltaLng;
    m_oRetrieve_SW_Lat = centerLat - deltaLat;
    m_oRetrieve_SW_Lng = centerLng - deltaLng;
}


function BuildQChTests()
{
    // Store the test names and their label images.
    // NOTE: The img* variables are defined in the <head> portion of the web page,
    //       and refer to images that have been preloaded.
    m_oAllTests.push("QchsSequenceComplete", imgComplete.src);
    m_oAllTests.push("QchsManualFlag", imgManual.src);
    m_oAllTests.push("QchsServiceSensorRange", imgSensorRange.src);
    m_oAllTests.push("QchsServiceClimateRange", imgClimateRange.src);
    m_oAllTests.push("QchsServiceStep", imgStep.src);
    m_oAllTests.push("QchsServiceLike", imgLikeInstrument.src);
    m_oAllTests.push("QchsServicePersist", imgPersistence.src);
    m_oAllTests.push("QchsServiceBarnes", imgBarnesSpatial.src);
    m_oAllTests.push("QchsServiceDewpoint", imgDewpoint.src);
    m_oAllTests.push("QchsServicePressure", imgSealevelPressure.src);
}


function TrackMouseMovement(oMouseLatLong)
{
    m_oMousePos.firstChild.data = "Lat, Lon: " +
                                  oMouseLatLong.latLng.lat().toFixed(6) + ", " +
                                  oMouseLatLong.latLng.lng().toFixed(6);
}


function GetObsList()
{
    m_oTimeSendXml_1 = new Date();

    var oXmlRequest = new XmlRequest();
    // oXmlRequest.getXml("../obsv1/listObsTypes.jsp", cbGetObsList);
    oXmlRequest.getXml("ListObsTypes", cbGetObsList);
}


function DrawDebugRectangles()
{
/*****
    var boxV = new google.maps.Polyline([new GLatLng(m_oViewport_NE_Lat, m_oViewport_NE_Lng),
                              new GLatLng(m_oViewport_SW_Lat, m_oViewport_NE_Lng),
                              new GLatLng(m_oViewport_SW_Lat, m_oViewport_SW_Lng),
                              new GLatLng(m_oViewport_NE_Lat, m_oViewport_SW_Lng),
                              new GLatLng(m_oViewport_NE_Lat, m_oViewport_NE_Lng)],
                              "#000000", 3, 1);
    var boxR = new google.maps.Polyline([new GLatLng(m_oRetrieve_NE_Lat, m_oRetrieve_NE_Lng),
                              new GLatLng(m_oRetrieve_SW_Lat, m_oRetrieve_NE_Lng),
                              new GLatLng(m_oRetrieve_SW_Lat, m_oRetrieve_SW_Lng),
                              new GLatLng(m_oRetrieve_NE_Lat, m_oRetrieve_SW_Lng),
                              new GLatLng(m_oRetrieve_NE_Lat, m_oRetrieve_NE_Lng)],
                              "#FF00FF", 3, 1);
    m_oMap.addOverlay(boxV);
    m_oMap.addOverlay(boxR);
*****/
    DrawBox(42.391388, -96.75389, 43.6083, -96.378);
    DrawBox(48.1347, -93.8784, 48.601833, -92.97047);
}


function DrawBox(fLatSW, fLngSW, fLatNE, fLngNE)
{
    var oOptions =
    {
      strokeColor: "#000",
      strokeOpacity: 1.0,
      strokeWeight: 3,
      path:
      [
	new google.maps.LatLng(fLatSW, fLngSW),
        new google.maps.LatLng(fLatNE, fLngSW),
        new google.maps.LatLng(fLatNE, fLngNE),
        new google.maps.LatLng(fLatSW, fLngNE),
        new google.maps.LatLng(fLatSW, fLngSW)
      ]
    };

    m_oMap.addOverlay(new google.maps.Polyline(oOptions));
}


function LabelClicked(sLabelClicked)
{
    var oUnitType = document.getElementsByName("rbUnits");
    m_sCurrentUnits = sLabelClicked;

    if (sLabelClicked == "m")
        oUnitType[0].checked = true;
    else
        oUnitType[1].checked = true;

    UnitsChanged();
}

function ToggleLayer()
{
	var bVDTMobile = document.getElementById("chVDTMobile").checked;
	var bWxDEMobile = document.getElementById("chWxDEMobile").checked;	
	var bFixed = document.getElementById("chFixed").checked;

	var nIndex = m_oStationData.length;
	while (nIndex-- > 0)
	{
		var oMarker = m_oStationData[nIndex];
		var oLabelDiv = oMarker.m_oLabelDiv;

		if (
				(bVDTMobile && oMarker.m_oSource == 2 && oMarker.m_oStation.ca == "M") ||
				(bWxDEMobile && oMarker.m_oSource == 1 && oMarker.m_oStation.ca == "M") ||
				(bFixed && (oMarker.m_oStation.ca == "P" || oMarker.m_oStation.ca == 'T')))
		{
			oMarker.setVisible(true);
			if (oLabelDiv != undefined)
				oLabelDiv.style.display = "block";
		}
		else
		{
			oMarker.setVisible(false);
			if (oLabelDiv != undefined)
				oLabelDiv.style.display = "none";
		}
	}
}


function UnitsChanged()
{
    // Fill the ObsTypes list box.
    // The "false" indicates that we don't want to re-fetch the stations in the region.
    FillObsTypesListbox(false);
}


//-----------------------------------------------------------
// ListboxRemoveAll()  ==> From Intermodal:Utils.js
//      Removes all items in a list box.
//-----------------------------------------------------------
function ListboxRemoveAll(oList)
{
    while (oList.childNodes.length > 0)
    {
        oList.removeChild(oList.lastChild);
    }
}


function cbGetObsList(oXml, oText)
{
    m_oTimeReceiveXml_1 = new Date();
    m_oObsTypes = oXml.documentElement.getElementsByTagName("obsType");
    setTimeout("FillObsTypesListbox(true)", 100);
}


function FillObsTypesListbox(bGetStations)
{
    var oSelect = document.getElementById("obsTypeList");

    // Save the currently-selected index.
    var nCurrIndex = oSelect.selectedIndex;

    // Remove all the elements in the listbox.
    ListboxRemoveAll(oSelect);

    oEntry = document.createElement("option");
    oEntry.appendChild(document.createTextNode("(Select Data to Show)"));
    oEntry.value = "";
    oSelect.appendChild(oEntry);

    var sUnitAttribute = "units";
    var oUnitType = document.getElementsByName("rbUnits");
    if (oUnitType[1].checked)
    {
        sUnitAttribute = "englishUnits";
    }

    var oRow;
    var sText;
    var sUnits;
    for (var i = 0; i < m_oObsTypes.length; i++)
    {
        oRow = m_oObsTypes[i];

        if (oRow.getAttribute("active") == "1")
        {
            sText = oRow.getAttribute("name");

            // If there are any units for the chosen Unit system,
            // then append them to the observation string.
            sUnits = oRow.getAttribute(sUnitAttribute);
            if (sUnits != "")
              sText += " (" + sUnits + ")";

            oEntry = document.createElement("option");
            oEntry.appendChild(document.createTextNode(sText));
            oEntry.value = oRow.getAttribute("id");
            oSelect.appendChild(oEntry);
        }
    }

    // Tack the Platform Code option to the end, since it isn't an ObsType.
    oEntry = document.createElement("option");
    oEntry.appendChild(document.createTextNode("Platform Code"));
    oEntry.value = "";
    oSelect.appendChild(oEntry);

    // Re-select the selected index.
    if (nCurrIndex != -1)
        oSelect.selectedIndex = nCurrIndex;

    if (bGetStations)
        GetStations();
    else
    {
		// update the div innerHTML for each station, displayed div tag content will change
		var nIndex = m_oStationData.length;
		while (nIndex-- > 0)
		{
			var oMarker = m_oStationData[nIndex];
			var oObsValues = oMarker.m_oObsValues;
			var sLabel = "";
			if (oObsValues != undefined)
			{
				var oValueArray = oMarker.m_oObsValues.mv;
				if (m_sCurrentUnits == "e")
					oValueArray = oMarker.m_oObsValues.ev;

				sLabel = "";
				for (var nValueIndex = 0; nValueIndex < oValueArray.length; nValueIndex++)
				{
					if (nValueIndex > 0)
						sLabel += ", ";

					sLabel += oValueArray[nValueIndex];
				}
			}
			oMarker.m_oLabel.setText(sLabel);
		}
    }
}


function GetStations()
{
    // Turn off various objects until the XML data is returned.
    DisableObjects(true);

    // Display a "Retrieving data" label
    ShowProgressLabel();

    m_oTimeSendXml_2 = new Date();
    var oXmlRequest = new XmlRequest();
    oXmlRequest.addParameter("lat1", m_oRetrieve_SW_Lat);
    oXmlRequest.addParameter("lng1", m_oRetrieve_SW_Lng);
    oXmlRequest.addParameter("lat2", m_oRetrieve_NE_Lat);
    oXmlRequest.addParameter("lng2", m_oRetrieve_NE_Lng);
    oXmlRequest.addParameter("format", "json");
    if (m_bShowASOS)
      oXmlRequest.addParameter("showasos", "1");

    oXmlRequest.getXml("GetPlatformsForRegion", cbGetStations);
}


function CreateIcon(oIcon, sImage, nWidth, nHeight, nX, nY)
{
	oIcon.anchor = new google.maps.Point(nX, nY);
	oIcon.size = new google.maps.Size(nWidth, nHeight);
	oIcon.url = sImage;
}


// ShowStationCode()
// This function displays the Platform Code in a text field
// whenever the mouse runs over it.
function ShowStationCode(oMarker)
{
    m_oStationCode.firstChild.data = "Platform Code: " + oMarker.m_oStation.st;
}


function ShowInfoWindow(oMarker)
{
	m_oInfoWindow.close();
    m_oSelectedMarker = oMarker;
    var oXmlRequest = new XmlRequest();
    oXmlRequest.addParameter("sourceId", oMarker.m_oSource);
    oXmlRequest.addParameter("stationId", oMarker.m_oStation.id);
    oXmlRequest.addParameter("lat", oMarker.m_oStation.lt);
    oXmlRequest.addParameter("lon", oMarker.m_oStation.ln);
    oXmlRequest.getXml("GetPlatformsForRegion", cbGetObsForStation);
}


function cbGetObsForStation(oXml, sText)
{
	var oStationObs = eval("(" + sText + ")");
	var oObs = oStationObs.ob;
	var oMarker = m_oSelectedMarker;

    // Early bailout
    if (oMarker == null)
    	return;
    var oStation = oMarker.m_oStation;

    // Figure out which Unit Types are being displayed.
    var bShowEnglishUnits = false;
    var oUnitType = document.getElementsByName("rbUnits");
    bShowEnglishUnits = oUnitType[1].checked;

    var sObsTableHeader;
    if (oMarker.m_oSource == 1)
    {
    	sObsTableHeader =
        "<div style=\"width: 684px; overflow: hidden;\">\n" +
        "<table class=\"qualityChecks\">\n" +
        "  <tr align=\"center\">\n" +
        "    <td colspan=\"6\">" + oStation.st + "<br/>" + oStationObs.nm + "<br/>" + "Lat, Lon: " + oStation.lt + ", " + oStation.ln + "<br/>Elevation: " + oStationObs.el + " m</td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgComplete.src + "\" alt=\"Complete\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgManual.src + "\" alt=\"Manual\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgSensorRange.src + "\" alt=\"Sensor Range\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgClimateRange.src + "\" alt=\"Climate Range\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgStep.src + "\" alt=\"Step\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgLikeInstrument.src + "\" alt=\"Like Instrument\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgPersistence.src + "\" alt=\"Persistence\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgIQR.src + "\" alt=\"Inter-quartile Range\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgBarnesSpatial.src + "\" alt=\"Barnes Spatial\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgDewpoint.src + "\" alt=\"Dewpoint\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgSealevelPressure.src + "\" alt=\"Sea Level Pressure\"/></td>\n" +
        "    <td rowspan=\"2\"><img src=\"" + imgPrecipAccum.src + "\" alt=\"Accumulated Precipitation\"/></td>\n" +
        "  </tr>\n" +
        "  <tr align=\"center\">\n" +
        "    <td><b>Timestamp (UTC)</b></td>\n" +
        "    <td><b>Observation Type</b></td>\n" +
        "    <td><b>Ind</b></td>\n" +
        "    <td><b>Value</b></td>\n" +
        "    <td><b>Unit</b></td>\n" +
        "    <td><b>Conf</b></td>\n" +
        "  </tr>\n";
    }
    else
    {
    	sObsTableHeader =
            "<div style=\"width: 684px; overflow: hidden;\">\n" +
            "<table class=\"qualityChecks\">\n" +
            "  <tr align=\"center\">\n" +
            "    <td colspan=\"6\">" + oStation.st + "<br/>" + oStationObs.nm + "<br/>" + "Lat, Lon: " + oStation.lt + ", " + oStation.ln + "<br/>Elevation: " + oStationObs.el + " m</td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgCombinedAlgorithm.src + "\" alt=\"Combined Algorithm\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgClimateRange.src + "\" alt=\"Climate Range\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgModelAnalysis.src + "\" alt=\"Model Analysis\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgNearestSurfaceStation.src + "\" alt=\"Nearest Surface Station\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgNeighboringVehicle.src + "\" alt=\"Neighboring Vehicle\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgPersistence.src + "\" alt=\"Persistence\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgSensorRange.src + "\" alt=\"Sensor Range\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgStandardDeviation.src + "\" alt=\"Standard Deviation\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgSpatialBarnes.src + "\" alt=\"Spatial Barnes\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgSpatialIOR.src + "\" alt=\"Spatial IQR\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgTimeStep.src + "\" alt=\"Time Step\"/></td>\n" +
            "    <td rowspan=\"2\"><img src=\"" + imgOverallDewTemperature.src + "\" alt=\"Overall Dew Temperature\"/></td>\n" +            
            "    <td rowspan=\"2\"><img src=\"" + imgFiltering.src + "\" alt=\"Filtering\"/></td>\n" +
            "  </tr>\n" +
            "  <tr align=\"center\">\n" +
            "    <td><b>Timestamp (UTC)</b></td>\n" +
            "    <td><b>Observation Type</b></td>\n" +
            "    <td><b>Ind</b></td>\n" +
            "    <td><b>Value</b></td>\n" +
            "    <td><b>Unit</b></td>\n" +
            "    <td><b>Conf</b></td>\n" +
            "  </tr>\n";
    }

    var sObsTableFooter = "</table>\n</div>";
    var sObsTableRows = "";

    if (oObs.length > 0)
    {
		// sort obs array by obs type name and then sensor index
		var oCompare =
		{
			compare : function(oLhs, oRhs)
			{
				if (oLhs.ot == oRhs.ot)
				{
					if (oLhs.si == oRhs.si)
						return 0;

					if (oLhs.si < oRhs.si)
						return -1;

					return 1;
				}

				if (oLhs.ot < oRhs.ot)
					return -1;

				return 1;
			}
		};

		js.util.Collections.usort(oObs, oCompare);

        // Now, build the table of Observations.
        for (var i = 0; i < oObs.length; i++)
        {
			var iObs = oObs[i];

			sObsTableRows +=
				"  <tr>\n" +
				"    <td>" + iObs.ts + "</td>\n" +
				"    <td class=\"obsType\">" + iObs.ot + "</td>\n" +
				"    <td class=\"value\">" + iObs.si + "</td>\n";

			// add the observation value
			sObsTableRows += "    <td class=\"value\">";

			if (bShowEnglishUnits)
				sObsTableRows += iObs.ev;
			else
				sObsTableRows += iObs.mv;

			sObsTableRows += "</td>\n";

			// add the appropriate units left-justified
			sObsTableRows += "    <td class=\"obsType\">";
			// only disply units when they are not null
			if (iObs.mu != "null" && iObs.eu != "null")
			{
				if (bShowEnglishUnits)
					sObsTableRows += iObs.eu;
				else
					sObsTableRows += iObs.mu;
			}
			sObsTableRows += "</td>\n";

			// show the confidence value right-justified
			sObsTableRows += "    <td class=\"value\">" + iObs.cv + "%</td>\n";

			var sRun = Number(iObs.rf).toString(2);
			while (sRun.length < QCH_MAX)
				sRun = "0" + sRun;

			var sPass = Number(iObs.pf).toString(2);
			while (sPass.length < QCH_MAX)
				sPass = "0" + sPass;

			var nIndex = sRun.length;
			while (nIndex-- > 0)
			{
				var nRow = Number(sRun.charAt(nIndex));
				var nCol = Number(sPass.charAt(nIndex));
				var oFlag = m_oQCh[nRow][nCol];

				sObsTableRows += "    <td><img src=\"image/";
				sObsTableRows += oFlag.im;
				sObsTableRows += ".png\" alt=\"";
				sObsTableRows += oFlag.tx;
				sObsTableRows += "\"/></td>\n";
			}

            sObsTableRows += "  </tr>\n";
        }
    }
    else
    {
        // No Observations for this Station.
        sObsTableRows +=
            "  <tr>\n" +
            "    <td colspan=\"6\">No current observations available</td>\n" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>" +
            "<td>&nbsp;</td>";
    }

	m_oInfoWindow.setContent(sObsTableHeader + sObsTableRows + sObsTableFooter);
	m_oInfoWindow.open(m_oMap, oMarker);
}


function cbGetStations(oXml, oText)
{
	m_oStationXmlText = oText;
	var oStationXmlData = eval(oText);

	// remove data for ASOS stations if they are not going to be displayed
	var nIndex = oStationXmlData.length;
	if (!m_bShowASOS)
	{
		var oTempArray = new Array();
		while (nIndex-- > 0)
		{
			var oStation = oStationXmlData[nIndex];

			// only save the stations outside the ASOS ranges
			if (oStation.cn != 4)
				oTempArray.push(oStation);
		}
		oStationXmlData = oTempArray;
	}

	
	nIndex = oStationXmlData.length;
	while (nIndex-- > 0)
	{
		var oStation = oStationXmlData[nIndex];
		var icon = m_oGrayIcon;
		var oSource = 1;
		if (oStation.cn == 4)
		{
			if (oStation.ho == 0)
				icon = m_oGrayWhiteIcon;
			else
				icon = m_oWhiteIcon;
		}
		else
		{
			if (oStation.ho == 1)
			{
				if (oStation.ca == "P" || oStation.ca == "T")
					icon = m_oPurpleIcon;
				else
					icon = m_oBlueIcon;
			}
			else if (oStation.ho == 2)
			{
				oSource = 2;
				icon = m_oBrownIcon;
			}
			else if (oStation.ho == 3)
				icon = m_oBlueIcon; // create the one for WxDE first
		}
		
		PopulateMarker(oStation, oSource, icon);
		
		if (oStation.ho == 3) 
		{
			// now create the one for VDT
			oSource = 2;
			icon = m_oBrownIcon;
			PopulateMarker(oStation, oSource, icon);
		}
	}
	js.util.Collections.usort(m_oStationData, m_oMarkerCompare);

	// Re-enable the screen objects.
	DisableObjects(false);

	HideProgressLabel();
//	google.maps.event.addListener(m_oMap, "zoomend", MapWasZoomed);

	//    m_oTimeDoneParsing = new Date();

	// DrawDebugRectangles();
	
	//TODO:  Make the cluster prettier
	var markerCluster = new MarkerClusterer(m_oMap, m_oStationData);
	
    $.ajax({
        url: "/resources/segment/",
        dataType: "json",
        success: function(resp) {
        	var routePathCoordinates2;

        	//render segments on to map according to coordinates
            $.each(resp.segment, function(index, item) {
            	routePathCoordinates2 = new Array();

            	$.each(item.geoCodes.geoCode, function(i, item2) {
                    routePathCoordinates2.push(new google.maps.LatLng(item2.latitude, item2.longitude));
            	});

            	var routePath = new google.maps.Polyline({
          	       path: routePathCoordinates2,
          	       geodesic: true,
          	       strokeColor: 'darkviolet',
          	       strokeOpacity: 1.0,
          	       strokeWeight: 10
                });
                
    			routePath.setMap(m_oMap);
    			
  			    google.maps.event.addListener(routePath, "click", function() {
  			    	alert("Road Segment " + item.id + "-" + item.name + " Clicked");
				});
    			
/*    			
				google.maps.event.addListener(routePath, "click", function(routePath) {
    				
    				
    				// Use the existing
    				this.anchorPoint = new google.maps.Point(1,1);
    				this.m_oSource = "1";
    				var tempStation = new Object();
    				tempStation.id  = "107";
    				tempStation.lt = "43.902366";
    				tempStation.ln = "-92.482283";
   					tempStation.lt = new String(routePath.latLng.nb);
    				tempStation.ln = new String(routePath.latLng.ob);
  				
    				this.m_oStation = tempStation;
					var oOptions =
					{
						anchorPoint: new google.maps.Point(1, 1),
						position: new google.maps.LatLng(tempStation.lt, tempStation.ln),
						icon: m_oPurpleIcon
					};  					
					this.m_oLabel = new LabelOverlay(oOptions);
  					ShowInfoWindow(this);
    				
   					$.ajax({
    			        url: "/GetPlatformsForRegion",
    			        dataType: "json",
    			        type: "POST",
    			        data: "sourceId=1&stationId=107&lat=43.902366&lon=-92.482283",
    			        success: function(resp) {
    			        	console.log("Success");
    			        },
    			        error : function(resp) {
    			        	console.log("Failure");
    			        }
    			    });
    			});
    			*/
    			google.maps.event.addListener(routePath, "mouseover", function() {
    				routePath.setOptions({strokeColor: 'yellow'});
    				m_oStationCode.firstChild.data = "Platform Code: " + item.name;
    			});
    			google.maps.event.addListener(routePath, "mouseout", function() {
    				routePath.setOptions({strokeColor: 'darkviolet'});
    				m_oStationCode.firstChild.data = "Platform Code: ";
    			});
                
    			//append routePath to the routePaths array
                routePaths.push(routePath);
            });
        }
    });
}

//function to toggle ALL routePaths
function toggleSegments() {
	// this should initially be TRUE
	var toggleCheck = document.getElementById("toggleSegments").checked;
	
	if (!toggleCheck) {
		for ( var x = 0; x < routePaths.length; x++) {
			routePaths[x].setVisible(false);
		}
	} else {
		for ( var x = 0; x < routePaths.length; x++) { 
			routePaths[x].setVisible(true);
		}
	}
}

function PopulateMarker(oStation, oSource, icon)
{
	var oMarker;
	var oOptions =
	{
		anchorPoint: new google.maps.Point(1, 1),
		position: new google.maps.LatLng(oStation.lt, oStation.ln),
		icon: m_oPurpleIcon
	};
	oOptions.icon = icon;
	oMarker = new google.maps.Marker(oOptions);

	// attach mouse events to each marker
	google.maps.event.addListener
	(
		oMarker, "click",
		function(oMarker)
		{
			ShowInfoWindow(this);
		}
	);

	google.maps.event.addListener
	(
		oMarker, "mouseover",
		function(oMarker)
		{
			ShowStationCode(this);
		}
	);

	google.maps.event.addListener
	(
		oMarker, "mouseout",
		function()
		{
			m_oStationCode.firstChild.data = "Platform Code: ";
		}
	);

	// attach the parsed station data to the map marker
	oMarker.m_oSource = oSource;
	oMarker.m_oStation = oStation;
	oMarker.m_oLabel = new LabelOverlay(oOptions);
	m_oStationData.push(oMarker);
	oMarker.setMap(m_oMap);
	oMarker.m_oLabel.setMap(m_oMap);
}


function DisableObjects(bDisabled)
{
    var oShowObs = document.getElementById("btn_show");
    var oObsTypeList = document.getElementById("obsTypeList");
    var oJumpList = document.getElementById("jumpList");

    if (oShowObs != null)
        oShowObs.disabled = bDisabled;

    if (oObsTypeList != null)
        oObsTypeList.disabled = bDisabled;

    if (oJumpList != null)
        oJumpList.disabled = bDisabled;
}


function Debug(sText)
{
    alert("DEBUG:\n" + sText);
}


function GetObsValue()
{
    var oSelect = document.getElementById("obsTypeList");
    var sObsType = oSelect.childNodes.item(oSelect.selectedIndex).firstChild.data;

	var nIndex = m_oStationData.length;
	while (nIndex-- > 0)
		m_oStationData[nIndex].m_oLabel.setText("");

    if (sObsType == "(Select Data to Show)") // clear marker labels
        return; // early bailout

    ShowProgressLabel();

    if (sObsType == "Platform Code") // already have station codes, no need for XML request
    {
		nIndex = m_oStationData.length;
		while (nIndex-- > 0)
		{
			var oMarker = m_oStationData[nIndex];
			oMarker.m_oLabel.setText(oMarker.m_oStation.st);
		}

		HideProgressLabel();
		return; // quit early
    }

	var oXmlRequest = new XmlRequest(); // request the obs values
	oXmlRequest.addParameter("obsType", oSelect.value);
	oXmlRequest.getXml("GetPlatformsForRegion", cbGetObsValue);
}


function cbGetObsValue(oXml, sText)
{
	HideProgressLabel();

	var oValueArray = undefined;
	var oObsValues = eval(sText);
	for (var nIndex = 0; nIndex < oObsValues.length; nIndex++)
	{
		var oValues = oObsValues[nIndex];
		if (oValues.mv.length > 0) // when metric units exist english units exist
		{
			oValues.m_oStation = new Object(); // create station for the comparison
			oValues.m_oStation.id = oValues.id;
			oValues.m_oStation.lt = oValues.lt;
			oValues.m_oStation.ln = oValues.ln;

			var nMarkerIndex = js.util.Collections.binarySearch(m_oStationData, oValues, m_oMarkerCompare);
			if (nMarkerIndex >= 0)
			{
				var oMarker = m_oStationData[nMarkerIndex];
				oMarker.m_oObsValues = oValues;

				oValueArray = oMarker.m_oObsValues.mv;
				if (m_sCurrentUnits == "e")
					oValueArray = oMarker.m_oObsValues.ev;

				var sLabel = "";
				for (var nValueIndex = 0; nValueIndex < oValueArray.length; nValueIndex++)
				{
					if (nValueIndex > 0)
						sLabel += ", ";

					sLabel += oValueArray[nValueIndex];
				}
				oMarker.m_oLabel.setText(sLabel);
			}
		}
		else
			oMarker.m_oObsValues = undefined;
	}
}


function StartMapClock()
{
    m_oClock.firstChild.data = FormatCurrentTime();

    // Update the clock every 60 seconds, at the top of the minute.
    setTimeout(StartMapClock, (1000 * (60 - new Date().getSeconds())));
}


function ShowProgressLabel()
{
    var oDivLabel = document.getElementById("progressLabel");
    oDivLabel.style.top = ((GetWinDimension("height") / 2) - 24) + "px";
    oDivLabel.style.visibility = "visible";
}


function HideProgressLabel()
{
    document.getElementById("progressLabel").style.visibility = "hidden";
}


function ClearCircle()
{
    // Remove the previous circle, if any.
    if (m_oCircleOverlay != null)
    {
        m_oMap.removeOverlay(m_oCircleOverlay);
    }
}


function DrawCircle(oCenterPoint, oRadiusPoint, sLineColor, nLineWeight)
{
	var oPoints = [];
	var nIndex = m_dCircleY.length;
	while (nIndex-- > 0)
	{
		var dLatOffset = oCenterPoint.lat() + m_dCircleY[nIndex];
		oPoints.push(new google.maps.LatLng(dLatOffset, oCenterPoint.lng() + m_dCircleX[nIndex] / Math.cos(dLatOffset * Math.PI / 180)));
	}

	m_oCircleOverlay = new google.maps.Polyline(oPoints, sLineColor, nLineWeight, 1);
	m_oMap.addOverlay(m_oCircleOverlay);
}


// DrawCircle() is based on
// http://maps.forum.nu/gm_clickable_circle.html
function DrawCircle2(oCenterPoint, oRadiusPoint, sLineColor, nLineWeight)
{
    var oNormalProj = G_NORMAL_MAP.getProjection();
    var zoom = m_oMap.getZoom();

    var centerPt = oNormalProj.fromLatLngToPixel(oCenterPoint, zoom);
    // var radiusPt = m_NormalProj.fromLatLngToPixel(radiusMarker, zoom);
    var radiusPt = oNormalProj.fromLatLngToPixel(oRadiusPoint, zoom);

    var circlePoints = Array();

    with (Math)
    {
        var radius = floor(sqrt(pow((centerPt.x-radiusPt.x),2) + pow((centerPt.y-radiusPt.y),2)));

        for (var a = 0 ; a < 361 ; a+=10 )
        {
            var aRad = a*(PI/180);
            y = centerPt.y + radius * sin(aRad);
            x = centerPt.x + radius * cos(aRad);
            var p = new google.maps.Point(x,y);
            circlePoints.push(oNormalProj.fromPixelToLatLng(p, zoom));
        }

        m_oCircleOverlay = new google.maps.Polyline(circlePoints, sLineColor, nLineWeight, 1);
        m_oMap.addOverlay(m_oCircleOverlay);
    }
}


function ShowCircle(oMousePoint)
{
    // Remove the previous circle, if any.
    ClearCircle();

    // Convert from the mouse coordinate point (x, y of mouse in div)
    // to a latitude/longitude coordinate.  Then, create a point
    // on the radius of the desired circle.
    var oLatLng = m_oMap.fromContainerPixelToLatLng(oMousePoint);
    var oRadiusPoint = new google.maps.LatLng(oLatLng.lat() + m_oBarnesSpatialRadius, oLatLng.lng());
    DrawCircle(oLatLng, oRadiusPoint, "#000000", 2);
}


function RemoveStationsFromMap()
{
    var pane = m_oMap.getPane(G_MAP_MARKER_SHADOW_PANE);
    var oStation;
    for (var i = m_oStations.length() - 1; i >= 0; i--)
    {
        oStation = m_oStations.get(i);
        if (oStation.latitude < m_oRetrieve_SW_Lat ||
            oStation.latitude > m_oRetrieve_NE_Lat ||
            oStation.longitude < m_oRetrieve_SW_Lng ||
            oStation.longitude > m_oRetrieve_NE_Lng)
        {
            m_oStations.remove(i);
            m_oMarkerMgr.removeMarker(oStation.marker);

            // Remove the station's label div tag.
            if (oStation.labelDiv != undefined)
            {
                pane.removeChild(oStation.labelDiv);
            }
        }
    }
}


function FillMapAreaList()
{
    var oSelect = document.getElementById("jumpList");

    // Remove all the elements in the listbox.
    ListboxRemoveAll(oSelect);

    oEntry = document.createElement("option");
    oEntry.appendChild(document.createTextNode("(Re-center map on ...)"));
    oEntry.value = "";
    oSelect.appendChild(oEntry);

    var oRow;
    var sLink;
    for (var i = 0; i < oMapAreas.length; i++)
    {
        oRow = oMapAreas[i];

        if (oRow.active == "1")
        {
            sLink = "?lat=" + oRow.lat +
                    "&lon=" + oRow.lon +
                    "&zoom=" + oRow.zoom;
            ListboxInsertItem(oSelect, oRow.name, sLink);
        }
    }
}


function Jump()
{
    var sUrl = document.getElementById("jumpList").value;
    if (sUrl != "")
    {
		var oParams = new Object();
		parseUrl(oParams, sUrl);

		m_oMap.setCenter(new google.maps.LatLng(oParams.lat, oParams.lon));
		m_oMap.setZoom(oParams.zoom);
    }
}


window.onresize = function()
{
    document.getElementById("map").style.height = (GetWinDimension("height") - 66) + "px";
};
