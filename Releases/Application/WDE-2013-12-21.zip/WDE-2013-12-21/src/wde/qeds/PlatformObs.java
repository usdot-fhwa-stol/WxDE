// Copyright (c) 2010 Mixon/Hill, Inc. All rights reserved.
/**
 * @file PlatformObs.java
 */
package wde.qeds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import wde.metadata.IPlatform;
import wde.obs.IObs;
import wde.util.MathUtil;

/**
 * Wraps observations with the platform that recorded them.
 *
 * <p>
 * Implements {@code Comparator<IObs>} to enforce an ordering on observations,
 * based off sensor id.
 * </p>
 */
public class PlatformObs implements Comparator<IObs>
{
    /**
     * Latitude for grouped observations.
     */
	int m_nLat;
    /**
     * Longitude for grouped observations.
     */
	int m_nLon;
    /**
     * Elevation for grouped observations.
     */
	int m_tElev;
    /**
     * Flag showing whether or not this {@code PlatformObs} object contains WxDE
     * observations.
     */
	boolean m_bHasWxDEObs;
    /**
     * Flag showing whether or not this {@code PlatformObs} object contains VDT
     * observations.
     */
    boolean m_bHasVDTObs;
	/**
     * Platform id.
     */
	int m_nId;
	/**
     * Platform code.
     */
	String m_sCode;
    /**
     * Distribution group this platform belongs to.
     */
	int m_nDistGroup;
    /**
     * Timestamp corresponding to the last WxDE update.
     */
	long m_lLastWxDEUpdate;
    /**
     * Timestamp corresponding to the last VDT update.
     */
    long m_lLastVDTUpdate;	
    /**
     * Latitudes for road segment definition.
     */
	ArrayList<Double> m_oLat;
    /**
     * Longitudes for road segment definition.
     */
	ArrayList<Double> m_oLon;
    /**
     * Observations list.
     */
	final ArrayList<IObs> m_oObs = new ArrayList<IObs>();
    /**
     * Platform corresponding to the observations.
     */
	IPlatform m_iPlatform;


	/**
	 * <b> Default Constructor </b>
	 * <p>
	 * Creates new instances of {@code PlatformObs}
	 * </p>
	 */
	PlatformObs()
	{
	}


    /**
     * <b> Constructor </b>
     * <p>
     * New instance of {@code PlatformObs} created with this constructor will
     * have the same platform id as the provided platform, and the platform member
     * ({@code m_iPlatform}) will be a copy of the supplied platform.
     * </p>
     * @param platform  Object
     */
	PlatformObs(IPlatform platform)
	{
		this(platform, 
		     MathUtil.toMicro(platform.getLocBaseLat()), 
		     MathUtil.toMicro(platform.getLocBaseLong()), 
		     (int)platform.getLocBaseElev());
	}


    /**
     * <b> Constructor </b>
     * <p>
     * New instance of {@code PlatformObs} created with this constructor will
     * have the same platform id as the provided platform, and geo-coordinates
	 * from mobile observations.
     * </p>
     * @param platform  Object
     */
	PlatformObs(IPlatform platform, int nLat, int nLon, int tElev)
	{
		m_nId = platform.getId();
		m_sCode = platform.getPlatformCode();
		m_iPlatform = platform;
		m_nLat = nLat;
		m_nLon = nLon;
		m_tElev = tElev;
	}


    /**
     * Determines whether or not the observation list contains any observations.
     * @return true if the observation list contains observations, false
     * otherwise.
     */
	synchronized boolean hasObs()
	{
		return (m_oObs.size() > 0);
	}
	

    /**
     * Adds the supplied observation to the observation list if the observation
     * is new to the list, otherwise existing observations are replaced with
     * newer ones.
     * @param iObs observation to add to the list.
     * @return true if the observation is either added to the list, or replaces
     * an older observation.
     */
	synchronized boolean addObs(IObs iObs)
	{
		int nIndex = Collections.binarySearch(m_oObs, iObs, this);

		// add obs that are completely new
		if (nIndex < 0)
		{
			m_oObs.add(~nIndex, iObs);
			return true;
		}

		// replace existing obs with newer obs
		if (m_oObs.get(nIndex).getObsTimeLong() <= iObs.getObsTimeLong())
		{
			m_oObs.set(nIndex, iObs);
			return true;
		}
		
		return false;
	}


    /**
     * Compares the two observations by sensor id.
     * @param oLhs object to compare to {@code oRhs}
     * @param oRhs object to compare to {@code oLhs}
     * @return 0 if the sensor id's match. otherwise they don't.
     */
	public int compare(IObs oLhs, IObs oRhs)
	{
		return (oLhs.getSensorId() -  oRhs.getSensorId());
	}
}
